# Current Data Inventory and Balance Audit

## Inventory

- PDFs: 16
- EPUBs: 12
- HTML research pages: 10
- Extracted words: 1,990,161
- Estimated 220-word chunks: 11,068

File totals are descriptive only. The experimental corpus must be balanced after chunking because files differ greatly in length.

## Balanced podcast-Q&A target

The pilot target is 40 validated questions for each of six content agents (240 total).

| Content agent | Current primary-label Q&A | Additional needed |
|---|---:|---:|
| mental_health | 59 | 0 |
| sleep | 8 | 32 |
| hormonal_health | 38 | 2 |
| lifestyle | 34 | 6 |
| nutrition_body | 66 | 0 |
| intervention | 32 | 8 |

Router, Safety and Synthesizer are workflow agents, so they do not receive equal document quotas. Safety is evaluated with a separate risk-query set.

## Current written-corpus concentration

| Automatically inferred primary domain | Estimated chunks before quality filtering |
|---|---:|
| intervention | 4,099 |
| lifestyle | 1,397 |
| mental_health | 3,984 |
| nutrition_body | 1,315 |
| sleep | 272 |
| unclassified | 1 |

These keyword-based domain assignments are preliminary. Every source still requires quality, relevance and licence review.
