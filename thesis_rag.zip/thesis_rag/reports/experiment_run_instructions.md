# RAG Experiment Run Instructions

These commands assume you are in the project root:

```bash
cd /Users/danicam003/Documents/Codex/2026-06-20/i-am-doing-a-master-thesis
```

## 1. Prepared Data

The preparation step has already created:

```text
thesis_rag/data/prepared/passages.jsonl
thesis_rag/data/prepared/qna_pairs.jsonl
thesis_rag/data/prepared/qna_pairs_train.jsonl
thesis_rag/data/prepared/qna_pairs_test.jsonl
thesis_rag/data/prepared/evaluation_questions.jsonl
thesis_rag/data/prepared/knowledge_graph.json
thesis_rag/data/prepared/source_manifest.csv
thesis_rag/data/prepared/concept_inventory.csv
thesis_rag/data/prepared/agent_concepts.json
thesis_rag/data/prepared/preparation_report.md
```

Current counts:

```text
Source files scanned: 62
Passage chunks: 1081
Human-reviewed Q&A rows: 492
Q&A train/index rows: 394
Q&A held-out test rows: 98
Active concept vocabulary: 331
Graph nodes: 307
Graph candidate edges: 17631
```

The 98 held-out Q&A rows are used only for testing. They are not included in
`qna_pairs.jsonl` and are not used to build the knowledge graph.

To regenerate the prepared files:

```bash
/Users/danicam003/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
  thesis_rag/experiments/prepare_experiment_data.py \
  --concept-matrix "/Users/danicam003/Desktop/files for thesis/highlight_concept_metadata_matrix.xlsx"
```

## 2. Install/Download Model Dependencies

If you run the full RAG models locally, install the model dependencies first:

```bash
cd thesis_rag
python3 -m pip install -e '.[models]'
cd ..
```

If VS Code/Jupyter shows a message like `Disabling PyTorch because PyTorch >= 2.4
is required but found 2.2.2`, the environment has installed a newer
`transformers` package than this Mac/Python environment can support. Install the
compatible versions inside the active notebook kernel and then restart the
kernel:

```python
import sys
!{sys.executable} -m pip install --upgrade "numpy<2"
!{sys.executable} -m pip install --upgrade "torch==2.2.2"
!{sys.executable} -m pip install --upgrade "transformers>=4.41,<4.48" "sentence-transformers>=3.0,<3.5"
!{sys.executable} -m pip install --upgrade qdrant-client accelerate openpyxl pypdf
```

This local compatibility path is intended for running ClinicalBERT embeddings,
Qdrant indexing and the MiniLM reranker on machines where only `torch==2.2.2` is
available. The final `Qwen/Qwen3.5-0.8B` generator may still require a newer
PyTorch/Transformers stack. If Qwen3.5 fails locally after this fix, run the full
generator experiments in Google Colab or another environment that can install
PyTorch 2.4 or newer.

Then make sure the models are available from Hugging Face:

```bash
huggingface-cli download emilyalsentzer/Bio_ClinicalBERT
huggingface-cli download cross-encoder/ms-marco-MiniLM-L6-v2
huggingface-cli download Qwen/Qwen3.5-0.8B
```

If your Hugging Face account uses a different accessible Qwen checkpoint, set it
with `GENERATOR_MODEL`.

## 3. Fixed Model Settings

Use the same generator, embedding model, reranker, and Qdrant path across all
experimental conditions:

```bash
export GENERATOR_MODEL=Qwen/Qwen3.5-0.8B
export EMBEDDING_MODEL=emilyalsentzer/Bio_ClinicalBERT
export RERANKER_MODEL=cross-encoder/ms-marco-MiniLM-L6-v2
export GENERATOR_TASK=image-text-to-text
export QDRANT_PATH=thesis_rag/outputs/qdrant_local
```

## 4. Smoke Test First

Run only two held-out questions first. This confirms that the models load, the
indexes build, and JSONL output is written.

```bash
python3 thesis_rag/experiments/run_experiment_batch.py \
  --model single_agent \
  --questions thesis_rag/data/prepared/evaluation_questions.jsonl \
  --passages thesis_rag/data/prepared/passages.jsonl \
  --output thesis_rag/outputs/runs/single_agent_smoke.jsonl \
  --limit 2 \
  --reindex
```

Expected output:

```text
Wrote 2 results to thesis_rag/outputs/runs/single_agent_smoke.jsonl
```

Each JSONL line contains the test ID, query, model answer, retrieved evidence,
latency, expected domain, expected tags, and reference answer.

## 5. Full Experiment Runs

Run the full held-out test set for each model.

Single-agent passage RAG:

```bash
python3 thesis_rag/experiments/run_experiment_batch.py \
  --model single_agent \
  --questions thesis_rag/data/prepared/evaluation_questions.jsonl \
  --passages thesis_rag/data/prepared/passages.jsonl \
  --output thesis_rag/outputs/runs/single_agent.jsonl \
  --reindex
```

Multi-agent passage RAG:

```bash
python3 thesis_rag/experiments/run_experiment_batch.py \
  --model multi_agent_passage \
  --questions thesis_rag/data/prepared/evaluation_questions.jsonl \
  --passages thesis_rag/data/prepared/passages.jsonl \
  --output thesis_rag/outputs/runs/multi_agent_passage.jsonl
```

Question-to-question semantic retrieval RAG:

```bash
python3 thesis_rag/experiments/run_experiment_batch.py \
  --model question_to_question \
  --questions thesis_rag/data/prepared/evaluation_questions.jsonl \
  --qna thesis_rag/data/prepared/qna_pairs.jsonl \
  --output thesis_rag/outputs/runs/question_to_question.jsonl \
  --reindex
```

Graph-supported multi-agent passage RAG:

```bash
python3 thesis_rag/experiments/run_experiment_batch.py \
  --model graph_supported \
  --questions thesis_rag/data/prepared/evaluation_questions.jsonl \
  --passages thesis_rag/data/prepared/passages.jsonl \
  --graph thesis_rag/data/prepared/knowledge_graph.json \
  --output thesis_rag/outputs/runs/graph_supported.jsonl
```

## 6. Compare the Models

After the four run files exist, calculate metrics:

```bash
python3 thesis_rag/experiments/evaluate_experiment_outputs.py \
  --runs \
    thesis_rag/outputs/runs/single_agent.jsonl \
    thesis_rag/outputs/runs/multi_agent_passage.jsonl \
    thesis_rag/outputs/runs/question_to_question.jsonl \
    thesis_rag/outputs/runs/graph_supported.jsonl \
  --output-dir thesis_rag/outputs/metrics \
  --k 5
```

Expected metric outputs:

```text
thesis_rag/outputs/metrics/detailed_metrics.csv
thesis_rag/outputs/metrics/summary_metrics.csv
thesis_rag/outputs/metrics/summary_metrics.json
```

The evaluator reports both micro averages and macro-by-domain averages. Macro
averages are important because the available data is not perfectly balanced
across domains.

## 7. What the Metrics Mean

The automatic evaluator calculates:

```text
precision_at_5
hit_at_5
mrr
ndcg_at_5
answer_reference_f1
citation_count
route_domain_hit
latency_seconds
```

These are proxy metrics. They are useful for comparing systems consistently,
but they should be supplemented with manual thesis scoring for evidence
faithfulness, contextual completeness, citation correctness, and safety.
