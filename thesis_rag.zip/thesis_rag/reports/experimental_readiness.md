# Experimental Readiness Decision

## Decision

The collection is large enough to begin a controlled pilot, but it is not yet balanced enough for the final model comparison. Readiness depends on balancing selected retrieval units, not collecting the same number of files for every architecture.

## Required collection before the pilot

- Written corpus target: 18 eligible sources, operationally planned as 12 PDFs and 6 EPUBs.
- Evidence target: 40 selected 220-word passage units for each of six content domains, 240 units total.
- Podcast target: 40 validated questions for each content domain, 240 questions total.
- New podcast extraction required: 32 Sleep, 2 Hormonal Health, 6 Lifestyle and 8 Intervention questions.
- New written-source priority: at least three strong hormonal-health sources and enough written nutrition evidence to avoid treating the podcast transcript as a written scientific source.
- Safety resources: separate crisis, contraindication and escalation policies; these are not balanced against content domains.

## Why 12 PDFs and 6 EPUBs is not the statistical control

The exact 12/6 split is a practical collection plan that yields 18 source slots, or three independent source contributions per content domain. The actual control is enforced after text extraction: equal evidence-unit counts, approximately equal selected words, source caps and identical corpora across systems. Replacing one long EPUB with several short papers is acceptable if the final selected evidence budget remains unchanged.

## Go/no-go checks

The experiment is ready only when all checks pass:

1. Every source has title, author, year, source type, domain, quality tier and licence status.
2. Every evidence unit has a source ID, location, domain and stable evidence ID.
3. Every content domain has 40 passage units and 40 question units.
4. No source supplies more than 35% of a domain's selected units.
5. The same source text is used across primary comparison conditions.
6. Evaluation queries are held out from indexing and prompt development.
7. Graph edges contain evidence IDs and pass the tuned confidence threshold.
8. The same generator, embedding model, top-k and context budget are used across systems.
9. Safety and synthesis outputs are evaluated independently of routing accuracy.
10. At least a stratified sample of source extraction, Q&A alignment and graph edges has been reviewed by a second annotator.

