from __future__ import annotations

import json
from dataclasses import dataclass

from .knowledge_graph import GraphEdge, Relation


GRAPH_EXTRACTION_PROMPT = """
Extract only relationships explicitly supported by the supplied evidence passage.
Return a JSON array. Each object must contain:
source_node, source_type, relation, target_node, target_type, evidence_ids,
source_quality, extraction_confidence, entailment_score, polarity,
population, statement_type, and notes.

Allowed relations:
associated_with, co_occurs_with, may_contribute_to, evaluated_by,
may_be_supported_by, contraindicated_for, relevant_during,
modified_by_context, mentioned_in, routed_to.

Rules:
- Do not convert an association into causation.
- Do not infer a treatment recommendation from co-occurrence.
- Preserve negation, uncertainty and population restrictions.
- Every relationship must cite at least one supplied evidence ID.
- If the passage does not support a relationship, return an empty array.
""".strip()


@dataclass(frozen=True, slots=True)
class GraphCandidate:
    source_node: str
    relation: Relation
    target_node: str
    evidence_ids: tuple[str, ...]
    source_quality: float
    extraction_confidence: float
    entailment_score: float
    polarity: str = "positive"
    population: str = "unspecified"
    statement_type: str = "association"
    notes: str = ""

    def validate(self) -> None:
        if not self.evidence_ids:
            raise ValueError("Graph candidate has no evidence IDs")
        for field_name in ("source_quality", "extraction_confidence", "entailment_score"):
            value = getattr(self, field_name)
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{field_name} must be between 0 and 1")
        if self.statement_type == "association" and self.relation not in {
            Relation.ASSOCIATED_WITH,
            Relation.CO_OCCURS_WITH,
            Relation.MODIFIED_BY_CONTEXT,
            Relation.RELEVANT_DURING,
            Relation.MENTIONED_IN,
        }:
            raise ValueError("Association statement cannot be encoded as a stronger relation")

    def to_edge(self, edge_id: str, corroboration_count: int = 1) -> GraphEdge:
        self.validate()
        return GraphEdge(
            edge_id=edge_id,
            source_node=self.source_node,
            relation=self.relation,
            target_node=self.target_node,
            evidence_ids=self.evidence_ids,
            source_quality=self.source_quality,
            extraction_confidence=self.extraction_confidence,
            entailment_score=self.entailment_score,
            corroboration_count=corroboration_count,
            polarity=self.polarity,
            population=self.population,
            notes=self.notes,
        )


def parse_candidates(raw_json: str) -> list[GraphCandidate]:
    payload = json.loads(raw_json)
    if not isinstance(payload, list):
        raise ValueError("Graph extraction output must be a JSON array")
    candidates = []
    for item in payload:
        candidate = GraphCandidate(
            source_node=item["source_node"],
            relation=Relation(item["relation"]),
            target_node=item["target_node"],
            evidence_ids=tuple(item["evidence_ids"]),
            source_quality=float(item["source_quality"]),
            extraction_confidence=float(item["extraction_confidence"]),
            entailment_score=float(item["entailment_score"]),
            polarity=item.get("polarity", "positive"),
            population=item.get("population", "unspecified"),
            statement_type=item.get("statement_type", "association"),
            notes=item.get("notes", ""),
        )
        candidate.validate()
        candidates.append(candidate)
    return candidates
