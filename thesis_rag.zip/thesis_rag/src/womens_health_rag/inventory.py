from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import zipfile
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path

from pypdf import PdfReader

from .balancing import BalanceTarget, qna_deficits, qna_domain_counts
from .models import AgentName, CONTENT_AGENTS


DOMAIN_TERMS = {
    AgentName.MENTAL_HEALTH: ("anxiety", "depression", "mental health", "mood", "trauma", "cognitive behavioral", "self-esteem"),
    AgentName.SLEEP: ("sleep", "insomnia", "circadian", "wakefulness", "fatigue", "sleep deprivation"),
    AgentName.HORMONAL_HEALTH: ("menstrual", "pms", "pmdd", "pcos", "menopause", "estrogen", "progesterone", "fertility"),
    AgentName.LIFESTYLE: ("exercise", "physical activity", "social connection", "mindfulness", "yoga", "music therapy", "lifestyle"),
    AgentName.NUTRITION_BODY: ("nutrition", "diet", "food", "glucose", "insulin", "metabolic", "fiber", "body composition"),
    AgentName.INTERVENTION: ("therapy", "treatment", "intervention", "cognitive behavioral therapy", "medication", "supplement"),
}


class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self.hidden = 0

    def handle_starttag(self, tag, attrs):
        del attrs
        if tag in {"script", "style", "nav"}:
            self.hidden += 1

    def handle_endtag(self, tag):
        if tag in {"script", "style", "nav"} and self.hidden:
            self.hidden -= 1

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)

    def text(self) -> str:
        return re.sub(r"\s+", " ", " ".join(self.parts)).strip()


def html_text(raw: str) -> str:
    parser = TextExtractor()
    parser.feed(raw)
    return parser.text()


def extract_pdf(path: Path) -> tuple[str, int]:
    reader = PdfReader(str(path))
    return " ".join(page.extract_text() or "" for page in reader.pages), len(reader.pages)


def extract_epub(path: Path) -> tuple[str, int]:
    texts: list[str] = []
    document_count = 0
    with zipfile.ZipFile(path) as archive:
        for name in archive.namelist():
            if not name.lower().endswith((".html", ".htm", ".xhtml")):
                continue
            raw = archive.read(name).decode("utf-8", errors="ignore")
            text = html_text(raw)
            if text:
                texts.append(text)
                document_count += 1
    return " ".join(texts), document_count


def extract_html(path: Path) -> tuple[str, int]:
    return html_text(path.read_text(encoding="utf-8", errors="ignore")), 1


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def word_count(text: str) -> int:
    return len(re.findall(r"\b[\w'-]+\b", text))


def chunk_count(words: int, chunk_words: int, overlap_words: int) -> int:
    if words <= 0:
        return 0
    if words <= chunk_words:
        return 1
    return 1 + math.ceil((words - chunk_words) / (chunk_words - overlap_words))


def domain_scores(text: str) -> dict[str, int]:
    lowered = text.lower()
    return {
        agent.value: sum(lowered.count(term) for term in terms)
        for agent, terms in DOMAIN_TERMS.items()
    }


def scan(data_dir: Path, chunk_words: int = 220, overlap_words: int = 40) -> list[dict[str, object]]:
    rows = []
    for path in sorted(data_dir.iterdir(), key=lambda item: item.name.casefold()):
        suffix = path.suffix.lower()
        if not path.is_file() or suffix not in {".pdf", ".epub", ".html", ".htm"}:
            continue
        try:
            if suffix == ".pdf":
                text, structural_units = extract_pdf(path)
                source_type = "pdf"
            elif suffix == ".epub":
                text, structural_units = extract_epub(path)
                source_type = "epub"
            else:
                text, structural_units = extract_html(path)
                source_type = "html"
            words = word_count(text)
            scores = domain_scores(text)
            ranked = sorted(scores, key=lambda key: (-scores[key], key))
            rows.append({
                "source_id": f"SRC-{len(rows) + 1:03d}",
                "filename": path.name,
                "path": str(path),
                "source_type": source_type,
                "bytes": path.stat().st_size,
                "structural_units": structural_units,
                "words": words,
                "estimated_chunks": chunk_count(words, chunk_words, overlap_words),
                "primary_domain": ranked[0] if scores[ranked[0]] else "unclassified",
                "domain_scores": scores,
                "sha256": sha256(path),
                "extraction_status": "ok" if words else "no_text_extracted",
                "quality_review": "pending",
                "license_review": "pending",
            })
        except Exception as exc:  # Inventory must record failures rather than stopping.
            rows.append({
                "source_id": f"SRC-{len(rows) + 1:03d}",
                "filename": path.name,
                "path": str(path),
                "source_type": suffix.lstrip("."),
                "bytes": path.stat().st_size,
                "structural_units": 0,
                "words": 0,
                "estimated_chunks": 0,
                "primary_domain": "unclassified",
                "domain_scores": {},
                "sha256": sha256(path),
                "extraction_status": f"error: {type(exc).__name__}: {exc}",
                "quality_review": "pending",
                "license_review": "pending",
            })
    return rows


def build_report(rows: list[dict[str, object]], qna_path: Path, target: BalanceTarget) -> str:
    by_type = Counter(str(row["source_type"]) for row in rows)
    words_by_type = Counter()
    chunks_by_domain = Counter()
    for row in rows:
        words_by_type[str(row["source_type"])] += int(row["words"])
        chunks_by_domain[str(row["primary_domain"])] += int(row["estimated_chunks"])
    qna_counts = qna_domain_counts(qna_path)
    deficits = qna_deficits(qna_path, target)
    lines = [
        "# Current Data Inventory and Balance Audit",
        "",
        "## Inventory",
        "",
        f"- PDFs: {by_type['pdf']}",
        f"- EPUBs: {by_type['epub']}",
        f"- HTML research pages: {by_type['html'] + by_type['htm']}",
        f"- Extracted words: {sum(int(row['words']) for row in rows):,}",
        f"- Estimated {target.chunk_words}-word chunks: {sum(int(row['estimated_chunks']) for row in rows):,}",
        "",
        "File totals are descriptive only. The experimental corpus must be balanced after chunking because files differ greatly in length.",
        "",
        "## Balanced podcast-Q&A target",
        "",
        f"The pilot target is {target.units_per_domain} validated questions for each of six content agents ({target.units_per_domain * len(CONTENT_AGENTS)} total).",
        "",
        "| Content agent | Current primary-label Q&A | Additional needed |",
        "|---|---:|---:|",
    ]
    for agent in CONTENT_AGENTS:
        lines.append(f"| {agent.value} | {qna_counts[agent]} | {deficits[agent]} |")
    lines.extend([
        "",
        "Router, Safety and Synthesizer are workflow agents, so they do not receive equal document quotas. Safety is evaluated with a separate risk-query set.",
        "",
        "## Current written-corpus concentration",
        "",
        "| Automatically inferred primary domain | Estimated chunks before quality filtering |",
        "|---|---:|",
    ])
    for domain, count in sorted(chunks_by_domain.items()):
        lines.append(f"| {domain} | {count:,} |")
    lines.extend([
        "",
        "These keyword-based domain assignments are preliminary. Every source still requires quality, relevance and licence review.",
    ])
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--qna", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-report", type=Path, required=True)
    args = parser.parse_args()
    target = BalanceTarget()
    rows = scan(args.data_dir, target.chunk_words, target.overlap_words)
    payload = {
        "data_directory": str(args.data_dir),
        "chunk_words": target.chunk_words,
        "overlap_words": target.overlap_words,
        "sources": rows,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_report.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    args.output_report.write_text(build_report(rows, args.qna, target), encoding="utf-8")
    print(json.dumps({"sources": len(rows), "words": sum(int(row["words"]) for row in rows)}, indent=2))


if __name__ == "__main__":
    main()
