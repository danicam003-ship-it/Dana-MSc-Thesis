from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Sequence

from .models import AgentName, AgentResult, CONTENT_AGENTS, EvidenceUnit, PipelineState
from .retrieval import Generator, Retriever


@dataclass(slots=True)
class BaseAgent:
    name: AgentName
    domains: tuple[AgentName, ...]
    system_prompt: str
    retriever: Retriever
    generator: Generator
    top_k: int = 5

    def run(self, state: PipelineState) -> AgentResult:
        evidence = self.retriever.search(
            state.query,
            domains=self.domains,
            top_k=self.top_k,
            user_context=state.user_context,
        )
        answer = self.generator.generate(
            self.system_prompt,
            state.query,
            evidence,
            state.user_context,
        )
        confidence = sum(item.retrieval_score for item in evidence) / max(1, len(evidence))
        return AgentResult(self.name, answer, evidence, confidence)


class MentalHealthAgent(BaseAgent):
    def __init__(self, retriever: Retriever, generator: Generator, top_k: int = 5):
        super().__init__(
            AgentName.MENTAL_HEALTH,
            (AgentName.MENTAL_HEALTH,),
            "Explain mental-health evidence without diagnosing the user. Distinguish symptoms, associations and disorders.",
            retriever,
            generator,
            top_k,
        )


class SleepAgent(BaseAgent):
    def __init__(self, retriever: Retriever, generator: Generator, top_k: int = 5):
        super().__init__(
            AgentName.SLEEP,
            (AgentName.SLEEP,),
            "Explain sleep, circadian and fatigue evidence and its limits. Do not infer a diagnosis from sleep symptoms.",
            retriever,
            generator,
            top_k,
        )


class HormonalHealthAgent(BaseAgent):
    def __init__(self, retriever: Retriever, generator: Generator, top_k: int = 5):
        super().__init__(
            AgentName.HORMONAL_HEALTH,
            (AgentName.HORMONAL_HEALTH,),
            "Explain menstrual, reproductive and hormonal evidence across life stages. Avoid deterministic causal claims.",
            retriever,
            generator,
            top_k,
        )


class LifestyleAgent(BaseAgent):
    def __init__(self, retriever: Retriever, generator: Generator, top_k: int = 5):
        super().__init__(
            AgentName.LIFESTYLE,
            (AgentName.LIFESTYLE,),
            "Explain modifiable lifestyle and social-context evidence without blaming the user or treating demographics as destiny.",
            retriever,
            generator,
            top_k,
        )


class NutritionBodyAgent(BaseAgent):
    def __init__(self, retriever: Retriever, generator: Generator, top_k: int = 5):
        super().__init__(
            AgentName.NUTRITION_BODY,
            (AgentName.NUTRITION_BODY,),
            "Explain nutrition, metabolic and body-related evidence. Separate general education from individualized advice.",
            retriever,
            generator,
            top_k,
        )


class InterventionAgent(BaseAgent):
    def __init__(self, retriever: Retriever, generator: Generator, top_k: int = 5):
        super().__init__(
            AgentName.INTERVENTION,
            (AgentName.INTERVENTION,),
            "Summarize possible interventions by evidence level, contraindications and uncertainty; never prescribe or set doses.",
            retriever,
            generator,
            top_k,
        )


class RouterAgent:
    KEYWORDS: dict[AgentName, tuple[str, ...]] = {
        AgentName.MENTAL_HEALTH: ("anxiety", "depression", "mood", "panic", "trauma", "adhd", "stress"),
        AgentName.SLEEP: ("sleep", "insomnia", "tired", "fatigue", "circadian", "wake"),
        AgentName.HORMONAL_HEALTH: ("period", "pms", "pmdd", "pcos", "hormone", "menopause", "fertility"),
        AgentName.LIFESTYLE: ("exercise", "work", "relationship", "social", "breathing", "music", "habit"),
        AgentName.NUTRITION_BODY: ("food", "diet", "nutrition", "weight", "glucose", "insulin", "vitamin"),
        AgentName.INTERVENTION: ("help", "treat", "therapy", "supplement", "medication", "what can i do"),
    }

    def route(self, query: str, max_agents: int = 3) -> list[AgentName]:
        text = query.lower()
        scores = {
            agent: sum(text.count(keyword) for keyword in keywords)
            for agent, keywords in self.KEYWORDS.items()
        }
        selected = [agent for agent in CONTENT_AGENTS if scores[agent] > 0]
        selected.sort(key=lambda agent: (-scores[agent], CONTENT_AGENTS.index(agent)))
        return selected[:max_agents] or [AgentName.MENTAL_HEALTH]


class SafetyAgent:
    URGENT_PATTERNS = (
        re.compile(r"\bkill myself\b", re.I),
        re.compile(r"\bsuicid(?:e|al)\b", re.I),
        re.compile(r"\bself[- ]?harm\b", re.I),
        re.compile(r"\boverdose\b", re.I),
        re.compile(r"\bimmediate danger\b", re.I),
    )

    def precheck(self, state: PipelineState) -> list[str]:
        return ["urgent_safety_language"] if any(p.search(state.query) for p in self.URGENT_PATTERNS) else []

    def postcheck(self, answer: str) -> list[str]:
        warnings = []
        if re.search(r"\b(definitely|certainly) (?:have|means you have)\b", answer, re.I):
            warnings.append("deterministic_diagnostic_language")
        if re.search(r"\b(?:take|use) \d+(?:\.\d+)?\s*(?:mg|g|mcg|iu)\b", answer, re.I):
            warnings.append("individualized_dose_language")
        return warnings


class SynthesizerAgent:
    def __init__(self, generator: Generator):
        self.name = AgentName.SYNTHESIZER
        self.generator = generator

    def synthesize(self, state: PipelineState) -> str:
        evidence_by_id: dict[str, EvidenceUnit] = {}
        for result in state.agent_results:
            for item in result.evidence:
                evidence_by_id[item.evidence_id] = item
        evidence = sorted(evidence_by_id.values(), key=lambda item: (-item.retrieval_score, item.evidence_id))
        return self.generator.generate(
            "Synthesize only the supplied evidence. Preserve disagreements, cite evidence IDs and state uncertainty.",
            state.query,
            evidence,
            state.user_context,
        )


def build_domain_agents(retriever: Retriever, generator: Generator, top_k: int = 5) -> dict[AgentName, BaseAgent]:
    agents: Sequence[BaseAgent] = (
        MentalHealthAgent(retriever, generator, top_k),
        SleepAgent(retriever, generator, top_k),
        HormonalHealthAgent(retriever, generator, top_k),
        LifestyleAgent(retriever, generator, top_k),
        NutritionBodyAgent(retriever, generator, top_k),
        InterventionAgent(retriever, generator, top_k),
    )
    return {agent.name: agent for agent in agents}

