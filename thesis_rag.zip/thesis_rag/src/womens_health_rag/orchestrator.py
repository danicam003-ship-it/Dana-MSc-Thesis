from __future__ import annotations

from dataclasses import dataclass, field

from .agents import RouterAgent, SafetyAgent, SynthesizerAgent, build_domain_agents
from .models import AgentName, PipelineState, UserContext
from .retrieval import Generator, Retriever


@dataclass(slots=True)
class MultiAgentRAG:
    retriever: Retriever
    generator: Generator
    top_k_per_agent: int = 5
    router: RouterAgent = field(init=False)
    safety: SafetyAgent = field(init=False)
    synthesizer: SynthesizerAgent = field(init=False)
    agents: dict = field(init=False)

    def __post_init__(self) -> None:
        self.router = RouterAgent()
        self.safety = SafetyAgent()
        self.synthesizer = SynthesizerAgent(self.generator)
        self.agents = build_domain_agents(self.retriever, self.generator, self.top_k_per_agent)

    def answer(self, query: str, user_context: UserContext | None = None) -> PipelineState:
        state = PipelineState(query=query, user_context=user_context or UserContext())
        state.safety_flags.extend(self.safety.precheck(state))
        state.routed_agents = self.router.route(query)
        state.agent_results = [self.agents[name].run(state) for name in state.routed_agents]
        state.final_answer = self.synthesizer.synthesize(state)
        state.safety_flags.extend(self.safety.postcheck(state.final_answer))
        state.citations = sorted({
            item.evidence_id
            for result in state.agent_results
            for item in result.evidence
        })
        return state


@dataclass(slots=True)
class SingleAgentRAG:
    retriever: Retriever
    generator: Generator
    top_k: int = 5

    def answer(self, query: str, user_context: UserContext | None = None) -> PipelineState:
        context = user_context or UserContext()
        state = PipelineState(query=query, user_context=context, routed_agents=[AgentName.ROUTER])
        evidence = self.retriever.search(query, (), self.top_k, context)
        state.final_answer = self.generator.generate(
            "Answer educationally from the supplied evidence, without diagnosis or prescription.",
            query,
            evidence,
            context,
        )
        state.citations = [item.evidence_id for item in evidence]
        return state


@dataclass(slots=True)
class QuestionToQuestionRAG(SingleAgentRAG):
    """Uses the same interface, but the retriever index contains stored questions linked to answers."""

    def answer(self, query: str, user_context: UserContext | None = None) -> PipelineState:
        state = super().answer(query, user_context)
        state.routed_agents = [AgentName.ROUTER]
        return state
