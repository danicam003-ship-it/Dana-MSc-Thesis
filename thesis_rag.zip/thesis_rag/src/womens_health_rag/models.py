from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class AgentName(StrEnum):
    ROUTER = "router"
    MENTAL_HEALTH = "mental_health"
    SLEEP = "sleep"
    HORMONAL_HEALTH = "hormonal_health"
    LIFESTYLE = "lifestyle"
    NUTRITION_BODY = "nutrition_body"
    INTERVENTION = "intervention"
    SAFETY = "safety"
    SYNTHESIZER = "synthesizer"


CONTENT_AGENTS = (
    AgentName.MENTAL_HEALTH,
    AgentName.SLEEP,
    AgentName.HORMONAL_HEALTH,
    AgentName.LIFESTYLE,
    AgentName.NUTRITION_BODY,
    AgentName.INTERVENTION,
)


@dataclass(frozen=True, slots=True)
class UserContext:
    age_band: str | None = None
    life_stage: str | None = None
    demographic_context: dict[str, str] = field(default_factory=dict)
    family_history: tuple[str, ...] = ()
    preferences: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class EvidenceUnit:
    evidence_id: str
    text: str
    source_id: str
    source_type: str
    domain: AgentName
    title: str = ""
    page_start: int | None = None
    page_end: int | None = None
    retrieval_score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class AgentResult:
    agent: AgentName
    answer: str
    evidence: list[EvidenceUnit] = field(default_factory=list)
    confidence: float = 0.0
    warnings: list[str] = field(default_factory=list)


@dataclass(slots=True)
class PipelineState:
    query: str
    user_context: UserContext = field(default_factory=UserContext)
    routed_agents: list[AgentName] = field(default_factory=list)
    agent_results: list[AgentResult] = field(default_factory=list)
    safety_flags: list[str] = field(default_factory=list)
    final_answer: str = ""
    citations: list[str] = field(default_factory=list)

