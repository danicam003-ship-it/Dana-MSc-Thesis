from __future__ import annotations

from dataclasses import replace
from typing import Sequence

from .models import AgentName, EvidenceUnit, UserContext


class SentenceTransformerRetriever:
    """Dense retriever adapter loaded only when sentence-transformers is installed."""

    def __init__(self, evidence: Sequence[EvidenceUnit], model_id: str = "emilyalsentzer/Bio_ClinicalBERT"):
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise RuntimeError("Install the 'models' optional dependencies first") from exc
        self.evidence = list(evidence)
        self.model = SentenceTransformer(model_id)
        self.corpus_embeddings = self.model.encode(
            [item.text for item in self.evidence],
            normalize_embeddings=True,
            show_progress_bar=True,
        )

    def search(
        self,
        query: str,
        domains: Sequence[AgentName],
        top_k: int,
        user_context: UserContext,
    ) -> list[EvidenceUnit]:
        del user_context
        import numpy as np

        query_embedding = self.model.encode([query], normalize_embeddings=True)[0]
        scores = np.asarray(self.corpus_embeddings) @ np.asarray(query_embedding)
        allowed = set(domains)
        candidates = [
            (float(scores[index]), item)
            for index, item in enumerate(self.evidence)
            if not allowed or item.domain in allowed
        ]
        candidates.sort(key=lambda pair: (-pair[0], pair[1].evidence_id))
        return [replace(item, retrieval_score=score) for score, item in candidates[:top_k]]


class HuggingFaceChatGenerator:
    """Local conversational-model adapter; use one instance for every experimental arm."""

    def __init__(self, model_id: str = "Qwen/Qwen3.5-0.8B", max_new_tokens: int = 450):
        try:
            from transformers import pipeline
        except ImportError as exc:
            raise RuntimeError("Install the 'models' optional dependencies first") from exc
        self.pipe = pipeline("text-generation", model=model_id, device_map="auto")
        self.max_new_tokens = max_new_tokens

    def generate(
        self,
        system_prompt: str,
        query: str,
        evidence: Sequence[EvidenceUnit],
        user_context: UserContext,
    ) -> str:
        evidence_text = "\n\n".join(
            f"[{item.evidence_id}] {item.text}" for item in evidence
        ) or "No evidence retrieved."
        context_text = (
            f"Life stage: {user_context.life_stage or 'not provided'}; "
            f"age band: {user_context.age_band or 'not provided'}."
        )
        messages = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": (
                    f"User context: {context_text}\n"
                    f"Question: {query}\n\nEvidence:\n{evidence_text}\n\n"
                    "Use only the evidence. Cite evidence IDs. State uncertainty and do not diagnose."
                ),
            },
        ]
        output = self.pipe(messages, max_new_tokens=self.max_new_tokens, do_sample=False)
        generated = output[0]["generated_text"]
        if isinstance(generated, list):
            return generated[-1]["content"]
        return str(generated)
