from __future__ import annotations

import re
from dataclasses import replace
from typing import Protocol, Sequence

from .models import AgentName, EvidenceUnit, UserContext


class Retriever(Protocol):
    def search(
        self,
        query: str,
        domains: Sequence[AgentName],
        top_k: int,
        user_context: UserContext,
    ) -> list[EvidenceUnit]: ...


class Generator(Protocol):
    def generate(
        self,
        system_prompt: str,
        query: str,
        evidence: Sequence[EvidenceUnit],
        user_context: UserContext,
    ) -> str: ...


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-z][a-z0-9-]{2,}", text.lower()))


class InMemoryRetriever:
    """Dependency-free lexical baseline used by tests and as a BM25 sanity check."""

    def __init__(self, evidence: Sequence[EvidenceUnit]):
        self.evidence = list(evidence)

    def search(
        self,
        query: str,
        domains: Sequence[AgentName],
        top_k: int,
        user_context: UserContext,
    ) -> list[EvidenceUnit]:
        del user_context
        query_tokens = _tokens(query)
        allowed = set(domains)
        scored: list[tuple[float, EvidenceUnit]] = []
        for item in self.evidence:
            if allowed and item.domain not in allowed:
                continue
            item_tokens = _tokens(item.text)
            score = len(query_tokens & item_tokens) / max(1, len(query_tokens | item_tokens))
            scored.append((score, item))
        scored.sort(key=lambda pair: (-pair[0], pair[1].evidence_id))
        return [replace(item, retrieval_score=score) for score, item in scored[:top_k]]


class EvidenceOnlyGenerator:
    """Deterministic generator stub; replace with a local Qwen/HF adapter for experiments."""

    def generate(
        self,
        system_prompt: str,
        query: str,
        evidence: Sequence[EvidenceUnit],
        user_context: UserContext,
    ) -> str:
        del system_prompt, user_context
        if not evidence:
            return "The indexed evidence is insufficient to answer this question."
        citations = ", ".join(f"[{item.evidence_id}]" for item in evidence)
        return f"Evidence retrieved for '{query}': {citations}"

