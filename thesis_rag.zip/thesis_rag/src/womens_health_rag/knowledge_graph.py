from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Sequence

from .models import AgentName, EvidenceUnit, UserContext
from .retrieval import Retriever


class NodeType(StrEnum):
    SYMPTOM = "symptom"
    CONDITION = "condition"
    INTERVENTION = "intervention"
    LIFE_STAGE = "life_stage"
    DEMOGRAPHIC_CONTEXT = "demographic_context"
    NUTRIENT = "nutrient"
    SOURCE = "source"
    PASSAGE = "passage"
    QUESTION = "question"
    AGENT_DOMAIN = "agent_domain"


class Relation(StrEnum):
    ASSOCIATED_WITH = "associated_with"
    CO_OCCURS_WITH = "co_occurs_with"
    MAY_CONTRIBUTE_TO = "may_contribute_to"
    EVALUATED_BY = "evaluated_by"
    MAY_BE_SUPPORTED_BY = "may_be_supported_by"
    CONTRAINDICATED_FOR = "contraindicated_for"
    RELEVANT_DURING = "relevant_during"
    MODIFIED_BY_CONTEXT = "modified_by_context"
    MENTIONED_IN = "mentioned_in"
    ROUTED_TO = "routed_to"


@dataclass(frozen=True, slots=True)
class GraphNode:
    node_id: str
    node_type: NodeType
    canonical_name: str
    synonyms: tuple[str, ...] = ()
    metadata: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class GraphEdge:
    edge_id: str
    source_node: str
    relation: Relation
    target_node: str
    evidence_ids: tuple[str, ...]
    source_quality: float
    extraction_confidence: float
    entailment_score: float
    corroboration_count: int = 1
    contradiction_penalty: float = 0.0
    human_reviewed: bool = False
    polarity: str = "positive"
    population: str = "unspecified"
    notes: str = ""

    def confidence(self) -> float:
        corroboration = min(self.corroboration_count, 3) / 3
        review = 1.0 if self.human_reviewed else 0.0
        raw = (
            0.25 * self.source_quality
            + 0.25 * self.extraction_confidence
            + 0.30 * self.entailment_score
            + 0.15 * corroboration
            + 0.05 * review
            - 0.25 * self.contradiction_penalty
        )
        return max(0.0, min(1.0, raw))


class KnowledgeGraph:
    def __init__(self) -> None:
        self.nodes: dict[str, GraphNode] = {}
        self.edges: dict[str, GraphEdge] = {}

    def add_node(self, node: GraphNode) -> None:
        if node.node_id in self.nodes and self.nodes[node.node_id] != node:
            raise ValueError(f"Conflicting node definition: {node.node_id}")
        self.nodes[node.node_id] = node

    def add_edge(self, edge: GraphEdge) -> None:
        if not edge.evidence_ids:
            raise ValueError("Every graph edge must have at least one evidence ID")
        if edge.source_node not in self.nodes or edge.target_node not in self.nodes:
            raise ValueError("Both edge nodes must exist before adding the edge")
        if edge.edge_id in self.edges and self.edges[edge.edge_id] != edge:
            raise ValueError(f"Conflicting edge definition: {edge.edge_id}")
        self.edges[edge.edge_id] = edge

    def confident_edges(self, threshold: float) -> list[GraphEdge]:
        return sorted(
            (edge for edge in self.edges.values() if edge.confidence() >= threshold),
            key=lambda edge: (-edge.confidence(), edge.edge_id),
        )

    def neighbors(self, node_id: str, threshold: float = 0.0) -> list[GraphEdge]:
        return [
            edge
            for edge in self.confident_edges(threshold)
            if edge.source_node == node_id or edge.target_node == node_id
        ]

    def expand(self, seed_node_ids: set[str], threshold: float, max_hops: int = 1) -> set[str]:
        visited = set(seed_node_ids)
        frontier = set(seed_node_ids)
        for _ in range(max_hops):
            next_frontier: set[str] = set()
            for node_id in frontier:
                for edge in self.neighbors(node_id, threshold):
                    next_frontier.update((edge.source_node, edge.target_node))
            next_frontier -= visited
            visited.update(next_frontier)
            frontier = next_frontier
            if not frontier:
                break
        return visited


class GraphAugmentedRetriever:
    """Adds provenance-linked graph evidence to an unchanged base retrieval result."""

    def __init__(
        self,
        base: Retriever,
        graph: KnowledgeGraph,
        evidence_by_id: dict[str, EvidenceUnit],
        threshold: float = 0.70,
        max_hops: int = 1,
    ) -> None:
        self.base = base
        self.graph = graph
        self.evidence_by_id = evidence_by_id
        self.threshold = threshold
        self.max_hops = max_hops

    def _link_query(self, query: str) -> set[str]:
        lowered = query.lower()
        return {
            node.node_id
            for node in self.graph.nodes.values()
            if node.canonical_name.lower() in lowered
            or any(synonym.lower() in lowered for synonym in node.synonyms)
        }

    def search(
        self,
        query: str,
        domains: Sequence[AgentName],
        top_k: int,
        user_context: UserContext,
    ) -> list[EvidenceUnit]:
        base_results = self.base.search(query, domains, top_k, user_context)
        linked_nodes = self._link_query(query)
        expanded_nodes = self.graph.expand(linked_nodes, self.threshold, self.max_hops)
        graph_evidence_ids = {
            evidence_id
            for node_id in expanded_nodes
            for edge in self.graph.neighbors(node_id, self.threshold)
            for evidence_id in edge.evidence_ids
        }
        merged = {item.evidence_id: item for item in base_results}
        for evidence_id in sorted(graph_evidence_ids):
            item = self.evidence_by_id.get(evidence_id)
            if item and (not domains or item.domain in set(domains)):
                merged.setdefault(evidence_id, item)
        return sorted(
            merged.values(),
            key=lambda item: (-item.retrieval_score, item.evidence_id),
        )[:top_k]
