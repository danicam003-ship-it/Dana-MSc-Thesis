from __future__ import annotations

import csv
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path

from .models import AgentName, CONTENT_AGENTS


AGENT_LABEL_MAP = {
    "Mental Health Agent": AgentName.MENTAL_HEALTH,
    "Sleep Agent": AgentName.SLEEP,
    "Hormonal Health Agent": AgentName.HORMONAL_HEALTH,
    "Lifestyle Agent": AgentName.LIFESTYLE,
    "Nutrition and Body Agent": AgentName.NUTRITION_BODY,
    "Intervention Agent": AgentName.INTERVENTION,
}


@dataclass(frozen=True, slots=True)
class BalanceTarget:
    units_per_domain: int = 40
    chunk_words: int = 220
    overlap_words: int = 40
    min_sources_per_domain: int = 3
    max_source_share: float = 0.35
    token_tolerance: float = 0.05


def qna_domain_counts(csv_path: Path) -> Counter[AgentName]:
    counts: Counter[AgentName] = Counter()
    with csv_path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            agent = AGENT_LABEL_MAP.get(row.get("primary_agent", ""))
            if agent:
                counts[agent] += 1
    return counts


def qna_deficits(csv_path: Path, target: BalanceTarget) -> dict[AgentName, int]:
    counts = qna_domain_counts(csv_path)
    return {agent: max(0, target.units_per_domain - counts[agent]) for agent in CONTENT_AGENTS}


def audit_selected_units(rows: list[dict[str, str]], target: BalanceTarget) -> dict[str, object]:
    by_domain: Counter[str] = Counter(row["domain"] for row in rows)
    sources: dict[str, Counter[str]] = defaultdict(Counter)
    for row in rows:
        sources[row["domain"]][row["source_id"]] += 1
    issues: list[str] = []
    for domain in (agent.value for agent in CONTENT_AGENTS):
        count = by_domain[domain]
        if count != target.units_per_domain:
            issues.append(f"{domain}: expected {target.units_per_domain} units, found {count}")
        if len(sources[domain]) < target.min_sources_per_domain:
            issues.append(f"{domain}: fewer than {target.min_sources_per_domain} independent sources")
        if count:
            largest_share = max(sources[domain].values(), default=0) / count
            if largest_share > target.max_source_share:
                issues.append(f"{domain}: one source contributes {largest_share:.1%}")
    return {"balanced": not issues, "counts": dict(by_domain), "issues": issues}

