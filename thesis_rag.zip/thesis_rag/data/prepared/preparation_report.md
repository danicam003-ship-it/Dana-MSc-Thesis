# Experiment Data Preparation Report

## Inputs
- Source files scanned: 62
- Source file types: {'html': 14, 'pdf': 3, 'science_direct_html': 45}
- Human-reviewed Q&A rows loaded: 492
- Active concept vocabulary: 331 concepts
- Concept source: default agent concepts plus highlighted concept metadata matrix: /Users/danicam003/Desktop/files for thesis/highlight_concept_metadata_matrix.xlsx

## Outputs
- Passage chunks: 1081 -> `thesis_rag/data/prepared/passages.jsonl`
- Q&A train/index rows: 394 -> `thesis_rag/data/prepared/qna_pairs.jsonl`
- Q&A held-out test rows: 98 -> `thesis_rag/data/prepared/qna_pairs_test.jsonl`
- Training questions: 394 -> `thesis_rag/data/prepared/training_questions.jsonl`
- Evaluation questions: 98 -> `thesis_rag/data/prepared/evaluation_questions.jsonl`
- Graph nodes: 307
- Graph candidate edges above threshold: 17631

## Domain Distribution

| Domain | Passages | Q&A train | Q&A test |
|---|---:|---:|---:|
| mental_health | 586 | 82 | 20 |
| sleep | 177 | 105 | 27 |
| hormonal_health | 29 | 54 | 13 |
| lifestyle | 188 | 51 | 13 |
| nutrition_body | 77 | 73 | 18 |
| intervention | 24 | 29 | 7 |

## Leakage Control
Held-out Q&A rows are not written to `qna_pairs.jsonl` and are not used when constructing graph edges.
They are written only to `qna_pairs_test.jsonl` and `evaluation_questions.jsonl`.

## Notes
The graph is semi-automatic: the concept vocabulary is controlled by the agent concepts and the highlighted concept metadata matrix, while candidate edges are created automatically from concept co-occurrence in the training evidence.
All graph edges are retrieval-expansion candidates and require manual review before being treated as thesis evidence.
