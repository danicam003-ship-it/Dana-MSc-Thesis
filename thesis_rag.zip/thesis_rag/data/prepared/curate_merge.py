import csv
import hashlib
import json
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

CSV_PATH = Path("/Users/danicam003/Downloads/huberman_lab_essentials_qna_files/qna_pairs_retrieval.csv")
JSON_PATH = Path("/Users/danicam003/Documents/work/huberman_qa/qa_data.json")
MATCH_PATH = Path("/Users/danicam003/Documents/work/huberman_qa_cleaned/analysis/cross_source_matches.tsv")
OUT_DIR = Path("/Users/danicam003/Documents/work/huberman_qa_cleaned/curated")

CSV_MANUAL_REMOVE = {
    # Contextless fragments, rhetorical filler, malformed extraction, banter, or personal promotion
    1, 4, 8, 9, 12, 13, 14, 15, 16, 17, 20, 22, 24, 26, 27, 36, 37,
    41, 42, 43, 44, 46, 47, 48, 50, 54, 56, 58, 59, 63, 64, 66, 68, 71,
    73, 74, 75, 77, 79, 84, 93, 94, 99, 104, 106, 109, 110, 113, 115,
    118, 120, 122, 123, 124, 126, 127, 128, 129, 131, 133, 134, 136,
    137, 138, 139, 140, 141, 143, 144, 146, 147, 148, 149, 150, 151,
    152, 153, 154, 155, 156, 159, 161, 162, 164, 171, 174, 181, 183,
    184, 185, 188, 193, 199, 200, 203, 204, 205, 207, 208, 212, 215,
    217, 219, 221, 224, 228, 229, 231, 232, 234, 236, 238, 243, 244,
    245, 246, 247, 249, 250, 253, 254, 255, 257, 258, 259, 260, 261,
    262, 263, 265, 266, 268, 271, 272, 273, 274, 275, 277, 278, 279,
    280, 281, 282, 283, 284, 286, 287, 288, 291, 293, 294, 295, 296,
    297, 298, 299, 300, 302, 305, 309, 315, 316, 323, 324, 325, 330,
    333, 335, 337, 338, 343, 344, 345, 346, 347, 349, 350, 351, 353,
    358, 359, 361, 362, 363, 365, 367, 368, 369, 370, 377, 383, 384,
    385, 386, 389, 392, 395, 397, 399, 402, 403, 405, 406, 408, 409,
    418, 419, 420, 421, 423, 425, 428, 430, 432, 435, 442, 444, 451,
    453, 454, 456, 460, 462, 463, 465, 468, 470, 471, 473, 474, 475,
    476, 481, 483, 486, 488, 491,
    # Additional semantic review: answer mismatch or still-dependent antecedent.
    10, 19, 28, 53, 60, 145, 157, 163, 196, 213, 216, 220, 276,
    292, 380, 391, 398, 413, 447, 457, 458, 459, 78, 214,
}

WORKBOOK_MANUAL_REMOVE = {
    "QA-0002", "QA-0007", "QA-0008", "QA-0009", "QA-0018", "QA-0032",
    "QA-0038", "QA-0042", "QA-0044", "QA-0045", "QA-0053", "QA-0057",
    "QA-0058", "QA-0059", "QA-0062", "QA-0068", "QA-0073", "QA-0082",
    "QA-0090", "QA-0091", "QA-0094", "QA-0102", "QA-0103", "QA-0107",
    "QA-0109", "QA-0113", "QA-0115", "QA-0116", "QA-0117", "QA-0118",
    "QA-0119", "QA-0120", "QA-0126", "QA-0127", "QA-0128", "QA-0129",
    "QA-0131", "QA-0132", "QA-0135", "QA-0137", "QA-0142", "QA-0148",
    "QA-0157", "QA-0158", "QA-0159", "QA-0164", "QA-0168", "QA-0169",
    "QA-0175", "QA-0176", "QA-0178", "QA-0186", "QA-0192", "QA-0197",
    "QA-0207", "QA-0209", "QA-0211", "QA-0213", "QA-0214", "QA-0229",
    "QA-0234", "QA-0235", "QA-0236", "QA-0247", "QA-0253", "QA-0254",
    "QA-0258",
    "QA-0003", "QA-0011", "QA-0012", "QA-0043", "QA-0047", "QA-0050",
    "QA-0054", "QA-0060", "QA-0061", "QA-0063", "QA-0076", "QA-0081",
    "QA-0086", "QA-0087", "QA-0092", "QA-0095", "QA-0096", "QA-0097",
    "QA-0098", "QA-0105", "QA-0110", "QA-0114", "QA-0121", "QA-0122",
    "QA-0124", "QA-0134", "QA-0143", "QA-0163", "QA-0165", "QA-0166",
    "QA-0170", "QA-0171", "QA-0174", "QA-0177", "QA-0185", "QA-0190",
    "QA-0195", "QA-0196", "QA-0201", "QA-0204", "QA-0210", "QA-0216",
    "QA-0221", "QA-0225", "QA-0239", "QA-0248", "QA-0259", "QA-0261",
    "QA-0039", "QA-0046", "QA-0049", "QA-0130", "QA-0262",
}

QUESTION_REWRITES = {
    "hle_qna_0005": "What is the vagus nerve?",
    "hle_qna_0055": "What distinguishes clinically concerning period pain from typical premenstrual cramping?",
    "hle_qna_0065": "How is polycystic ovary syndrome (PCOS) diagnosed?",
    "hle_qna_0086": "How is premenstrual dysphoric disorder (PMDD) treated?",
    "hle_qna_0173": "What does the decibel scale mean?",
    "hle_qna_0357": "Can exercise help alleviate symptoms of depression?",
    "hle_qna_0414": "Do all women need iron supplementation?",
    "hle_qna_0482": "How quickly should blood glucose return toward baseline after eating?",
    "hle_qna_0097": "How do the lungs pack a large gas-exchange surface area into the chest?",
    "hle_qna_0356": "Why might people with major depression need medication or supplementation in addition to behavioral tools?",
    "hle_qna_0241": "How should protein sources be compared in terms of protein quality?",
    "hle_qna_0336": "What are brain-machine interfaces, and how are they used?",
    "hle_qna_0484": "Which foods can unexpectedly spike glucose, and how much do glycemic responses vary between individuals?",
    "hle_qna_0485": "Which lifestyle strategies can reduce post-meal glucose spikes?",
}

WORKBOOK_REWRITES = {
    "QA-0010": "What is the lifetime risk of breast cancer for women?",
    "QA-0017": "What is premenstrual dysphoric disorder (PMDD)?",
    "QA-0208": "What is Schisandra?",
    "QA-0223": "What is the most efficient way for women to train for health, vigor, and longevity?",
    "QA-0249": "What does the evidence say about L-glutamine supplementation?",
    "QA-0250": "What are thylakoids, and why are they discussed in relation to satiety?",
}

GENERIC_QUESTIONS = {
    "why", "why not", "how", "how so", "what", "where", "when", "who",
    "tell me more", "could you elaborate", "what happened", "what happens",
    "what does this mean", "what does that mean", "how does that work",
    "is that right", "why is that", "did it really", "do they really",
    "what are those", "what do they do", "what sorts of things",
}

PROMOTIONAL = re.compile(
    r"where can (?:people|listeners|we) find|social media|subscribe|your (?:book|podcast|website|newsletter)",
    re.I,
)
SPEAKER_TAG = re.compile(r"\[(?:Andrew Huberman|Alia Crum|Casey Means|Stacy Sims|[^\]]+:)", re.I)
PROMPT = re.compile(r"\b(?:tell us|tell me|explain|describe|elaborate|walk us through|share with us|help us understand)\b", re.I)

AGENT_TERMS = {
    "Mental Health Agent": ["anxiety", "depression", "psychiat", "mental health", "mood", "trauma", "adhd", "stress", "emotion"],
    "Sleep Agent": ["sleep", "insomnia", "circadian", "wake", "dream", "night"],
    "Hormonal Health Agent": ["hormone", "estrogen", "progesterone", "androgen", "pcos", "menopause", "perimenopause", "menstrual", "period", "fertility", "endometriosis", "ovarian"],
    "Lifestyle Agent": ["exercise", "training", "practice", "mindset", "behavior", "lifestyle", "breath", "meditation", "music", "social", "environment"],
    "Nutrition and Body Agent": ["food", "diet", "nutrition", "protein", "glucose", "insulin", "metabolic", "mitochond", "vitamin", "magnesium", "fat", "muscle"],
    "Intervention Agent": ["therapy", "treat", "protocol", "medication", "supplement", "recommend", "dose", "surgery", "diagnos", "screen"],
    "Safety Agent": ["suicid", "self-harm", "cancer", "overdose", "danger", "contraindicat", "pregnan"],
}

OLD_AGENT_MAP = {
    "Psychological Symptoms": "Mental Health Agent",
    "Mental Health": "Mental Health Agent",
    "Sleep": "Sleep Agent",
    "Reproductive and Hormonal Health": "Hormonal Health Agent",
    "Hormonal Health": "Hormonal Health Agent",
    "Lifestyle and Context": "Lifestyle Agent",
    "Lifestyle and Intervention": "Lifestyle Agent",
    "Nutrition and Body": "Nutrition and Body Agent",
    "Intervention": "Intervention Agent",
    "Safety": "Safety Agent",
    "Router / General": "Router Agent",
}


def normalize(text):
    text = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def words(text):
    return normalize(text).split()


def checksum(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def page_bounds(value):
    nums = [int(x) for x in re.findall(r"\d+", str(value or ""))]
    return (min(nums), max(nums)) if nums else (None, None)


def question_quality(question, answer, source_id, source):
    q=(question or "").strip()
    a=(answer or "").strip()
    nq=normalize(q)
    reasons = []
    if not q or not a:
        reasons.append("Blank question or answer")
    if source=="CSV" and int(source_id.rsplit("_", 1)[1]) in CSV_MANUAL_REMOVE:
        reasons.append("Manual review: contextless, malformed, conversational, or non-educational prompt")
    if source=="Workbook" and source_id in WORKBOOK_MANUAL_REMOVE:
        reasons.append("Manual review: contextless, malformed, conversational, or non-educational prompt")
    if nq in GENERIC_QUESTIONS:
        reasons.append("Generic follow-up lacks standalone meaning")
    if len(words(q)) <= 2:
        reasons.append("Too short to express a standalone information need")
    if PROMOTIONAL.search(q):
        reasons.append("Promotional or source-discovery question")
    if SPEAKER_TAG.search(q) or SPEAKER_TAG.search(a):
        reasons.append("Speaker labels are embedded in the extracted pair")
    if "?" not in q and not PROMPT.search(q):
        reasons.append("No explicit question or interview prompt")
    if source == "CSV" and len(words(a)) < 12:
        reasons.append("Answer is too short to support retrieval")
    return ("REMOVE" if reasons else "KEEP"), reasons


def assign_episode(page, question_speaker, answer_speaker, episodes):
    if page is None:
        return {"episode_id": "UNMAPPED", "title": "Unmapped transcript segment"}
    for episode in episodes:
        # EP-006 begins at the page transition around 328 in the CSV extraction.
        start = 328 if episode["episode_id"] == "EP-006" else episode["start_page"]
        if start <= page <= episode["end_page"]:
            return episode
    if page <= 10:
        return {
            "episode_id": "EP-S01",
            "title": "Gut-Brain Axis, Nutrition and Mood (solo educational segment)",
            "start_page": 1,
            "end_page": 10,
            "guest": answer_speaker,
            "guest_credentials": "PhD" if answer_speaker == "Andrew Huberman" else "See Speakers sheet",
        }
    if 368 <= page <= 409:
        return {
            "episode_id": "EP-S02",
            "title": "Depression, Sleep, Breathing and Circadian Biology (solo educational segment)",
            "start_page": 368,
            "end_page": 409,
            "guest": answer_speaker,
            "guest_credentials": "PhD" if answer_speaker == "Andrew Huberman" else "See Speakers sheet",
        }
    return {"episode_id": "UNMAPPED", "title": "Unmapped transcript segment"}


def agents(question, answer):
    text = normalize(question + " " + answer[:1200])
    scores = [(name, sum(text.count(term) for term in terms)) for name, terms in AGENT_TERMS.items()]
    ranked = [name for name, score in sorted(scores, key=lambda item: (-item[1], item[0])) if score]
    primary = ranked[0] if ranked else "Router Agent"
    secondary = "; ".join(ranked[1:3])
    return primary, secondary


def standalone_score(question, answer, source):
    q_words = len(words(question))
    a_words = len(words(answer))
    score = 0
    score += 3 if 6 <= q_words <= 55 else 1
    score += 3 if 20 <= a_words <= 260 else 1 if 12 <= a_words <= 450 else 0
    score += 2 if not re.search(r"\b(this|that|those|these|it|they)\b", normalize(question)) else 0
    score += 1 if source == "Workbook" else 0  # Existing excerpts are deliberately concise.
    return score


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with CSV_PATH.open(encoding="utf-8-sig", newline="") as handle:
        csv_rows = list(csv.DictReader(handle))
    data = json.loads(JSON_PATH.read_text(encoding="utf-8"))
    workbook_rows = data["qa_pairs"]
    episodes = data["episodes"]

    match_by_csv = {}
    if MATCH_PATH.exists():
        with MATCH_PATH.open(encoding="utf-8", newline="") as handle:
            for row in csv.DictReader(handle, delimiter="\t"):
                match_by_csv[row["csv_id"]] = row

    records=[]
    audits=[]
    workbook_by_id = {row["pair_id"]: row for row in workbook_rows}
    workbook_decisions = {}

    for row in workbook_rows:
        cleaned_question = WORKBOOK_REWRITES.get(row["pair_id"], row["question"])
        decision, reasons = question_quality(cleaned_question, row["possible_answer"], row["pair_id"], "Workbook")
        workbook_decisions[row["pair_id"]] = decision
        audits.append({
            "source": "Workbook", "source_id": row["pair_id"], "decision": decision,
            "reason": "; ".join(reasons) if reasons else "Passed standalone-question review",
            "question": row["question"], "pages": str(row["question_page"]),
        })
        if decision == "KEEP":
            primary, secondary = agents(cleaned_question, row["possible_answer"])
            records.append({
                "source_origin": "Existing workbook",
                "source_record_id": row["pair_id"],
                "pair_type": "dialogue",
                "question": cleaned_question,
                "original_question": row["question"],
                "question_edited": "Yes" if cleaned_question != row["question"] else "No",
                "answer": row["possible_answer"],
                "question_speaker": row["interviewer"],
                "answer_speaker": row["interviewee"],
                "pages": str(row["question_page"]),
                "episode_id": row["episode_id"],
                "episode_title": row["episode_title"],
                "primary_agent": OLD_AGENT_MAP.get(row.get("primary_agent"), primary),
                "secondary_agents": "; ".join(
                    OLD_AGENT_MAP.get(part.strip(), part.strip())
                    for part in (row.get("secondary_agents") or secondary).split(";")
                    if part.strip()
                ),
                "safety_tag": row.get("safety_tag", "None identified"),
                "context_dependency": row.get("context_dependency", "Low"),
                "retrieval_recommendation": row.get("recommended_for_q2q", "Yes"),
                "extraction_confidence": row.get("extraction_confidence", 0.85),
                "review_status": "Automatically cleaned; manual scientific verification required",
                "source_file": data["source_file"],
            })

    chosen_workbook_ids = {record["source_record_id"] for record in records if record["source_origin"] == "Existing workbook"}
    added_csv_ids = []
    duplicate_audits = []

    for row in csv_rows:
        source_id = row["id"]
        rewritten = QUESTION_REWRITES.get(source_id, row["question"])
        decision, reasons = question_quality(rewritten, row["answer"], source_id, "CSV")
        match = match_by_csv.get(source_id)
        duplicate_workbook_id = None
        similarity = 0.0
        if match:
            duplicate_workbook_id = match["workbook_id"]
            similarity = float(match["combined_similarity"])

        if decision == "KEEP" and similarity >= 0.72 and duplicate_workbook_id in chosen_workbook_ids:
            decision = "DUPLICATE"
            reasons = [f"Near-duplicate of {duplicate_workbook_id}; concise workbook representation retained"]

        audits.append({
            "source": "CSV", "source_id": source_id, "decision": decision,
            "reason": "; ".join(reasons) if reasons else "Passed standalone-question and answer review",
            "question": row["question"], "pages": row["pages"],
        })

        if decision != "KEEP":
            if decision == "DUPLICATE":
                duplicate_audits.append({
                    "csv_id": source_id,
                    "workbook_id": duplicate_workbook_id,
                    "similarity": similarity,
                    "retained_source": "Existing workbook",
                    "csv_question": row["question"],
                    "workbook_question": workbook_by_id[duplicate_workbook_id]["question"],
                })
            continue

        start_page, end_page = page_bounds(row["pages"])
        episode = assign_episode(start_page, row["question_speaker"], row["answer_speaker"], episodes)
        primary, secondary = agents(rewritten, row["answer"])
        records.append({
            "source_origin": "Supplied CSV addition",
            "source_record_id": source_id,
            "pair_type": row["pair_type"],
            "question": rewritten,
            "original_question": row["question"],
            "question_edited": "Yes" if rewritten != row["question"] else "No",
            "answer": row["answer"],
            "question_speaker": row["question_speaker"],
            "answer_speaker": row["answer_speaker"],
            "pages": row["pages"],
            "episode_id": episode["episode_id"],
            "episode_title": episode["title"],
            "primary_agent": primary,
            "secondary_agents": secondary,
            "safety_tag": "Safety review required" if primary == "Safety Agent" or "Safety Agent" in secondary else "None identified automatically",
            "context_dependency": "Low" if standalone_score(rewritten, row["answer"], "CSV") >= 7 else "Medium",
            "retrieval_recommendation": "Yes" if standalone_score(rewritten, row["answer"], "CSV") >= 6 else "Review",
            "extraction_confidence": 0.84 if row["pair_type"] == "dialogue" else 0.78,
            "review_status": "Automatically cleaned; manual scientific verification required",
            "source_file": row["source_file"],
        })
        added_csv_ids.append(source_id)

    # Stable order follows transcript page, then source identity. Assign new master IDs.
    def sort_key(record):
        start, _ = page_bounds(record["pages"])
        return (start if start is not None else 9999, record["source_origin"], record["source_record_id"])

    # Remove exact normalized-question duplicates that survived cross-source fuzzy matching.
    deduplicated_records = []
    by_question = defaultdict(list)
    for record in records:
        by_question[normalize(record["question"])].append(record)
    for group in by_question.values():
        if len(group) == 1:
            deduplicated_records.append(group[0])
            continue
        retained = max(group, key=lambda record: standalone_score(
            record["question"], record["answer"],
            "Workbook" if record["source_origin"] == "Existing workbook" else "CSV",
        ))
        deduplicated_records.append(retained)
        for record in group:
            if record is retained:
                continue
            source_name = "Workbook" if record["source_origin"] == "Existing workbook" else "CSV"
            for audit in reversed(audits):
                if audit["source"] == source_name and audit["source_id"] == record["source_record_id"]:
                    audit["decision"] = "DUPLICATE"
                    audit["reason"] = f"Exact normalized-question duplicate; {retained['source_record_id']} retained"
                    break
    records = deduplicated_records
    records.sort(key=sort_key)
    for index, record in enumerate(records, 1):
        record["pair_id"] = f"CQA-{index:04d}"
        record["embedding_text"] = record["question"]

    summary = {
        "source_csv": str(CSV_PATH),
        "source_csv_sha256": checksum(CSV_PATH),
        "source_workbook_json": str(JSON_PATH),
        "source_workbook_json_sha256": checksum(JSON_PATH),
        "input_csv_pairs": len(csv_rows),
        "input_workbook_pairs": len(workbook_rows),
        "cleaned_master_pairs": len(records),
        "retained_from_workbook": sum(r["source_origin"] == "Existing workbook" for r in records),
        "added_from_csv": sum(r["source_origin"] == "Supplied CSV addition" for r in records),
        "rewritten_questions": sum(r["question_edited"] == "Yes" for r in records),
        "removed_csv": sum(a["source"] == "CSV" and a["decision"] == "REMOVE" for a in audits),
        "removed_workbook": sum(a["source"] == "Workbook" and a["decision"] == "REMOVE" for a in audits),
        "deduplicated_csv": sum(a["source"] == "CSV" and a["decision"] == "DUPLICATE" for a in audits),
        "decision_counts": dict(Counter(a["decision"] for a in audits)),
    }

    output = {
        "summary": summary,
        "records": records,
        "audit": audits,
        "duplicate_audit": duplicate_audits,
        "episodes": episodes,
        "method_notes": data.get("method_notes", []),
        "source_file": data["source_file"],
        "source_sha256": data["source_sha256"],
    }
    (OUT_DIR / "cleaned_master.json").write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")

    csv_fields = [
        "pair_id", "embedding_text", "question", "original_question", "question_edited",
        "answer", "pair_type", "question_speaker", "answer_speaker", "pages",
        "episode_id", "episode_title", "primary_agent", "secondary_agents", "safety_tag",
        "context_dependency", "retrieval_recommendation", "extraction_confidence",
        "source_origin", "source_record_id", "review_status", "source_file",
    ]
    with (OUT_DIR / "qna_pairs_retrieval_cleaned.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=csv_fields)
        writer.writeheader()
        for record in records:
            writer.writerow({field: record.get(field, "") for field in csv_fields})

    print(json.dumps(summary, indent=2))
    print("Pairs by source:", Counter(record["source_origin"] for record in records))
    print("Pairs by agent:", Counter(record["primary_agent"] for record in records))


if __name__ == "__main__":
    main()
