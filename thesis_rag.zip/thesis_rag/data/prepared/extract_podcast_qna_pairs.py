
"""Extract podcast-style Q&A pairs from a transcript PDF.

This script only creates a Q&A pair when it
can identify a question-like speaker turn and a following answer span that ends
at a speaker boundary. It does not cut an answer in the middle of a word or in the
middle of a speaker turn.

Short questions often depend on nearby context ("Why?", "How so?", "What about
sleep?"). For those cases, the script stores context_before/context_after and an
expanded_question field instead of treating the short text as standalone.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import pdfplumber


DEFAULT_INPUT = Path("/Users/danicam003/Desktop/Data for master thesis/Document 3.pdf")
DEFAULT_OUTPUT_DIR = Path("outputs/podcast_qna/document3_extraction")

QUESTION_STARTERS = { "what", "why",  "how",  "when", "where","who",  "which", "can", "could", "would", "should", "is", "are",  "do", "does",  "did",
    "tell",
}

QUESTION_INTRO_PATTERNS = [
    re.compile(r"\bsomebody\s+asked\b", re.I),
    re.compile(r"\bsomeone\s+asked\b", re.I),
    re.compile(r"\ba\s+couple\s+(?:of\s+)?people\s+(?:wrote|asked|said)\b", re.I),
    re.compile(r"\bpeople\s+(?:wrote|asked|said)\b", re.I),
    re.compile(r"\bmany\s+(?:of\s+)?you\s+(?:asked|wrote|said)\b", re.I),
    re.compile(r"\ba\s+number\s+of\s+people\s+(?:asked|wrote|said)\b", re.I),
]

ANSWER_CUE_PATTERNS = [
    re.compile(r"\bgreat\s+question\b", re.I),
    re.compile(r"\bgood\s+question\b", re.I),
    re.compile(r"\bexcellent\s+question\b", re.I),
    re.compile(r"\bthe\s+answer\s+is\b", re.I),
    re.compile(r"\bshort\s+answer\b", re.I),
]

UI_NOISE_PATTERNS = [
    re.compile(r"^File Home Insert Layout References Review View Help", re.I),
    re.compile(r"^Aptos \(Body\)", re.I),
    re.compile(r"^Mode$", re.I),
    re.compile(r"^Page \d+ of \d+", re.I),
    re.compile(r"^Search for tools", re.I),
    re.compile(r"^Document \d+", re.I),
    re.compile(r"^Text Predictions:", re.I),
]


@dataclass
class Turn:
    turn_id: str
    source_file: str
    page_start: int
    page_end: int
    speaker: str
    text: str
    word_count: int
    has_question_mark: bool
    is_question_candidate: bool
    extraction_flags: str


@dataclass
class QAPair:
    pair_id: str
    source_file: str
    source_title: str
    question_speaker: str
    answer_speakers: str
    question: str
    expanded_question: str
    answer: str
    context_before: str
    context_after: str
    question_word_count: int
    answer_word_count: int
    page_start: int
    page_end: int
    extraction_method: str
    extraction_flags: str
    requires_manual_review: str


def normalize_whitespace(text: str) -> str:
    """Collapse repeated whitespace while preserving complete words."""
    return re.sub(r"\s+", " ", text).strip()


def strip_leading_quote_artifacts(text: str) -> str:
    """Remove quotation fragments that can remain after an embedded question."""
    return normalize_whitespace(text).lstrip(" \"'“”‘’")


def word_count(text: str) -> int:
    return len(re.findall(r"\b[\w'-]+\b", text))


def cap_text_at_sentence_boundary(text: str, max_words: int = 900) -> tuple[str, bool]:
    """Cap long text after a complete sentence when possible.

    This is used only for unusually long transcript spans caused by imperfect
    PDF paragraph extraction. It avoids cutting in the middle of words and
    prefers a sentence boundary over a hard token cutoff.
    """
    if word_count(text) <= max_words:
        return text, False

    sentences = re.findall(r".+?(?:[.!?](?:\s+|$)|$)", text)
    kept: list[str] = []
    running_words = 0
    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue
        sentence_words = word_count(sentence)
        if kept and running_words + sentence_words > max_words:
            break
        kept.append(sentence)
        running_words += sentence_words
        if running_words >= max_words:
            break

    capped = normalize_whitespace(" ".join(kept))
    if word_count(capped) >= 80:
        return capped, True
    return text, False


def is_noise_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return True
    if any(pattern.search(stripped) for pattern in UI_NOISE_PATTERNS):
        return True
    # The PDF supplied here is a screenshot-like Word export. This removes the
    # ribbon shortcut debris but keeps transcript lines.
    if "⌘" in stripped or "Option + Q" in stripped:
        return True
    return False


def clean_line(line: str) -> str:
    line = line.replace("\uf4e0", "").replace("\ue721", "")
    line = re.sub(r"[\u200b\u200c\u200d]", "", line)
    return line.strip()


def looks_like_speaker_line(line: str) -> str | None:
    """Return speaker name if the line is a standalone speaker label."""
    match = re.match(r"^([A-Z][A-Za-z .'\-]{1,80}):$", line.strip())
    if not match:
        return None
    speaker = normalize_whitespace(match.group(1))
    # Avoid treating ordinary prose ending with a colon as a speaker label.
    if len(speaker.split()) > 6:
        return None
    return speaker


def extract_pages(pdf_path: Path) -> list[tuple[int, list[str]]]:
    """Extract text lines per page with light cleanup."""
    pages: list[tuple[int, list[str]]] = []
    with pdfplumber.open(pdf_path) as pdf:
        for page_number, page in enumerate(pdf.pages, start=1):
            text = page.extract_text(x_tolerance=1, y_tolerance=3) or ""
            lines = []
            for raw_line in text.splitlines():
                line = clean_line(raw_line)
                if not is_noise_line(line):
                    lines.append(line)
            pages.append((page_number, lines))
    return pages


def make_turns(pdf_path: Path) -> list[Turn]:
    """Convert speaker-labelled transcript lines into speaker turns."""
    pages = extract_pages(pdf_path)
    turns: list[Turn] = []
    current_speaker = ""
    current_lines: list[str] = []
    current_start_page = 1
    current_end_page = 1

    def flush() -> None:
        nonlocal current_speaker, current_lines, current_start_page, current_end_page
        text = normalize_whitespace(" ".join(current_lines))
        if current_speaker and text:
            flags = []
            is_question = is_question_like(text)
            if word_count(text) < 8 and is_question:
                flags.append("short_question_needs_context")
            turns.append(
                Turn(
                    turn_id=f"doc3_turn_{len(turns) + 1:04d}",
                    source_file=str(pdf_path),
                    page_start=current_start_page,
                    page_end=current_end_page,
                    speaker=current_speaker,
                    text=text,
                    word_count=word_count(text),
                    has_question_mark="?" in text,
                    is_question_candidate=is_question,
                    extraction_flags="; ".join(flags),
                )
            )
        current_lines = []

    for page_number, lines in pages:
        for line in lines:
            speaker = looks_like_speaker_line(line)
            if speaker:
                flush()
                current_speaker = speaker
                current_start_page = page_number
                current_end_page = page_number
            else:
                if current_speaker:
                    current_lines.append(line)
                    current_end_page = page_number
    flush()
    return turns


def is_question_like(text: str) -> bool:
    """Detect explicit questions while avoiding broad false positives."""
    normalized = normalize_whitespace(text).lower()
    if "?" in normalized:
        return True
    first_word = re.match(r"^([a-z']+)", normalized)
    if first_word and first_word.group(1) in QUESTION_STARTERS:
        # Without a question mark, require short/interview-like phrasing.
        return word_count(text) <= 30
    return False


def find_sentence_start(text: str, position: int) -> int:
    """Find a clean sentence-ish boundary before a question."""
    boundary = max(text.rfind(". ", 0, position), text.rfind("\n", 0, position), text.rfind("; ", 0, position))
    return boundary + 2 if boundary >= 0 else 0


def find_question_intro_start(text: str, before_position: int) -> int | None:
    """Find the closest listener-question intro before a question mark."""
    window_start = max(0, before_position - 700)
    window = text[window_start:before_position]
    starts: list[int] = []
    for pattern in QUESTION_INTRO_PATTERNS:
        for match in pattern.finditer(window):
            starts.append(window_start + match.start())
    if not starts:
        return None
    return max(starts)


def first_answer_cue_after(text: str, first_question_mark: int) -> int | None:
    """Find a phrase that usually marks the answer after quoted/listener question text."""
    search = text[first_question_mark + 1 :]
    candidates: list[int] = []
    for pattern in ANSWER_CUE_PATTERNS:
        match = pattern.search(search)
        if match:
            candidates.append(first_question_mark + 1 + match.start())
    return min(candidates) if candidates else None


def extract_embedded_question(turn: Turn) -> tuple[str, str, str] | None:
    """Extract listener questions embedded inside a monologue turn.

    Returns question_text, same_turn_answer_remainder, flags. This catches common
    podcast phrasing such as:
      "Somebody asked, 'What about morning light?' Great question. ..."
    """
    text = turn.text
    if "?" not in text:
        return None

    first_q = text.find("?")
    intro_start = find_question_intro_start(text, first_q)
    if intro_start is None:
        # Avoid over-extracting rhetorical questions from explanatory answers.
        return None

    cue_start = first_answer_cue_after(text, first_q)
    if cue_start is not None:
        question_end = text.rfind("?", intro_start, cue_start)
    else:
        question_end = text.find("?", first_q)
    if question_end < first_q:
        question_end = first_q

    question = normalize_whitespace(text[intro_start : question_end + 1])
    answer_remainder = strip_leading_quote_artifacts(text[question_end + 1 :])
    flags = []
    if cue_start is None:
        flags.append("no_explicit_answer_cue")
    if word_count(question) < 8:
        flags.append("short_question_needs_context")
    return question, answer_remainder, "; ".join(flags)


def nearest_question_context(turns: list[Turn], index: int, direction: int) -> str:
    """Find a nearby same-speaker question for context expansion."""
    speaker = turns[index].speaker
    j = index + direction
    steps = 0
    while 0 <= j < len(turns) and steps < 3:
        if turns[j].speaker == speaker and turns[j].is_question_candidate:
            return turns[j].text
        # Stop if a long non-question by the same speaker intervenes.
        if turns[j].speaker == speaker and turns[j].word_count > 20:
            return ""
        j += direction
        steps += 1
    return ""


def build_expanded_question(turns: list[Turn], index: int) -> tuple[str, str, str, str]:
    """Attach context to very short questions without fabricating new wording."""
    question = turns[index].text
    context_before = ""
    context_after = ""
    flags: list[str] = []

    if turns[index].word_count < 8:
        context_before = nearest_question_context(turns, index, -1)
        context_after = nearest_question_context(turns, index, 1)
        flags.append("short_question_context_linked")

    expanded_parts = [context_before, question, context_after]
    expanded_question = normalize_whitespace(" ".join(part for part in expanded_parts if part))
    return expanded_question or question, context_before, context_after, "; ".join(flags)


def answer_span(turns: list[Turn], question_index: int) -> tuple[list[Turn], list[str]]:
    """Collect complete answer turns after a question.

    The answer starts only after a speaker change. It continues through complete
    turns until the next question candidate, so answer text is never cut midway
    through a speaker's contribution.
    """
    question_speaker = turns[question_index].speaker
    answer_turns: list[Turn] = []
    flags: list[str] = []
    j = question_index + 1
    if j >= len(turns) or turns[j].speaker == question_speaker:
        flags.append("no_immediate_answer_speaker_change")
        return [], flags

    while j < len(turns):
        turn = turns[j]
        if turn.is_question_candidate and answer_turns:
            break
        if turn.speaker == question_speaker and turn.is_question_candidate:
            break
        answer_turns.append(turn)
        j += 1

    if not answer_turns:
        flags.append("no_following_answer_speaker_turn")
    elif sum(turn.word_count for turn in answer_turns) < 25:
        flags.append("answer_span_short_manual_review")

    return answer_turns, flags


def monologue_answer_span(
    turns: list[Turn],
    question_index: int,
    same_turn_answer_remainder: str,
    max_words: int = 900,
    max_pages: int = 6,
) -> tuple[str, list[Turn], list[str]]:
    """Build an answer for a question read aloud by the same speaker.

    The answer starts after the embedded question, then continues through full
    following speaker turns until the next listener-question marker. This keeps
    answer boundaries aligned to speaker turns and avoids mid-sentence truncation.
    """
    answer_parts: list[str] = []
    flags: list[str] = []

    running_words = 0
    if same_turn_answer_remainder:
        answer_parts.append(same_turn_answer_remainder)
        running_words += word_count(same_turn_answer_remainder)

    following_turns: list[Turn] = []
    j = question_index + 1
    while j < len(turns):
        if extract_embedded_question(turns[j]) is not None:
            break
        following_turns.append(turns[j])
        answer_parts.append(turns[j].text)
        running_words += turns[j].word_count
        page_span = turns[j].page_end - turns[question_index].page_start + 1
        if running_words >= max_words or (page_span >= max_pages and running_words >= 180):
            flags.append("answer_span_capped_at_complete_turn")
            break
        j += 1

    answer = strip_leading_quote_artifacts(" ".join(answer_parts))
    answer, capped_by_sentence = cap_text_at_sentence_boundary(answer, max_words=max_words)
    if capped_by_sentence:
        flags.append("answer_text_capped_at_sentence_boundary")
    if word_count(answer) < 25:
        flags.append("answer_span_short_manual_review")
    return answer, following_turns, flags


def make_qna_pairs(turns: list[Turn], source_title: str) -> list[QAPair]:
    pairs: list[QAPair] = []
    for index, turn in enumerate(turns):
        embedded = extract_embedded_question(turn)
        if embedded is not None:
            question, same_turn_answer, embedded_flags = embedded
            answer, following_turns, answer_flags = monologue_answer_span(turns, index, same_turn_answer)
            if word_count(answer) < 10:
                continue
            page_end = following_turns[-1].page_end if following_turns else turn.page_end
            flags = [flag for flag in [embedded_flags, *answer_flags] if flag]
            pairs.append(
                QAPair(
                    pair_id=f"doc3_qa_{len(pairs) + 1:04d}",
                    source_file=turn.source_file,
                    source_title=source_title,
                    question_speaker=turn.speaker,
                    answer_speakers=turn.speaker,
                    question=question,
                    expanded_question=question,
                    answer=answer,
                    context_before="",
                    context_after="",
                    question_word_count=word_count(question),
                    answer_word_count=word_count(answer),
                    page_start=turn.page_start,
                    page_end=page_end,
                    extraction_method="embedded listener-question extraction from monologue transcript",
                    extraction_flags="; ".join(flags),
                    requires_manual_review="yes" if flags else "no",
                )
            )
            continue

        if not turn.is_question_candidate:
            continue
        expanded_question, context_before, context_after, context_flags = build_expanded_question(turns, index)
        answer_turns, answer_flags = answer_span(turns, index)
        if not answer_turns:
            continue

        answer = strip_leading_quote_artifacts(" ".join(answer_turn.text for answer_turn in answer_turns))
        answer, capped_by_sentence = cap_text_at_sentence_boundary(answer)
        if capped_by_sentence:
            answer_flags.append("answer_text_capped_at_sentence_boundary")
        answer_speakers = "; ".join(dict.fromkeys(answer_turn.speaker for answer_turn in answer_turns))
        flags = [flag for flag in [context_flags, *answer_flags] if flag]
        pairs.append(
            QAPair(
                pair_id=f"doc3_qa_{len(pairs) + 1:04d}",
                source_file=turn.source_file,
                source_title=source_title,
                question_speaker=turn.speaker,
                answer_speakers=answer_speakers,
                question=turn.text,
                expanded_question=expanded_question,
                answer=answer,
                context_before=context_before,
                context_after=context_after,
                question_word_count=turn.word_count,
                answer_word_count=word_count(answer),
                page_start=turn.page_start,
                page_end=answer_turns[-1].page_end,
                extraction_method="speaker-turn rule extraction from PDF text layer",
                extraction_flags="; ".join(flags),
                requires_manual_review="yes" if flags else "no",
            )
        )
    return pairs


def link_short_question_context(pairs: list[QAPair]) -> None:
    """Add neighboring question context for short/underspecified questions."""
    for index, pair in enumerate(pairs):
        if pair.question_word_count >= 8:
            continue
        before = pairs[index - 1].question if index > 0 else ""
        after = pairs[index + 1].question if index + 1 < len(pairs) else ""
        pair.context_before = before
        pair.context_after = after
        pair.expanded_question = normalize_whitespace(" ".join(part for part in [before, pair.question, after] if part))
        flags = [pair.extraction_flags, "short_question_context_linked"]
        pair.extraction_flags = "; ".join(flag for flag in flags if flag)
        pair.requires_manual_review = "yes"


def write_csv(path: Path, rows: Iterable[dict], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    turns = make_turns(args.input)
    source_title = "SLEEP/LIFESTYLE PODCASTS - Document 3"
    pairs = make_qna_pairs(turns, source_title)
    link_short_question_context(pairs)

    write_csv(
        args.output_dir / "document3_turns.csv",
        (asdict(turn) for turn in turns),
        list(Turn.__dataclass_fields__.keys()),
    )
    write_csv(
        args.output_dir / "document3_qna_pairs.csv",
        (asdict(pair) for pair in pairs),
        list(QAPair.__dataclass_fields__.keys()),
    )
    (args.output_dir / "document3_turns.json").write_text(
        json.dumps([asdict(turn) for turn in turns], indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    (args.output_dir / "document3_qna_pairs.json").write_text(
        json.dumps([asdict(pair) for pair in pairs], indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    page_count = max((turn.page_end for turn in turns), default=0)
    if page_count <= 1:
        source_limitation = (
            "The supplied PDF is a one-page screenshot-like export of a Word document page, "
            "not the full transcript shown in the Word status bar. No complete Q&A pair can "
            "be produced unless the full transcript is exported as PDF/DOCX/TXT."
        )
    else:
        source_limitation = (
            "The supplied PDF is a multi-page transcript export. Extracted pairs should still "
            "be manually spot-checked because listener questions are sometimes embedded in "
            "single-speaker monologue rather than marked as separate speakers."
        )

    summary = {
        "source_file": str(args.input),
        "source_title": source_title,
        "page_count": page_count,
        "turn_count": len(turns),
        "question_candidate_count": sum(turn.is_question_candidate for turn in turns),
        "qna_pair_count": len(pairs),
        "method": "Speaker-labelled transcript turns were extracted from the PDF text layer. Questions were detected as complete speaker turns or embedded listener questions introduced by phrases such as 'somebody asked'. Answers were built from complete subsequent speaker turns and stopped at the next question candidate.",
        "source_limitation": source_limitation,
        "manual_review_required": len(pairs) == 0 or any(pair.requires_manual_review == "yes" for pair in pairs),
    }
    (args.output_dir / "document3_extraction_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    (args.output_dir / "document3_clean_text.txt").write_text(
        "\n\n".join(f"{turn.speaker}:\n{turn.text}" for turn in turns),
        encoding="utf-8",
    )

    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
