import csv
import json
import re
import unicodedata
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path

CSV_PATH = Path("/Users/danicam003/Downloads/huberman_lab_essentials_qna_files/qna_pairs_retrieval.csv")
JSON_PATH = Path("/Users/danicam003/Documents/work/huberman_qa/qa_data.json")
OUT_DIR = Path("/Users/danicam003/Documents/work/huberman_qa_cleaned/analysis")


def normalize(text):
    text = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def tokens(text):
    return set(normalize(text).split())


def similarity(a, b):
    na, nb=normalize(a), normalize(b)
    if not na or not nb:
        return 0.0
    ta=set(na.split()), 
    tb=set(nb.split()),
    jaccard = len(ta & tb) / max(1, len(ta | tb))
    sequence=SequenceMatcher(None, na, nb).ratio()
    containment=(max(len(ta & tb) / max(1, len(ta)), len(ta & tb) / max(1, len(tb))))
    maximum_similarity=max(sequence, jaccard, containment)
    return maximum_similarity


def page_bounds(value):
    nums=[int(x) for x in re.findall(r"\d+", str(value or ""))]
    if not nums:
        return (None, None)
    return (min(nums), max(nums))


GENERIC_EXACT = {
    "why", "why not", "how", "how so", "what", "where", "when", "who", "which",
    "really", "right", "correct", "sorry", "please explain", "do tell", "tell me more",
    "what happened", "what happens", "what else", "what about now", "and then what",
    "so what", "what does this mean", "what does that mean", "is that right",
    "does that make sense", "are you serious", "can you imagine", "for what",
}

GENERIC_PATTERNS = [
    r"^(and|but|so)?\s*(what|why|how|where|when|who|which)\s+(about|then|else|now)\??$",
    r"^(and|but|so)?\s*(is|are|was|were|do|does|did|can|could|would|will|should)\s+(it|that|this|they|there|he|she)\b.{0,28}\??$",
    r"^(and|but|so)?\s*(what|why|how)\s+(is|are|does|do|did|can|could|would)\s+(it|that|this|they|there)\b.{0,25}\??$",
    r"^(and|but|so)?\s*(what do you mean|what are you referring to|where does that fit)\b",
]

PROMOTIONAL_PATTERNS = [
    r"where can (people|listeners|we) find",
    r"social media",
    r"your (book|podcast|website|newsletter|instagram|twitter|x account)",
    r"subscribe",
    r"sponsors?",
    r"promotional",
]

BANTER_PATTERNS = [
    r"would you like (some|a|to)",
    r"can i (ask|tell|say|share)",
    r"do you have (a|any|some)",
    r"are you telling me",
    r"i heard (a|your) podcast",
    r"wasn't that (funny|great|interesting)",
]


def quality_flags(question, answer):
    q = (question or "").strip()
    a = (answer or "").strip()
    nq = normalize(q)
    qw = nq.split()
    aw = normalize(a).split()
    flags=[]
    severe=[]

    if not q or not a:
        severe.append("blank question or answer")
    if len(qw) <= 2:
        severe.append("question is too short to carry a standalone meaning")
    elif len(qw) <= 4 and nq not in {"what is pcos", "what is endometriosis", "what is menopause"}:
        flags.append("very short question")
    if nq in GENERIC_EXACT:
        severe.append("generic or context-dependent question")
    if any(re.search(pattern, nq) for pattern in GENERIC_PATTERNS):
        severe.append("unresolved deictic or follow-up wording")
    if any(re.search(pattern, nq) for pattern in PROMOTIONAL_PATTERNS):
        severe.append("promotional or source-discovery question")
    if any(re.search(pattern, nq) for pattern in BANTER_PATTERNS):
        flags.append("conversational banter or anecdotal setup")
    if len(aw) < 12:
        severe.append("answer is too short for retrieval")
    if q.count("?") > 2:
        flags.append("compound multi-question prompt")
    if len(qw) > 70:
        flags.append("question is excessively long")
    if len(aw) > 450:
        flags.append("answer is excessively long")
    if re.search(r"\b(this|that|these|those|it|they|there|such a thing)\b", nq) and len(qw) < 12:
        flags.append("possible unresolved context reference")
    if not q.endswith("?"):
        flags.append("question punctuation absent")
    if re.search(r"\b(uh|um|you know)\b", nq) and len(qw) < 10:
        flags.append("speech disfluency in short prompt")

    if severe:
        decision = "REMOVE"
    elif len(flags) >= 2:
        decision = "REVIEW"
    else:
        decision = "KEEP"
    return decision, severe + flags


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with CSV_PATH.open(encoding="utf-8-sig", newline="") as handle:
        csv_rows = list(csv.DictReader(handle))
    data = json.loads(JSON_PATH.read_text(encoding="utf-8"))
    workbook_rows = data["qa_pairs"]

    analyzed=[]
    for source, rows in (("CSV", csv_rows), ("Workbook", workbook_rows)):
        for index, row in enumerate(rows, 1):
            question=row.get("question", "")
            answer=row.get("answer", row.get("possible_answer", ""))
            decision, flags = quality_flags(question, answer)
            pages = row.get("pages", row.get("question_page", ""))
            analyzed.append({
                "source": source,
                "source_id": row.get("id", row.get("pair_id", f"{source}-{index}")),
                "pair_type": row.get("pair_type", "dialogue"),
                "question_speaker": row.get("question_speaker", row.get("interviewer", "")),
                "answer_speaker": row.get("answer_speaker", row.get("interviewee", "")),
                "pages": pages,
                "question_words": len(normalize(question).split()),
                "answer_words": len(normalize(answer).split()),
                "decision": decision,
                "flags": "; ".join(flags),
                "question": question,
                "answer_excerpt": " ".join(answer.split()[:45]),
            })

    # Find likely cross-source equivalents using page proximity, speaker compatibility,
    # question similarity and answer-prefix overlap.
    matches = []
    for c in csv_rows:
        c_start, c_end = page_bounds(c.get("pages"))
        best = None
        for w in workbook_rows:
            w_start, w_end = page_bounds(w.get("question_page"))
            if c_start is not None and w_start is not None and (c_end < w_start - 2 or w_end < c_start - 2):
                continue
            if c.get("answer_speaker") and w.get("interviewee") and c["answer_speaker"] != w["interviewee"]:
                continue
            qsim = similarity(c["question"], w["question"])
            asim = similarity(" ".join(c["answer"].split()[:80]), w["possible_answer"])
            score = max(
                0.55 * qsim + 0.45 * asim,
                0.80 * qsim + 0.20 * asim,
                0.30 * qsim + 0.70 * asim,
            )
            if best is None or score > best[0]:
                best = (score, qsim, asim, w)
        if best:
            matches.append({
                "csv_id": c["id"],
                "csv_question": c["question"],
                "workbook_id": best[3]["pair_id"],
                "workbook_question": best[3]["question"],
                "combined_similarity": round(best[0], 4),
                "question_similarity": round(best[1], 4),
                "answer_similarity": round(best[2], 4),
                "pages": c.get("pages", ""),
            })

    fields = list(analyzed[0])
    with (OUT_DIR / "quality_flags.tsv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(analyzed)

    match_fields = list(matches[0]) if matches else []
    with (OUT_DIR / "cross_source_matches.tsv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=match_fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(sorted(matches, key=lambda row: row["combined_similarity"], reverse=True))

    counts = Counter((row["source"], row["decision"]) for row in analyzed)
    print("Quality decisions:")
    for key in sorted(counts):
        print(key, counts[key])
    print("CSV likely duplicates >=0.72:", sum(row["combined_similarity"] >= 0.72 for row in matches))
    print("CSV possible duplicates 0.55-0.72:", sum(0.55 <= row["combined_similarity"] < 0.72 for row in matches))
    print("CSV likely new <0.55:", sum(row["combined_similarity"] < 0.55 for row in matches))


if __name__ == "__main__":
    main()
