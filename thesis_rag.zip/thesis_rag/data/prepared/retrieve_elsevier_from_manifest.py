#!/usr/bin/env python3
"""Retrieve Elsevier XML from API URLs stored in the ScienceDirect manifest.

This script is the step after ``build_sciencedirect_api_manifest.py``. It reads
DOI/PII API URLs, calls the official Elsevier Article Retrieval API, saves
successful XML responses locally, and writes a retrieval audit log.

It expects an API key in either the shell environment or a local .env file:

    ELSEVIER_API_KEY=your_key_here

Do not commit .env files or downloaded subscription XML to a public repository.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse, urlunparse, parse_qsl
from urllib.request import Request, urlopen


DEFAULT_MANIFEST = Path("outputs/api_manifest/sciencedirect_api_manifest.json")
DEFAULT_LOG_CSV = Path("outputs/api_manifest/elsevier_retrieval_log.csv")
DEFAULT_LOG_JSON = Path("outputs/api_manifest/elsevier_retrieval_log.json")


@dataclass
class RetrievalResult:
    retrieved_at: str
    file_name: str
    title: str
    doi: str
    pii: str
    endpoint_type: str
    request_url: str
    http_status_code: int | str
    success: bool
    saved_xml_path: str
    response_bytes: int
    error_message: str
    error_preview: str


def load_dotenv(path: Path = Path(".env")) -> None:
    """Load simple KEY=VALUE pairs without requiring python-dotenv."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def add_query_params(url: str, params: dict[str, str]) -> str:
    if not params:
        return url
    parsed = urlparse(url)
    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    query.update({k: v for k, v in params.items() if v})
    return urlunparse(parsed._replace(query=urlencode(query)))


def response_text_preview(body: bytes, limit: int = 500) -> str:
    text = body.decode("utf-8", errors="replace")
    text = " ".join(text.split())
    return text[:limit]


def choose_endpoints(record: dict[str, Any]) -> list[tuple[str, str]]:
    endpoints: list[tuple[str, str]] = []
    if record.get("elsevier_api_by_doi"):
        endpoints.append(("doi", record["elsevier_api_by_doi"]))
    if record.get("elsevier_api_by_pii"):
        endpoints.append(("pii", record["elsevier_api_by_pii"]))
    return endpoints


def call_elsevier(url: str, api_key: str, accept: str, timeout: int) -> tuple[int, bytes]:
    headers = {
        "X-ELS-APIKey": api_key,
        "Accept": accept,
        "User-Agent": "womens-health-rag-thesis/0.1",
    }
    insttoken = os.getenv("ELSEVIER_INSTTOKEN")
    if insttoken:
        headers["X-ELS-Insttoken"] = insttoken

    request = Request(url, headers=headers, method="GET")
    with urlopen(request, timeout=timeout) as response:
        return response.status, response.read()


def retrieve_record(
    record: dict[str, Any],
    api_key: str,
    accept: str,
    timeout: int,
    view: str,
    force: bool,
    dry_run: bool,
) -> RetrievalResult:
    retrieved_at = datetime.now(timezone.utc).isoformat()
    endpoints = choose_endpoints(record)

    if not endpoints:
        return RetrievalResult(
            retrieved_at=retrieved_at,
            file_name=record.get("file_name", ""),
            title=record.get("title", ""),
            doi=record.get("doi", ""),
            pii=record.get("pii", ""),
            endpoint_type="none",
            request_url="",
            http_status_code="missing_identifier",
            success=False,
            saved_xml_path="",
            response_bytes=0,
            error_message="No DOI or PII endpoint was available in the manifest.",
            error_preview="",
        )

    save_path = Path(record.get("suggested_raw_xml_path", ""))
    if save_path.exists() and not force:
        return RetrievalResult(
            retrieved_at=retrieved_at,
            file_name=record.get("file_name", ""),
            title=record.get("title", ""),
            doi=record.get("doi", ""),
            pii=record.get("pii", ""),
            endpoint_type="cached",
            request_url="",
            http_status_code="cached",
            success=True,
            saved_xml_path=str(save_path),
            response_bytes=save_path.stat().st_size,
            error_message="Skipped because XML already exists. Use --force to download again.",
            error_preview="",
        )

    last_error = ""
    last_preview = ""
    last_status: int | str = "not_called"
    last_endpoint_type = ""
    last_url = ""

    for endpoint_type, base_url in endpoints:
        url = add_query_params(base_url, {"view": view} if view else {})
        last_endpoint_type = endpoint_type
        last_url = url

        if dry_run:
            return RetrievalResult(
                retrieved_at=retrieved_at,
                file_name=record.get("file_name", ""),
                title=record.get("title", ""),
                doi=record.get("doi", ""),
                pii=record.get("pii", ""),
                endpoint_type=endpoint_type,
                request_url=url,
                http_status_code="dry_run",
                success=False,
                saved_xml_path=str(save_path),
                response_bytes=0,
                error_message="Dry run: API was not called.",
                error_preview="",
            )

        try:
            status, body = call_elsevier(url, api_key, accept, timeout)
            last_status = status
            if status == 200:
                save_path.parent.mkdir(parents=True, exist_ok=True)
                save_path.write_bytes(body)
                return RetrievalResult(
                    retrieved_at=retrieved_at,
                    file_name=record.get("file_name", ""),
                    title=record.get("title", ""),
                    doi=record.get("doi", ""),
                    pii=record.get("pii", ""),
                    endpoint_type=endpoint_type,
                    request_url=url,
                    http_status_code=status,
                    success=True,
                    saved_xml_path=str(save_path),
                    response_bytes=len(body),
                    error_message="",
                    error_preview="",
                )
            last_error = f"Unexpected status code: {status}"
            last_preview = response_text_preview(body)
        except HTTPError as error:
            body = error.read()
            last_status = error.code
            last_error = str(error)
            last_preview = response_text_preview(body)
            if error.code in {400, 404}:
                continue
            break
        except URLError as error:
            last_status = "network_error"
            last_error = str(error)
            break

    return RetrievalResult(
        retrieved_at=retrieved_at,
        file_name=record.get("file_name", ""),
        title=record.get("title", ""),
        doi=record.get("doi", ""),
        pii=record.get("pii", ""),
        endpoint_type=last_endpoint_type,
        request_url=last_url,
        http_status_code=last_status,
        success=False,
        saved_xml_path=str(save_path),
        response_bytes=0,
        error_message=last_error,
        error_preview=last_preview,
    )


def write_logs(results: list[RetrievalResult], csv_path: Path, json_path: Path) -> None:
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(RetrievalResult.__dataclass_fields__.keys())
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(asdict(result) for result in results)

    json_path.write_text(
        json.dumps([asdict(result) for result in results], indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--log-csv", type=Path, default=DEFAULT_LOG_CSV)
    parser.add_argument("--log-json", type=Path, default=DEFAULT_LOG_JSON)
    parser.add_argument("--limit", type=int, default=0, help="Maximum number of records to attempt. 0 means all.")
    parser.add_argument("--start", type=int, default=0, help="Zero-based start index in the manifest.")
    parser.add_argument("--sleep", type=float, default=0.5, help="Seconds to wait between API calls.")
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--accept", default="application/xml")
    parser.add_argument("--view", default="", help="Elsevier API view parameter. Empty string omits the view parameter.")
    parser.add_argument("--force", action="store_true", help="Overwrite existing saved XML files.")
    parser.add_argument("--dry-run", action="store_true", help="Prepare URLs and logs without calling the API.")
    args = parser.parse_args()

    load_dotenv()
    api_key = os.getenv("ELSEVIER_API_KEY", "").strip()
    if not api_key and not args.dry_run:
        raise SystemExit(
            "Missing ELSEVIER_API_KEY. Add it to a local .env file or export it in your shell. "
            "Use --dry-run if you only want to preview API calls."
        )

    records = json.loads(args.manifest.read_text(encoding="utf-8"))
    records = [record for record in records if record.get("retrieval_status") == "ready_for_api_call"]
    if args.start:
        records = records[args.start :]
    if args.limit:
        records = records[: args.limit]

    results: list[RetrievalResult] = []
    for index, record in enumerate(records, start=1):
        result = retrieve_record(
            record=record,
            api_key=api_key,
            accept=args.accept,
            timeout=args.timeout,
            view=args.view,
            force=args.force,
            dry_run=args.dry_run,
        )
        results.append(result)
        label = "OK" if result.success else "PREVIEW" if args.dry_run else "FAILED"
        print(f"{index}/{len(records)} | {result.http_status_code} | {label} | {result.title[:80]}")
        if index < len(records) and not args.dry_run:
            time.sleep(args.sleep)

    write_logs(results, args.log_csv, args.log_json)
    successes = sum(result.success for result in results)
    print(f"Successful retrievals: {successes}/{len(results)}")
    print(f"Wrote log CSV: {args.log_csv}")
    print(f"Wrote log JSON: {args.log_json}")


if __name__ == "__main__":
    main()
