import unittest

from womens_health_rag.agents import RouterAgent, SafetyAgent
from womens_health_rag.knowledge_graph import GraphEdge, GraphNode, KnowledgeGraph, NodeType, Relation
from womens_health_rag.graph_extraction import GraphCandidate
from womens_health_rag.models import AgentName, EvidenceUnit, PipelineState
from womens_health_rag.orchestrator import MultiAgentRAG
from womens_health_rag.retrieval import EvidenceOnlyGenerator, InMemoryRetriever


class SystemTests(unittest.TestCase):
    def setUp(self):
        self.evidence = [
            EvidenceUnit("E1", "Sleep loss may worsen fatigue and mood.", "S1", "paper", AgentName.SLEEP),
            EvidenceUnit("E2", "PMDD can involve severe mood symptoms.", "S2", "paper", AgentName.HORMONAL_HEALTH),
            EvidenceUnit("E3", "Anxiety symptoms can have multiple contributors.", "S3", "paper", AgentName.MENTAL_HEALTH),
        ]

    def test_router_is_multi_label(self):
        routed = RouterAgent().route("Can poor sleep make my anxiety and PMS symptoms worse?")
        self.assertIn(AgentName.SLEEP, routed)
        self.assertIn(AgentName.MENTAL_HEALTH, routed)
        self.assertIn(AgentName.HORMONAL_HEALTH, routed)

    def test_pipeline_returns_provenance(self):
        rag = MultiAgentRAG(InMemoryRetriever(self.evidence), EvidenceOnlyGenerator(), top_k_per_agent=1)
        result = rag.answer("Can poor sleep affect anxiety?")
        self.assertTrue(result.final_answer)
        self.assertIn("E1", result.citations)

    def test_safety_precheck(self):
        state = PipelineState("I am thinking about suicide")
        self.assertIn("urgent_safety_language", SafetyAgent().precheck(state))

    def test_graph_requires_provenance_and_filters_confidence(self):
        graph = KnowledgeGraph()
        graph.add_node(GraphNode("fatigue", NodeType.SYMPTOM, "fatigue"))
        graph.add_node(GraphNode("sleep_loss", NodeType.CONDITION, "sleep loss"))
        edge = GraphEdge(
            "G1", "sleep_loss", Relation.ASSOCIATED_WITH, "fatigue", ("E1",),
            source_quality=0.9, extraction_confidence=0.9, entailment_score=0.9,
            corroboration_count=2, human_reviewed=True,
        )
        graph.add_edge(edge)
        self.assertEqual([edge], graph.confident_edges(0.7))
        with self.assertRaises(ValueError):
            graph.add_edge(GraphEdge(
                "G2", "sleep_loss", Relation.ASSOCIATED_WITH, "fatigue", (),
                0.9, 0.9, 0.9,
            ))

    def test_association_cannot_be_promoted_to_intervention(self):
        candidate = GraphCandidate(
            "stress", Relation.MAY_BE_SUPPORTED_BY, "supplement_x", ("E1",),
            0.8, 0.8, 0.8, statement_type="association",
        )
        with self.assertRaises(ValueError):
            candidate.validate()


if __name__ == "__main__":
    unittest.main()
