#!/usr/bin/env python3
"""Model 4: Graph-supported multi-agent passage RAG.

This script evaluates the addition of a knowledge/symptom graph while keeping
the fixed retrieval pipeline unchanged:

1. ClinicalBERT still embeds queries and passages.
2. Qdrant is still the vector database.
3. MiniLM cross-encoder still reranks candidates.
4. Qwen3.5-0.8B still generates the final answer.

The graph does not replace Qdrant. It adds a controlled expansion step before
retrieval. For example, if the query contains "fatigue", the graph may expand
the retrieval query with connected concepts such as "sleep disturbance",
"PMS", "iron deficiency", or "depression", but only if the graph edges pass
the confidence threshold.

Expected graph JSON format
--------------------------
{
  "nodes": [
    {
      "id": "fatigue",
      "label": "fatigue",
      "synonyms": ["tiredness", "exhaustion"]
    }
  ],
  "edges": [
    {
      "source": "fatigue",
      "target": "sleep_disturbance",
      "relation": "associated_with",
      "confidence": 0.82,
      "evidence_ids": ["paper001_chunk_0007"]
    }
  ]
}
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from project_paths import PROJECT_ROOT, SCRIPT_DIR

CURRENT_DIR = SCRIPT_DIR
PROJECT_DIR = PROJECT_ROOT
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from multi_agent_passage_rag import (  # noqa: E402
    AGENT_PROMPTS,
    AgentFinding,
    build_agent_prompt,
    build_synthesis_prompt,
    route_agents,
    safety_precheck,
)
from multi_agent_passage_rag import UNROUTED_DOMAIN  # noqa: E402
from single_agent_rag_baseline import (  # noqa: E402
    FixedRAGSettings,
    MiniLMCrossEncoderReranker,
    QdrantVectorStore,
    QwenGenerator,
    TransformerMeanPoolEmbedder,
    citation_report,
    ensure_citations,
    load_jsonl,
    normalise_domain,
    settings_with_overrides,
    standardise_passage_record,
)


@dataclass
class GraphNode:
    node_id: str
    label: str
    synonyms: list[str] = field(default_factory=list)


# Relations that are safe to traverse in both directions. Everything else is
# treated as directed: expanding "X may_be_supported_by Y" backwards from Y to X
# asserts something the edge never claimed. The old neighbours() walked every
# edge in both directions regardless of relation.
SYMMETRIC_RELATIONS = {"associated_with", "co_occurs_with", "related_to"}


@dataclass
class GraphEdge:
    source: str
    target: str
    relation: str
    confidence: float
    evidence_ids: list[str] = field(default_factory=list)


class KnowledgeGraphExpander:
    """Small graph reader and query expander for the graph ablation."""

    def __init__(
        self,
        graph_path: Path | None,
        threshold: float = 0.91,
        max_terms: int = 8,
        allow_empty: bool = False,
    ):
        self.threshold = threshold
        self.max_terms = max_terms
        self.nodes: dict[str, GraphNode] = {}
        self.edges: list[GraphEdge] = []
        self.stats: dict[str, Any] = {
            "graph_path": str(graph_path) if graph_path else "",
            "edges_in_file": 0,
            "edges_below_threshold": 0,
            "edges_active": 0,
            "nodes_in_file": 0,
            "threshold": threshold,
            # Edges are automatically extracted co-occurrence candidates. None of
            # them are clinically reviewed, and nothing in this pipeline gates on
            # review status: this is an experimental retrieval-expansion
            # mechanism, not a validated clinical knowledge base. Recorded here
            # so every run output states it.
            "edges_clinically_reviewed": False,
        }

        if graph_path and graph_path.exists():
            self.load(graph_path)

        # A missing file, a threshold nothing clears, or an unreviewed graph all
        # used to fail silently, leaving this model behaviourally identical to
        # plain multi-agent RAG. The experiment would then report "the graph
        # does not help" for a graph that was never loaded.
        if not self.edges and not allow_empty:
            raise RuntimeError(
                "Graph expansion is active but no usable edges were loaded.\n"
                f"  path: {graph_path} (exists: {bool(graph_path and graph_path.exists())})\n"
                f"  nodes in file: {self.stats['nodes_in_file']}\n"
                f"  edges in file: {self.stats['edges_in_file']}\n"
                f"  dropped below confidence {threshold}: {self.stats['edges_below_threshold']}\n"
                "Lower --graph-threshold, or pass --allow-empty-graph if you deliberately "
                "want a no-op graph control arm."
            )

    def load(self, graph_path: Path) -> None:
        data = json.loads(graph_path.read_text(encoding="utf-8"))
        raw_nodes = data.get("nodes", [])
        self.stats["nodes_in_file"] = len(raw_nodes)
        for raw_node in raw_nodes:
            node_id = str(raw_node.get("id") or raw_node.get("node_id"))
            label = str(raw_node.get("label") or raw_node.get("canonical_name") or node_id)
            synonyms = [str(item) for item in raw_node.get("synonyms", [])]
            self.nodes[node_id] = GraphNode(node_id=node_id, label=label, synonyms=synonyms)

        raw_edges = data.get("edges", [])
        self.stats["edges_in_file"] = len(raw_edges)
        for raw_edge in raw_edges:
            confidence = float(raw_edge.get("confidence", raw_edge.get("score", 0.0)))
            if confidence < self.threshold:
                self.stats["edges_below_threshold"] += 1
                continue
            self.edges.append(
                GraphEdge(
                    source=str(raw_edge.get("source") or raw_edge.get("source_node")),
                    target=str(raw_edge.get("target") or raw_edge.get("target_node")),
                    relation=str(raw_edge.get("relation", "associated_with")),
                    confidence=confidence,
                    evidence_ids=[str(item) for item in raw_edge.get("evidence_ids", [])],
                )
            )
        self.stats["edges_active"] = len(self.edges)

    def match_query_nodes(self, query: str) -> set[str]:
        """Find graph nodes whose label or synonym appears in the query.

        Matching is on word boundaries. Plain substring matching made "iron"
        match "environment" and "cycle" match "bicycle", which seeded expansion
        from concepts the query never mentioned.
        """
        lowered = query.lower()
        matches: set[str] = set()
        for node in self.nodes.values():
            for name in (node.label, *node.synonyms):
                needle = (name or "").strip().lower()
                if not needle:
                    continue
                if re.search(rf"(?<![a-z0-9]){re.escape(needle)}(?![a-z0-9])", lowered):
                    matches.add(node.node_id)
                    break
        return matches

    def neighbours(self, node_ids: set[str]) -> list[tuple[GraphEdge, GraphNode]]:
        """Walk one hop out from the seed nodes, respecting edge direction."""
        results: list[tuple[GraphEdge, GraphNode]] = []
        for edge in self.edges:
            symmetric = edge.relation in SYMMETRIC_RELATIONS
            if edge.source in node_ids and edge.target in self.nodes:
                results.append((edge, self.nodes[edge.target]))
            elif symmetric and edge.target in node_ids and edge.source in self.nodes:
                results.append((edge, self.nodes[edge.source]))
        results.sort(key=lambda pair: (-pair[0].confidence, pair[1].label))
        return results

    def expand_query(self, query: str) -> tuple[str, list[str], list[dict[str, Any]]]:
        """Return an expanded query plus audit information.

        The original user query is preserved. Added terms are appended only for
        retrieval, and MiniLM later reranks candidates against the original query
        so weak graph expansions can be filtered out.
        """
        seed_nodes = self.match_query_nodes(query)
        related = self.neighbours(seed_nodes)

        added_terms: list[str] = []
        audit_edges: list[dict[str, Any]] = []
        seen_edges: set[tuple[str, str, str]] = set()
        for edge, node in related:
            if len(added_terms) >= self.max_terms:
                break
            # Only record an audit entry for an edge that actually contributes a
            # term. The old loop appended audit rows for skipped edges and could
            # log more edges than terms it added.
            if node.label.lower() in query.lower() or node.label in added_terms:
                continue
            key = (edge.source, edge.target, node.label)
            if key in seen_edges:
                continue
            seen_edges.add(key)
            added_terms.append(node.label)
            audit_edges.append(
                {
                    "source": edge.source,
                    "target": edge.target,
                    "relation": edge.relation,
                    "confidence": edge.confidence,
                    "evidence_ids": edge.evidence_ids,
                    "added_term": node.label,
                }
            )

        expanded_query = query if not added_terms else f"{query} Related graph concepts: {', '.join(added_terms)}"
        return expanded_query, added_terms, audit_edges


class GraphSupportedMultiAgentRAG:
    """Multi-agent passage RAG with graph-based query expansion."""

    def __init__(
        self,
        settings: FixedRAGSettings,
        graph_path: Path | None,
        graph_threshold: float,
        route_on: str = "original",
        max_terms: int = 8,
        allow_empty_graph: bool = False,
    ):
        self.settings = settings
        # route_on="original" keeps this arm a clean ablation of graph query
        # expansion. Routing on the expanded query changes which agents run as
        # well as what they retrieve, so the arm would differ from plain
        # multi-agent RAG in two ways at once and the effect could not be
        # attributed to the graph. Use route_on="expanded" as a separate arm.
        if route_on not in {"original", "expanded"}:
            raise ValueError("route_on must be 'original' or 'expanded'")
        self.route_on = route_on
        self.graph = KnowledgeGraphExpander(
            graph_path,
            threshold=graph_threshold,
            max_terms=max_terms,
            allow_empty=allow_empty_graph,
        )
        self.embedder = TransformerMeanPoolEmbedder(settings.embedding_model)
        self.store = QdrantVectorStore(settings, settings.passage_collection, self.embedder)
        self.reranker = MiniLMCrossEncoderReranker(settings.reranker_model)
        self.generator = QwenGenerator(settings.generator_model, settings.max_new_tokens)

    def index_passages(self, passage_path: Path, recreate: bool = False) -> None:
        raw_records = load_jsonl(passage_path)
        records = [standardise_passage_record(record) for record in raw_records]
        self.store.index_records(records, recreate=recreate)

    def retrieve_for_agent(
        self, original_query: str, expanded_query: str, agent_domain: str
    ) -> tuple[list[dict[str, Any]], int]:
        # Vector search uses the expanded graph-aware query.
        retrieved = self.store.search(
            query=expanded_query,
            top_k=self.settings.retrieve_k,
            agent_domain=None if agent_domain == UNROUTED_DOMAIN else normalise_domain(agent_domain),
        )

        # Reranking uses the original user query. This keeps the graph as a
        # candidate-expansion mechanism rather than letting it dominate the final
        # evidence selection.
        return self.reranker.rerank(original_query, retrieved, top_k=self.settings.final_k), len(retrieved)

    def run_agent(self, original_query: str, expanded_query: str, agent_domain: str) -> AgentFinding:
        evidence, n_retrieved = self.retrieve_for_agent(original_query, expanded_query, agent_domain)
        answer = self.generator.generate(
            system_prompt=AGENT_PROMPTS[agent_domain],
            user_prompt=build_agent_prompt(original_query, agent_domain, evidence),
        )
        answer, _ = ensure_citations(answer, evidence)
        return AgentFinding(
            agent_domain=agent_domain,
            answer=answer,
            evidence=evidence,
            n_retrieved=n_retrieved,
            n_after_rerank=len(evidence),
        )

    def synthesis_budget(self, n_agents: int) -> int:
        if self.settings.synthesis_k > 0:
            return self.settings.synthesis_k
        return self.settings.final_k * max(1, n_agents)

    def answer(self, query: str) -> dict[str, Any]:
        safety_flags = safety_precheck(query)
        expanded_query, added_terms, graph_audit = self.graph.expand_query(query)

        routing_query = expanded_query if self.route_on == "expanded" else query
        routed_agents = route_agents(routing_query)
        router_miss = not routed_agents
        active_agents = routed_agents or [UNROUTED_DOMAIN]
        findings = [self.run_agent(query, expanded_query, domain) for domain in active_agents]

        evidence_by_id: dict[str, dict[str, Any]] = {}
        for finding in findings:
            for item in finding.evidence:
                evidence_by_id.setdefault(str(item.get("record_id")), item)
        synthesis_evidence = sorted(
            evidence_by_id.values(),
            key=lambda item: (
                -float(item.get("rerank_score") or 0.0),
                -float(item.get("vector_score") or 0.0),
                str(item.get("record_id") or ""),
            ),
        )[: self.synthesis_budget(len(active_agents))]

        final_answer = self.generator.generate(
            system_prompt=(
                "You are the Synthesizer Agent for graph-supported RAG. "
                "Use graph-expanded evidence cautiously and distinguish associations from causes."
            ),
            user_prompt=build_synthesis_prompt(query, findings, synthesis_evidence),
        )
        final_answer, fallback_used = ensure_citations(final_answer, synthesis_evidence)

        return {
            "model": "graph_supported_multi_agent_passage_rag",
            "query": query,
            "expanded_query": expanded_query,
            "graph_added_terms": added_terms,
            "n_graph_added_terms": len(added_terms),
            "graph_expansion_applied": bool(added_terms),
            "graph_audit": graph_audit,
            "graph_stats": self.graph.stats,
            "route_on": self.route_on,
            "routed_agents": routed_agents,
            "active_agents": active_agents,
            "router_miss": router_miss,
            "starved_agents": [f.agent_domain for f in findings if f.n_after_rerank == 0],
            "n_agents": len(active_agents),
            "safety_flags": safety_flags,
            "agent_findings": [finding.__dict__ for finding in findings],
            "answer": final_answer,
            "evidence": synthesis_evidence,
            "n_evidence_to_generator": len(synthesis_evidence),
            "synthesis_k": self.synthesis_budget(len(active_agents)),
            "citation_fallback_used": fallback_used,
            "citation_report": citation_report(final_answer, synthesis_evidence),
        }

    def close(self) -> None:
        self.store.close()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run graph-supported multi-agent passage RAG.")
    parser.add_argument("--passages", type=Path, default=PROJECT_DIR / "data" / "prepared" / "passages.jsonl")
    parser.add_argument("--graph", type=Path, default=PROJECT_DIR / "data" / "prepared" / "knowledge_graph.json")
    parser.add_argument("--graph-threshold", type=float, default=0.91)
    parser.add_argument("--graph-max-terms", type=int, default=8)
    parser.add_argument(
        "--route-on",
        choices=("original", "expanded"),
        default="original",
        help="Which query the keyword router sees. Keep 'original' for a clean graph ablation.",
    )
    parser.add_argument("--allow-empty-graph", action="store_true")
    parser.add_argument("--query", required=True)
    parser.add_argument("--embedding-model", default=None, help="Hugging Face encoder used for retrieval embeddings.")
    parser.add_argument("--collection-suffix", default=None, help="Optional suffix for Qdrant collection names.")
    parser.add_argument("--reindex", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    settings = settings_with_overrides(
        embedding_model=args.embedding_model,
        collection_suffix=args.collection_suffix,
    )
    rag = GraphSupportedMultiAgentRAG(
        settings,
        args.graph,
        args.graph_threshold,
        route_on=args.route_on,
        max_terms=args.graph_max_terms,
        allow_empty_graph=args.allow_empty_graph,
    )

    if args.reindex:
        rag.index_passages(args.passages, recreate=True)
    elif rag.store.count_points() == 0:
        if not args.passages.exists():
            raise FileNotFoundError(
                f"No indexed passages found and {args.passages} does not exist. "
                "Pass --passages with your prepared JSONL file and use --reindex."
            )
        rag.index_passages(args.passages, recreate=False)

    try:
        result = rag.answer(args.query)
    finally:
        rag.close()
    json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
    print()


if __name__ == "__main__":
    main()
