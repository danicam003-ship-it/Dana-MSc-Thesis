#!/usr/bin/env python3
"""Run one RAG experiment over the held-out evaluation questions."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


from project_paths import PROJECT_ROOT, SCRIPT_DIR


CURRENT_DIR = SCRIPT_DIR
PROJECT_DIR = PROJECT_ROOT
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from graph_supported_rag import GraphSupportedMultiAgentRAG  # noqa: E402
from multi_agent_passage_rag import MultiAgentPassageRAG  # noqa: E402
from multi_agent_question_to_question_rag import MultiAgentQuestionToQuestionRAG  # noqa: E402
from single_agent_rag_baseline import (  # noqa: E402
    FixedRAGSettings,
    SingleAgentRAGBaseline,
    load_jsonl,
    model_slug,
    settings_with_overrides,
)


WARMUP_QUERY = "warmup query for timing stability, results are discarded"


def file_fingerprint(path: Path) -> str:
    """Short content hash of a prepared data file.

    Recorded in every result row so that two arms compared against each other
    can be proven to have run over the same corpus. Without it, a corpus edited
    between arms produces a silently invalid comparison.
    """
    if not path or not path.exists():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()[:16]


def git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"], cwd=str(PROJECT_DIR), stderr=subprocess.DEVNULL
        ).decode().strip()
    except Exception:
        return ""


def environment_versions() -> dict[str, str]:
    versions = {"python": platform.python_version()}
    for name in ("torch", "transformers", "sentence_transformers", "qdrant_client"):
        try:
            module = __import__(name)
            versions[name] = str(getattr(module, "__version__", "unknown"))
        except Exception:
            versions[name] = "not installed"
    try:
        import torch

        versions["cuda"] = torch.version.cuda or "cpu"
        versions["gpu"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu"
    except Exception:
        versions["cuda"] = "unknown"
        versions["gpu"] = "unknown"
    return versions


def seed_everything(seed: int) -> None:
    """Greedy decoding is already deterministic, but seed anyway.

    Tokenisation, any sampling path, and library-internal shuffling can all
    introduce run-to-run variation that would otherwise be indistinguishable
    from a real difference between architectures.
    """
    import random

    random.seed(seed)
    try:
        import numpy as np

        np.random.seed(seed)
    except Exception:
        pass
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except Exception:
        pass


def load_questions(path: Path, limit: int | None) -> list[dict[str, Any]]:
    questions = load_jsonl(path)
    return questions[:limit] if limit else questions


def build_model(args: argparse.Namespace, settings: FixedRAGSettings):
    if args.model == "single_agent":
        return SingleAgentRAGBaseline(settings)
    if args.model == "multi_agent_passage":
        return MultiAgentPassageRAG(settings)
    if args.model == "question_to_question":
        return MultiAgentQuestionToQuestionRAG(settings)
    if args.model == "graph_supported":
        return GraphSupportedMultiAgentRAG(
            settings,
            args.graph,
            args.graph_threshold,
            route_on=args.route_on,
            max_terms=args.graph_max_terms,
            allow_empty_graph=args.allow_empty_graph,
        )
    raise ValueError(args.model)


def run_label(args: argparse.Namespace, settings: FixedRAGSettings) -> str:
    """Result label that reflects every override, not only the embedder.

    The old version renamed the run only when the embedding model changed, so
    two runs that differed by generator or reranker collapsed into one row in
    the summary table.
    """
    base = FixedRAGSettings()
    parts = []
    if settings.embedding_model != base.embedding_model:
        parts.append(f"emb_{model_slug(settings.embedding_model)}")
    if settings.generator_model != base.generator_model:
        parts.append(f"gen_{model_slug(settings.generator_model)}")
    if settings.reranker_model != base.reranker_model:
        parts.append(f"rr_{model_slug(settings.reranker_model)}")
    if args.model == "graph_supported" and args.route_on != "original":
        parts.append(f"route_{args.route_on}")
    if settings.synthesis_k <= 0:
        parts.append("unbounded_synthesis")
    return "__".join(parts)


def verify_index(model: Any, args: argparse.Namespace) -> dict[str, Any]:
    """Confirm the index matches the corpus file before answering anything."""
    data_path = args.qna if args.model == "question_to_question" else args.passages
    expected = len(load_jsonl(data_path)) if data_path.exists() else 0
    actual = model.store.count_points()
    if expected and actual != expected:
        raise RuntimeError(
            f"Index integrity check failed for collection '{model.store.collection_name}'.\n"
            f"  expected points (rows in {data_path}): {expected}\n"
            f"  points in collection: {actual}\n"
            "A partially built collection is not zero, so the usual 'index if empty' check "
            "cannot catch it. Rerun with --reindex to rebuild."
        )
    return {"collection": model.store.collection_name, "expected_points": expected, "actual_points": actual}


def ensure_index(model: Any, args: argparse.Namespace) -> None:
    if args.model == "question_to_question":
        if args.reindex or model.store.count_points() == 0:
            model.index_qna_pairs(args.qna, recreate=args.reindex)
        return
    if args.reindex or model.store.count_points() == 0:
        model.index_passages(args.passages, recreate=args.reindex)


def completed_test_ids(path: Path) -> set[str]:
    if not path.exists():
        return set()
    done = set()
    for record in load_jsonl(path):
        if record.get("test_id") and not record.get("error"):
            done.add(str(record["test_id"]))
    return done


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run one experiment model over evaluation questions.")
    parser.add_argument(
        "--model",
        choices=["single_agent", "multi_agent_passage", "question_to_question", "graph_supported"],
        required=True,
    )
    parser.add_argument("--questions", type=Path, default=PROJECT_DIR / "data" / "prepared" / "evaluation_questions.jsonl")
    parser.add_argument("--passages", type=Path, default=PROJECT_DIR / "data" / "prepared" / "passages.jsonl")
    parser.add_argument("--qna", type=Path, default=PROJECT_DIR / "data" / "prepared" / "qna_pairs.jsonl")
    parser.add_argument("--graph", type=Path, default=PROJECT_DIR / "data" / "prepared" / "knowledge_graph.json")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--embedding-model", default=None)
    parser.add_argument("--generator-model", default=None)
    parser.add_argument("--reranker-model", default=None)
    parser.add_argument("--qdrant-path", default=None)
    parser.add_argument("--collection-suffix", default=None)
    parser.add_argument("--graph-threshold", type=float, default=0.91)
    parser.add_argument("--graph-max-terms", type=int, default=8)
    parser.add_argument("--route-on", choices=("original", "expanded"), default="original")
    parser.add_argument("--allow-empty-graph", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--reindex", action="store_true")
    parser.add_argument("--continue-on-error", action="store_true")
    parser.add_argument("--seed", type=int, default=20260719)
    parser.add_argument("--run-id", default=None, help="Shared identifier across the arms of one sweep.")
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Append to an existing output file, skipping questions that already completed without error.",
    )
    parser.add_argument("--no-warmup", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    seed_everything(args.seed)

    settings = settings_with_overrides(
        embedding_model=args.embedding_model,
        generator_model=args.generator_model,
        reranker_model=args.reranker_model,
        qdrant_path=args.qdrant_path,
        collection_suffix=args.collection_suffix,
    )

    run_id = args.run_id or uuid.uuid4().hex[:12]
    corpus_path = args.qna if args.model == "question_to_question" else args.passages
    provenance = {
        "run_id": run_id,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "git_commit": git_commit(),
        "seed": args.seed,
        "corpus_fingerprint": file_fingerprint(corpus_path),
        "questions_fingerprint": file_fingerprint(args.questions),
        "graph_fingerprint": file_fingerprint(args.graph) if args.model == "graph_supported" else "",
        "environment": environment_versions(),
    }

    model = build_model(args, settings)
    label_suffix = run_label(args, settings)
    written = 0

    try:
        ensure_index(model, args)
        index_info = verify_index(model, args)
        provenance["index"] = index_info
        print(json.dumps({"provenance": provenance}, indent=2))

        questions = load_questions(args.questions, args.limit)
        already_done = completed_test_ids(args.output) if args.resume else set()
        if already_done:
            print(f"[resume] skipping {len(already_done)} already-completed questions")

        # One discarded call so the first timed question does not absorb model
        # warmup, kernel compilation and cache population.
        if not args.no_warmup:
            try:
                model.answer(WARMUP_QUERY)
            except Exception as exc:  # a warmup failure must not kill the run
                print(f"[warn] warmup call failed: {type(exc).__name__}: {exc}")

        mode = "a" if (args.resume and args.output.exists()) else "w"
        with args.output.open(mode, encoding="utf-8") as handle:
            for item in questions:
                test_id = str(item.get("test_id") or "")
                if test_id and test_id in already_done:
                    continue

                generator = getattr(model, "generator", None)
                if generator is not None and hasattr(generator, "reset_usage"):
                    generator.reset_usage()

                start = time.perf_counter()
                try:
                    result = model.answer(item["query"])
                    result["error"] = ""
                except Exception as exc:
                    if not args.continue_on_error:
                        raise
                    result = {
                        "model": args.model,
                        "query": item.get("query", ""),
                        "answer": "",
                        "evidence": [],
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                result["latency_seconds"] = round(time.perf_counter() - start, 3)

                if generator is not None and hasattr(generator, "usage"):
                    result.update(generator.usage())

                result["test_id"] = item.get("test_id")
                result["expected_agent_domain"] = item.get("agent_domain")
                result["expected_concept_tags"] = item.get("concept_tags", [])
                result["expected_symptom_tags"] = item.get("symptom_tags", [])
                result["reference_answer"] = item.get("reference_answer", "")
                result["heldout_qa_id"] = item.get("heldout_qa_id", "")
                result["embedding_model"] = settings.embedding_model
                result["generator_model"] = settings.generator_model
                result["reranker_model"] = settings.reranker_model
                result["passage_collection"] = settings.passage_collection
                result["qa_collection"] = settings.qa_collection
                result["retrieve_k"] = settings.retrieve_k
                result["final_k"] = settings.final_k
                result["synthesis_k"] = settings.synthesis_k
                result["arm"] = args.model
                result["run_id"] = run_id
                result["corpus_fingerprint"] = provenance["corpus_fingerprint"]
                result["questions_fingerprint"] = provenance["questions_fingerprint"]
                result["git_commit"] = provenance["git_commit"]
                if label_suffix:
                    result["model"] = f"{result.get('model', args.model)}__{label_suffix}"

                handle.write(json.dumps(result, ensure_ascii=False, sort_keys=True) + "\n")
                handle.flush()
                written += 1
    finally:
        close = getattr(model, "close", None)
        if callable(close):
            close()

    provenance["finished_at"] = datetime.now(timezone.utc).isoformat()
    provenance["rows_written"] = written
    args.output.with_suffix(".provenance.json").write_text(
        json.dumps(provenance, indent=2), encoding="utf-8"
    )
    print(f"Wrote {written} results to {args.output}")


if __name__ == "__main__":
    main()
