
"""Compute comparison metrics for RAG experiment outputs.

retrieved evidence is counted as
relevant when it overlaps with the held-out symptom/concept tags of the
evaluation question. it handles unbalanced domains with macro
averages.

"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from project_paths import OUTPUTS_DIR
STOPWORDS = {
    "a", "about", "after", "all", "also", "an", "and", "any", "are", "as", "at", "be", "because",
    "been", "but", "by", "can", "could", "do", "does", "for", "from", "had", "has", "have", "how",
    "i", "if", "in", "into", "is", "it", "its", "may", "might", "more", "most", "no", "not", "of",
    "on", "one", "or", "other", "our", "out", "over", "should", "so", "some", "such", "than",
    "that", "the", "their", "them", "then", "there", "these", "they", "this", "those", "to", "up",
    "was", "we", "were", "what", "when", "which", "while", "who", "will", "with", "would", "you",
    "your",
}

FALLBACK_CITATION_PREFIX = "Evidence used:"


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    records = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def strip_citation_artifacts(text: str) -> str:
    """Remove bracketed IDs and the appended fallback block before text scoring.

    ensure_citations() appends "Evidence used: [id] [id]" when the model emitted
    no valid citation. Leaving that in inflates any overlap metric with tokens
    that came from the harness rather than from the model, and it does so
    unevenly across arms because the arms differ in how often the fallback
    fires.
    """
    text = text or ""
    cut = text.find(FALLBACK_CITATION_PREFIX)
    if cut != -1:
        text = text[:cut]
    return re.sub(r"\[[^\]]{1,120}\]", " ", text)


def tokens(text: str, drop_stopwords: bool = True) -> list[str]:
    words = re.findall(r"[a-z0-9]+", (text or "").lower())
    return [word for word in words if word not in STOPWORDS] if drop_stopwords else words


def lexical_f1(answer: str, reference: str) -> float:
    answer_counts = Counter(tokens(strip_citation_artifacts(answer)))
    reference_counts = Counter(tokens(reference))
    if not answer_counts or not reference_counts:
        return 0.0
    overlap = sum((answer_counts & reference_counts).values())
    precision = overlap / sum(answer_counts.values())
    recall = overlap / sum(reference_counts.values())
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


def dcg(relevances: list[int]) -> float:
    return sum(rel / math.log2(index + 2) for index, rel in enumerate(relevances))


def ndcg_at_k(relevances: list[int], k: int) -> float:
    """nDCG over the retrieved list only.

    The ideal ranking is taken from what was retrieved, so this measures
    ordering quality within the returned set. It cannot see relevant documents
    the system failed to retrieve at all. Report it alongside hit@k, and do not
    read it as a recall-sensitive measure.
    """
    observed = dcg(relevances[:k])
    ideal = dcg(sorted(relevances, reverse=True)[:k])
    return observed / ideal if ideal else 0.0


def evidence_items(result: dict[str, Any]) -> list[dict[str, Any]]:
    evidence = result.get("evidence") or []
    if evidence:
        return [item for item in evidence if isinstance(item, dict)]

    flattened = []
    for finding in result.get("agent_findings", []) or []:
        for item in finding.get("evidence", []) or []:
            if isinstance(item, dict):
                flattened.append(item)
    return flattened


def is_relevant(item: dict[str, Any], expected_domain: str, expected_tags: set[str], mode: str) -> int:
    item_tags = {
        str(tag).lower()
        for tag in (item.get("concept_tags") or []) + (item.get("symptom_tags") or [])
        if str(tag).strip()
    }
    if expected_tags and item_tags.intersection(expected_tags):
        return 1
    if mode == "tags_or_domain":
        domain = str(item.get("agent_domain") or item.get("primary_agent") or "").lower()
        if domain and domain == expected_domain:
            return 1
    return 0


def citation_metrics(result: dict[str, Any]) -> dict[str, float]:
    """Citation validity, preferring the report the model script already wrote.

    Counting brackets says nothing about grounding: "[1]" and "[source]" both
    match. What matters is whether the bracketed token names a record that was
    actually retrieved for that answer.
    """
    report = result.get("citation_report")
    if isinstance(report, dict) and report:
        n_cited = float(report.get("n_citations") or 0.0)
        n_invalid = float(report.get("n_invalid_citations") or 0.0)
        return {
            "citation_count": n_cited,
            "citation_validity": float(report.get("citation_validity") or 0.0),
            "hallucinated_citations": n_invalid,
            "hallucinated_citation_rate": (n_invalid / n_cited) if n_cited else 0.0,
            "distinct_valid_citations": float(report.get("distinct_valid_citations") or 0.0),
            "citation_fallback_used": 1.0 if result.get("citation_fallback_used") else 0.0,
        }

    # Fallback for output produced before citation_report existed.
    answer = str(result.get("answer", "") or "")
    cited = [match.strip() for match in re.findall(r"\[([^\]]{1,120})\]", answer) if match.strip()]
    allowed = set()
    for item in evidence_items(result):
        for key in ("record_id", "chunk_id", "qa_id"):
            value = item.get(key)
            if value:
                allowed.add(str(value).strip())
    valid = [item for item in cited if item in allowed]
    return {
        "citation_count": float(len(cited)),
        "citation_validity": len(valid) / len(cited) if cited else 0.0,
        "hallucinated_citations": float(len(cited) - len(valid)),
        "hallucinated_citation_rate": (len(cited) - len(valid)) / len(cited) if cited else 0.0,
        "distinct_valid_citations": float(len(set(valid))),
        "citation_fallback_used": 1.0 if result.get("citation_fallback_used") else 0.0,
    }


def score_result(result: dict[str, Any], k: int, relevance_mode: str) -> dict[str, Any]:
    expected_domain = str(result.get("expected_agent_domain") or "").lower()
    expected_tags = {
        str(tag).lower()
        for tag in (result.get("expected_concept_tags") or []) + (result.get("expected_symptom_tags") or [])
        if str(tag).strip()
    }
    evidence = evidence_items(result)[:k]
    relevances = [is_relevant(item, expected_domain, expected_tags, relevance_mode) for item in evidence]
    first_relevant = next((index + 1 for index, rel in enumerate(relevances) if rel), None)
    routed = [str(item).lower() for item in result.get("routed_agents", []) or []]

    row: dict[str, Any] = {
        "model": result.get("model", ""),
        "test_id": result.get("test_id", ""),
        "expected_agent_domain": expected_domain,
        "has_expected_tags": 1.0 if expected_tags else 0.0,
        "retrieved_count": len(evidence),
        f"precision_at_{k}": sum(relevances) / k if k else 0.0,
        f"hit_at_{k}": 1.0 if any(relevances) else 0.0,
        "mrr": 1 / first_relevant if first_relevant else 0.0,
        f"ndcg_at_{k}": ndcg_at_k(relevances, k),
        "answer_reference_f1": lexical_f1(str(result.get("answer", "")), str(result.get("reference_answer", ""))),
        "route_domain_hit": 1.0 if expected_domain and expected_domain in routed else 0.0,
        "router_miss": 1.0 if result.get("router_miss") else 0.0,
        "n_agents": float(result.get("n_agents") or 1),
        "n_starved_agents": float(len(result.get("starved_agents") or [])),
        "n_evidence_to_generator": float(result.get("n_evidence_to_generator") or len(evidence)),
        "graph_terms_added": float(result.get("n_graph_added_terms") or 0.0),
        "safety_flagged": 1.0 if (result.get("safety_flags") or []) else 0.0,
        "llm_calls": float(result.get("llm_calls") or 0.0),
        "prompt_tokens": float(result.get("prompt_tokens") or 0.0),
        "completion_tokens": float(result.get("completion_tokens") or 0.0),
        "latency_seconds": float(result.get("latency_seconds") or 0.0),
        "error": result.get("error", ""),
    }
    row.update(citation_metrics(result))
    return row


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def bootstrap_ci(values: list[float], iterations: int = 2000, seed: int = 12345) -> tuple[float, float]:
    """Percentile bootstrap CI for a mean. No external dependency."""
    if len(values) < 2:
        return (mean(values), mean(values))
    rng = random.Random(seed)
    n = len(values)
    means = []
    for _ in range(iterations):
        sample = [values[rng.randrange(n)] for _ in range(n)]
        means.append(sum(sample) / n)
    means.sort()
    return (means[int(0.025 * iterations)], means[int(0.975 * iterations) - 1])


def paired_test(a: list[float], b: list[float], iterations: int = 10000, seed: int = 999) -> dict[str, Any]:
    """Paired comparison of two arms on the same questions.

    Uses a paired bootstrap on the mean difference, plus a Wilcoxon signed-rank
    test when scipy is available. Reporting a difference in means without one of
    these is not enough to claim one architecture beat another.
    """
    diffs = [x - y for x, y in zip(a, b)]
    if not diffs or all(d == 0 for d in diffs):
        return {
            "n": len(diffs), "mean_diff": 0.0, "ci_low": 0.0, "ci_high": 0.0,
            "p_bootstrap": 1.0, "p_wilcoxon": None,
        }

    rng = random.Random(seed)
    n = len(diffs)
    boot = []
    for _ in range(iterations):
        boot.append(sum(diffs[rng.randrange(n)] for _ in range(n)) / n)
    boot.sort()
    ci_low = boot[int(0.025 * iterations)]
    ci_high = boot[int(0.975 * iterations) - 1]
    observed = mean(diffs)

    # Two-sided bootstrap p-value: how often a resampled mean lands on the far
    # side of zero from the observed effect.
    if observed > 0:
        crossings = sum(1 for value in boot if value <= 0)
    elif observed < 0:
        crossings = sum(1 for value in boot if value >= 0)
    else:
        crossings = iterations // 2
    p_bootstrap = min(1.0, 2 * crossings / iterations)

    p_wilcoxon = None
    try:
        from scipy.stats import wilcoxon

        nonzero = [d for d in diffs if d != 0]
        if len(nonzero) >= 5:
            p_wilcoxon = float(wilcoxon(nonzero).pvalue)
    except Exception:
        p_wilcoxon = None

    return {
        "n": n,
        "mean_diff": round(observed, 4),
        "ci_low": round(ci_low, 4),
        "ci_high": round(ci_high, 4),
        "p_bootstrap": round(p_bootstrap, 4),
        "p_wilcoxon": round(p_wilcoxon, 4) if p_wilcoxon is not None else None,
    }


def add_bertscores(
    rows: list[dict[str, Any]],
    raw_results: list[dict[str, Any]],
    *,
    model_type: str,
    lang: str,
    batch_size: int,
    rescale_with_baseline: bool,
    device: str | None,
) -> None:
    """Add BERTScore precision, recall, and F1 for generated/reference answers."""
    try:
        from bert_score import score as bert_score
    except ImportError as exc:
        raise RuntimeError(
            "BERTScore evaluation requires the bert-score package. Install it with:\n"
            "  python -m pip install bert-score"
        ) from exc

    # Pairs with an empty reference or an empty answer are scored as 0 rather
    # than fed to BERTScore, which returns meaningless similarity for them.
    scorable: list[int] = []
    candidates: list[str] = []
    references: list[str] = []
    for index, result in enumerate(raw_results):
        candidate = strip_citation_artifacts(str(result.get("answer", "") or "")).strip()
        reference = str(result.get("reference_answer", "") or "").strip()
        rows[index]["bertscore_precision"] = 0.0
        rows[index]["bertscore_recall"] = 0.0
        rows[index]["bertscore_f1"] = 0.0
        if candidate and reference:
            scorable.append(index)
            candidates.append(candidate)
            references.append(reference)

    if not candidates:
        print("[warn] no answer/reference pairs were scorable with BERTScore")
        return

    kwargs: dict[str, Any] = {
        "lang": lang,
        "model_type": model_type,
        "batch_size": batch_size,
        "rescale_with_baseline": rescale_with_baseline,
        "verbose": True,
    }
    if device:
        kwargs["device"] = device

    precision, recall, f1 = bert_score(candidates, references, **kwargs)
    p_list, r_list, f_list = precision.tolist(), recall.tolist(), f1.tolist()
    for position, index in enumerate(scorable):
        rows[index]["bertscore_precision"] = float(p_list[position])
        rows[index]["bertscore_recall"] = float(r_list[position])
        rows[index]["bertscore_f1"] = float(f_list[position])


def answer_metric_names(answer_metric: str) -> list[str]:
    if answer_metric == "bertscore":
        return ["bertscore_precision", "bertscore_recall", "bertscore_f1"]
    if answer_metric == "both":
        return ["answer_reference_f1", "bertscore_precision", "bertscore_recall", "bertscore_f1"]
    return ["answer_reference_f1"]


def metric_list(k: int, answer_metric: str) -> list[str]:
    return [
        f"precision_at_{k}",
        f"hit_at_{k}",
        "mrr",
        f"ndcg_at_{k}",
        *answer_metric_names(answer_metric),
        "citation_validity",
        "hallucinated_citation_rate",
        "citation_count",
        "citation_fallback_used",
        "route_domain_hit",
        "router_miss",
        "n_agents",
        "n_starved_agents",
        "n_evidence_to_generator",
        "graph_terms_added",
        "safety_flagged",
        "llm_calls",
        "prompt_tokens",
        "latency_seconds",
    ]


CI_METRICS = ("precision_at_", "hit_at_", "mrr", "ndcg_at_", "citation_validity")


def summarise(rows: list[dict[str, Any]], k: int, answer_metric: str) -> list[dict[str, Any]]:
    metric_names = metric_list(k, answer_metric)
    ci_wanted = {f"precision_at_{k}", f"hit_at_{k}", "mrr", f"ndcg_at_{k}", "citation_validity"}
    by_model: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_model[str(row["model"])].append(row)

    summary = []
    for model, model_rows in sorted(by_model.items()):
        base: dict[str, Any] = {"model": model, "n": len(model_rows), "average_type": "micro"}
        for metric in metric_names:
            values = [float(row.get(metric) or 0.0) for row in model_rows]
            base[metric] = round(mean(values), 4)
            if metric in ci_wanted:
                low, high = bootstrap_ci(values)
                base[f"{metric}_ci_low"] = round(low, 4)
                base[f"{metric}_ci_high"] = round(high, 4)
        summary.append(base)

        by_domain: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in model_rows:
            domain = str(row.get("expected_agent_domain") or "").strip()
            # An empty/unknown expected domain is not a domain. Letting it form
            # its own bucket gave it the same weight as a real domain in the
            # macro average.
            if domain and domain != "unknown":
                by_domain[domain].append(row)
        macro: dict[str, Any] = {
            "model": model,
            "n": len(model_rows),
            "average_type": "macro_by_domain",
            "n_domains": len(by_domain),
        }
        for metric in metric_names:
            domain_means = [
                mean([float(row.get(metric) or 0.0) for row in domain_rows]) for domain_rows in by_domain.values()
            ]
            macro[metric] = round(mean(domain_means), 4)
        summary.append(macro)
    return summary


def significance_table(
    rows: list[dict[str, Any]], k: int, answer_metric: str, baseline: str | None
) -> list[dict[str, Any]]:
    """Paired tests of every arm against the reference arm, on shared test_ids."""
    by_model: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
    for row in rows:
        by_model[str(row["model"])][str(row["test_id"])] = row
    if not by_model:
        return []

    models = sorted(by_model)
    reference = baseline if baseline in by_model else next(
        (name for name in models if "single_agent" in name), models[0]
    )

    metrics = [
        f"precision_at_{k}",
        f"hit_at_{k}",
        "mrr",
        f"ndcg_at_{k}",
        "citation_validity",
        *answer_metric_names(answer_metric),
    ]

    table = []
    for model in models:
        if model == reference:
            continue
        shared = sorted(set(by_model[model]) & set(by_model[reference]))
        if not shared:
            print(f"[warn] no shared test_ids between {model} and {reference}; skipping significance test")
            continue
        for metric in metrics:
            a = [float(by_model[model][tid].get(metric) or 0.0) for tid in shared]
            b = [float(by_model[reference][tid].get(metric) or 0.0) for tid in shared]
            table.append({"model": model, "reference": reference, "metric": metric, **paired_test(a, b)})
    return table


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_latex(path: Path, summary: list[dict[str, Any]], k: int, answer_metric: str) -> None:
    metrics = [
        f"precision_at_{k}",
        f"hit_at_{k}",
        "mrr",
        f"ndcg_at_{k}",
        "citation_validity",
        *answer_metric_names(answer_metric),
    ]
    micro = [row for row in summary if row.get("average_type") == "micro"]
    header = " & ".join(["Model", "n", *[m.replace("_", " ") for m in metrics]])
    lines = [
        "% Auto-generated by evaluate_experiment_outputs.py",
        "\\begin{tabular}{l" + "r" * (len(metrics) + 1) + "}",
        "\\toprule",
        header + " \\\\",
        "\\midrule",
    ]
    for row in micro:
        cells = [str(row["model"]).replace("_", "\\_"), str(row["n"])]
        cells += [f"{float(row.get(metric) or 0.0):.3f}" for metric in metrics]
        lines.append(" & ".join(cells) + " \\\\")
    lines += ["\\bottomrule", "\\end{tabular}"]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def check_run_consistency(raw_results: list[dict[str, Any]]) -> list[str]:
    """Flag configuration drift between runs that are about to be compared."""
    warnings: list[str] = []
    for field in ("embedding_model", "generator_model", "reranker_model", "corpus_fingerprint", "synthesis_k"):
        values = {str(result.get(field)) for result in raw_results if result.get(field) is not None}
        if len(values) > 1:
            warnings.append(f"runs disagree on {field}: {sorted(values)}")

    counts = Counter(str(result.get("model")) for result in raw_results)
    if len(set(counts.values())) > 1:
        warnings.append(f"arms answered different numbers of questions: {dict(counts)}")
    return warnings


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate RAG experiment JSONL outputs.")
    parser.add_argument("--runs", type=Path, nargs="+", required=True)
    parser.add_argument("--output-dir", type=Path, default=OUTPUTS_DIR / "metrics")
    parser.add_argument("--k", type=int, default=5)
    parser.add_argument(
        "--relevance",
        choices=("tags", "tags_or_domain"),
        default="tags",
        help=(
            "How proxy relevance is decided. 'tags' uses held-out concept/symptom tag overlap only. "
            "'tags_or_domain' also counts a domain match, which inflates any arm that retrieves with "
            "a domain filter and must not be used to compare filtered against unfiltered arms."
        ),
    )
    parser.add_argument(
        "--baseline-model",
        default=None,
        help="Model name used as the reference arm in paired significance tests.",
    )
    parser.add_argument(
        "--include-errors",
        action="store_true",
        help="Keep rows whose run raised an exception. By default they are excluded from all metrics.",
    )
    parser.add_argument("--answer-metric", choices=("lexical_f1", "bertscore", "both"), default="lexical_f1")
    parser.add_argument(
        "--bertscore-model",
        default="roberta-large",
        help="Hugging Face model used by BERTScore. roberta-large is the standard English default.",
    )
    parser.add_argument("--bertscore-lang", default="en")
    parser.add_argument("--bertscore-batch-size", type=int, default=8)
    parser.add_argument(
        "--no-bertscore-rescale",
        action="store_true",
        help="Disable baseline rescaling. Rescaling is on by default because raw BERTScore values "
        "bunch in a narrow high range and barely discriminate between systems.",
    )
    parser.add_argument("--bertscore-device", default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.relevance == "tags_or_domain":
        print(
            "[warn] --relevance tags_or_domain counts a domain match as relevant. The multi-agent "
            "arms filter on that same field, so their precision is inflated by construction. Do not "
            "use this mode to compare them against the unfiltered baseline."
        )

    detail_rows: list[dict[str, Any]] = []
    raw_results: list[dict[str, Any]] = []
    n_errors = 0
    n_missing_tags = 0

    for run_path in args.runs:
        for result in load_jsonl(run_path):
            if not result.get("model"):
                result["model"] = run_path.stem
            if result.get("error") and not args.include_errors:
                n_errors += 1
                continue
            expected_tags = (result.get("expected_concept_tags") or []) + (result.get("expected_symptom_tags") or [])
            if not expected_tags:
                n_missing_tags += 1
            raw_results.append(result)
            detail_rows.append(score_result(result, args.k, args.relevance))

    if not detail_rows:
        raise SystemExit("No scorable results found. Check --runs paths, or pass --include-errors.")

    if n_errors:
        print(f"[warn] excluded {n_errors} errored result rows (use --include-errors to keep them)")
    if n_missing_tags:
        print(
            f"[warn] {n_missing_tags} questions carry no expected concept/symptom tags, so proxy "
            "relevance is always 0 for them. Their retrieval metrics are not meaningful."
        )

    for warning in check_run_consistency(raw_results):
        print(f"[warn] {warning}")

    if args.answer_metric in {"bertscore", "both"}:
        add_bertscores(
            detail_rows,
            raw_results,
            model_type=args.bertscore_model,
            lang=args.bertscore_lang,
            batch_size=args.bertscore_batch_size,
            rescale_with_baseline=not args.no_bertscore_rescale,
            device=args.bertscore_device,
        )

    summary_rows = summarise(detail_rows, args.k, args.answer_metric)
    significance_rows = significance_table(detail_rows, args.k, args.answer_metric, args.baseline_model)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.output_dir / "detailed_metrics.csv", detail_rows)
    write_csv(args.output_dir / "summary_metrics.csv", summary_rows)
    write_csv(args.output_dir / "significance_tests.csv", significance_rows)
    write_latex(args.output_dir / "summary_table.tex", summary_rows, args.k, args.answer_metric)
    (args.output_dir / "summary_metrics.json").write_text(
        json.dumps(
            {
                "relevance_mode": args.relevance,
                "k": args.k,
                "summary": summary_rows,
                "significance": significance_rows,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    print(json.dumps(summary_rows, indent=2))
    if significance_rows:
        print("\nPaired tests against the reference arm:")
        for row in significance_rows:
            p_value = row["p_wilcoxon"] if row["p_wilcoxon"] is not None else row["p_bootstrap"]
            verdict = "significant" if p_value is not None and p_value < 0.05 else "not significant"
            print(
                f"  {row['model']} vs {row['reference']} | {row['metric']}: "
                f"diff={row['mean_diff']:+.4f} 95% CI [{row['ci_low']:+.4f}, {row['ci_high']:+.4f}] "
                f"p={p_value} -> {verdict}"
            )
    print(f"\nWrote metrics to {args.output_dir}")


if __name__ == "__main__":
    main()
