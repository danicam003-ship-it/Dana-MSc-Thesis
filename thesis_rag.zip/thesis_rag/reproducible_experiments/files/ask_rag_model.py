
"""Ask one of  RAG models free-form questions

This helper is for manual chatbot testing, not for formal evaluation.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from project_paths import PROJECT_ROOT, SCRIPT_DIR


CURRENT_DIR = SCRIPT_DIR
PROJECT_DIR = PROJECT_ROOT
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from run_experiment_batch import build_model, ensure_index, seed_everything, verify_index  # noqa: E402
from single_agent_rag_baseline import settings_with_overrides  # noqa: E402


def parse_args():
    parser = argparse.ArgumentParser(description="Ask a RAG model custom question.")
    parser.add_argument(
        "--model",
        choices=["single_agent", "multi_agent_passage", "question_to_question", "graph_supported"],
        default="multi_agent_passage",
        help="Which RAG architecture to ask.",
    )
    parser.add_argument("--question", default=None, help="One question to ask.")
    parser.add_argument(
        "--questions-file",
        type=Path,
        default=None,
        help="Optional .txt or .jsonl file of questions. Text files use one question per line.",
    )
    parser.add_argument("--passages", type=Path, default=PROJECT_DIR / "data" / "prepared" / "passages.jsonl")
    parser.add_argument("--qna", type=Path, default=PROJECT_DIR / "data" / "prepared" / "qna_pairs.jsonl")
    parser.add_argument("--graph", type=Path, default=PROJECT_DIR / "data" / "prepared" / "knowledge_graph.json")
    parser.add_argument("--embedding-model", default=None)
    parser.add_argument("--generator-model", default=None)
    parser.add_argument("--reranker-model", default=None)
    parser.add_argument("--qdrant-path", default=None)
    parser.add_argument("--collection-suffix", default=None)
    parser.add_argument("--graph-threshold", type=float, default=0.91)
    parser.add_argument("--graph-max-terms", type=int, default=8)
    parser.add_argument("--route-on", choices=("original", "expanded"), default="original")
    parser.add_argument("--allow-empty-graph", action="store_true")
    parser.add_argument("--reindex", action="store_true", help="Rebuild the relevant Qdrant index before asking.")
    parser.add_argument("--seed", type=int, default=20260719)
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Optional JSONL file where full raw results should be saved.",
    )
    return parser.parse_args()


def load_questions(path: Path):
    """Read questions from either plain text or JSONL."""
    questions: list[str] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            if path.suffix.lower() == ".jsonl":
                try:
                    item = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"Invalid JSON on line {line_number} of {path}") from exc
                query = str(item.get("query") or item.get("question") or "").strip()
            else:
                query = line
            if query:
                questions.append(query)
    return questions


def evidence_label(item: dict[str, Any], index: int) -> str:
    """Compact evidence label for manual inspection."""
    evidence_id = item.get("record_id") or item.get("chunk_id") or item.get("qa_id") or f"evidence_{index}"
    title = item.get("source_title") or item.get("title") or "Unknown source"
    score = item.get("rerank_score")
    score_text = f", rerank={float(score):.3f}" if score is not None else ""
    return f"{index}. [{evidence_id}] {title}{score_text}"


def print_result(result: dict[str, Any]) -> None:
    """Print a readable chatbot answer instead of dumping the full JSON."""
    print("\n" + "=" * 88)
    print("QUESTION")
    print(result.get("query", ""))

    if result.get("routed_agents") is not None:
        routed = result.get("routed_agents") or result.get("active_agents") or []
        print("\nROUTED AGENTS")
        print(", ".join(routed) if routed else "none")

    if result.get("graph_added_terms"):
        print("\nGRAPH ADDED TERMS")
        print(", ".join(result["graph_added_terms"]))

    print("\nANSWER")
    print(result.get("answer", "").strip() or "[empty answer]")

    evidence = result.get("evidence") or []
    print("\nEVIDENCE USED")
    if not evidence:
        print("No evidence returned.")
    else:
        for index, item in enumerate(evidence, start=1):
            print(evidence_label(item, index))

    report = result.get("citation_report") or {}
    if report:
        print("\nCITATION CHECK")
        print(
            "valid citations: "
            f"{report.get('n_valid_citations', 0)}/{report.get('n_citations', 0)}; "
            f"citation_validity={report.get('citation_validity', 0):.3f}"
        )


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)

    settings = settings_with_overrides(
        embedding_model=args.embedding_model,
        generator_model=args.generator_model,
        reranker_model=args.reranker_model,
        qdrant_path=args.qdrant_path,
        collection_suffix=args.collection_suffix,
    )

    model = build_model(args, settings)
    try:
        ensure_index(model, args)
        index_info = verify_index(model, args)
        print(f"Using Qdrant collection: {index_info['collection']}")
        print(f"Indexed records: {index_info['actual_points']}")

        if args.question:
            questions = [args.question]
        elif args.questions_file:
            questions = load_questions(args.questions_file)
        else:
            questions = []

        output_handle = None
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            output_handle = args.output.open("a", encoding="utf-8")

        try:
            if questions:
                for question in questions:
                    result = model.answer(question)
                    print_result(result)
                    if output_handle:
                        output_handle.write(json.dumps(result, ensure_ascii=False, sort_keys=True) + "\n")
                        output_handle.flush()
            else:
                print("\nInteractive mode. Type a question and press Enter. Type 'exit' to stop.")
                while True:
                    question = input("\nYour question: ").strip()
                    if question.lower() in {"exit", "quit", "q"}:
                        break
                    if not question:
                        continue
                    result = model.answer(question)
                    print_result(result)
                    if output_handle:
                        output_handle.write(json.dumps(result, ensure_ascii=False, sort_keys=True) + "\n")
                        output_handle.flush()
        finally:
            if output_handle:
                output_handle.close()
    finally:
        close = getattr(model, "close", None)
        if callable(close):
            close()


if __name__ == "__main__":
    main()
