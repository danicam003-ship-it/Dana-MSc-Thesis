
"""Model 2: Multi-agent RAG with passage retrieval.

This model uses the same fixed retrieval pipeline as the baseline:

1. ClinicalBERT embeds passage chunks.
2. Qdrant retrieves candidate chunks.
3. MiniLM cross-encoder reranks candidates.
4. Qwen3.5-0.8B writes the answer.

The difference from the single-agent baseline is architectural. Instead of one
general retriever searching everything at once, a router selects domain agents.
Each selected agent retrieves from the same Qdrant collection with an
agent_domain metadata filter. A synthesizer then combines the domain findings.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from project_paths import PROJECT_ROOT, SCRIPT_DIR


# Allow this script to import the shared utilities from the baseline file when
# it is run directly as: python thesis_rag/experiments/multi_agent_passage_rag.py
CURRENT_DIR = SCRIPT_DIR
PROJECT_DIR = PROJECT_ROOT
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from single_agent_rag_baseline import (  # noqa: E402
    FixedRAGSettings,
    MiniLMCrossEncoderReranker,
    QdrantVectorStore,
    QwenGenerator,
    TransformerMeanPoolEmbedder,
    citation_report,
    ensure_citations,
    format_passage_evidence,
    load_jsonl,
    normalise_domain,
    settings_with_overrides,
    standardise_passage_record,
)


AGENT_PROMPTS: dict[str, str] = {
    "mental_health": (
        "You are the Mental Health Agent. Explain evidence about mood, anxiety, depression, "
        "stress, trauma, and psychological symptoms. Do not diagnose the user."
    ),
    "sleep": (
        "You are the Sleep Agent. Explain evidence about sleep, insomnia, circadian rhythm, "
        "fatigue, and recovery. Do not reduce all symptoms to sleep alone."
    ),
    "hormonal_health": (
        "You are the Hormonal Health Agent. Explain menstrual, reproductive, PMS, PMDD, PCOS, "
        "perimenopause, menopause, and hormone-related evidence. Avoid deterministic claims."
    ),
    "lifestyle": (
        "You are the Lifestyle Agent. Explain evidence about exercise, stress routines, social "
        "context, habits, environment, breathing, music, and daily interventions."
    ),
    "nutrition_body": (
        "You are the Nutrition and Body Agent. Explain evidence about nutrition, appetite, gut, "
        "weight, metabolic health, body symptoms, and nutrients."
    ),
    "intervention": (
        "You are the Intervention Agent. Explain possible educational interventions, evidence "
        "strength, uncertainty, contraindications, and when professional advice is needed."
    ),
    # Used only when the keyword router matches nothing. The query still gets an
    # answer, but from an unfiltered search, and the result is flagged as a
    # router miss so those questions can be reported separately.
    "unrouted": (
        "You are a general evidence-grounded assistant. No domain agent matched this question, "
        "so you are working from an unfiltered search. Do not diagnose the user."
    ),
}

UNROUTED_DOMAIN = "unrouted"


ROUTER_KEYWORDS: dict[str, tuple[str, ...]] = {
    "mental_health": ("anxiety", "depression", "mood", "panic", "stress", "trauma", "mental", "adhd"),
    "sleep": ("sleep", "insomnia", "tired", "fatigue", "circadian", "wake", "rest"),
    "hormonal_health": (
        "period",
        "pms",
        "pmdd",
        "pcos",
        "hormone",
        "menopause",
        "perimenopause",
        "fertility",
        "cycle",
    ),
    "lifestyle": ("exercise", "habit", "routine", "work", "social", "breathing", "music", "movement"),
    "nutrition_body": ("food", "diet", "nutrition", "gut", "weight", "glucose", "insulin", "vitamin", "iron"),
    "intervention": ("help", "therapy", "treatment", "supplement", "medication", "what can i do", "intervention"),
}


URGENT_SAFETY_PATTERNS = (
    re.compile(r"\bsuicid(?:e|al)\b", re.I),
    re.compile(r"\bkill myself\b", re.I),
    re.compile(r"\bself[- ]?harm\b", re.I),
    re.compile(r"\boverdose\b", re.I),
    re.compile(r"\bimmediate danger\b", re.I),
)


@dataclass
class AgentFinding:
    """Structured output from one domain agent."""

    agent_domain: str
    answer: str
    evidence: list[dict[str, Any]]
    # How many candidates the domain filter actually returned before reranking.
    # A hard agent_domain filter can starve an agent to zero hits when the
    # corpus is unevenly labelled, and that has to be visible in the results
    # rather than showing up as an unexplained quality drop.
    n_retrieved: int = 0
    n_after_rerank: int = 0


def keyword_hits(text: str, keyword):
    """Count whole-word (or whole-phrase) occurrences of a router keyword.
    """
    pattern = rf"(?<![a-z0-9]){re.escape(keyword.lower())}(?![a-z0-9])"
    return len(re.findall(pattern, text))


def route_agents(query, max_agents: int = 4):
    """Select agents using a transparent keyword router.

    This is deliberately simple for the thesis prototype. Later you can replace
    it with an LLM router, but the keyword router is easier to audit.

    A query that matches no keyword returns an empty list. The old fallback of
    ["mental_health"] silently routed every unmatched query to one domain,
    which both biased the results and hid how often the router failed. Callers
    are expected to record the empty case; run_agents() below falls back to an
    unfiltered search so the arm still produces an answer.
    """
    lowered = query.lower()
    scores = {
        domain: sum(keyword_hits(lowered, keyword) for keyword in keywords)
        for domain, keywords in ROUTER_KEYWORDS.items()
    }
    selected = [domain for domain, score in scores.items() if score > 0]
    selected.sort(key=lambda domain: (-scores[domain], domain))
    return selected[:max_agents]


def safety_precheck(query):
    return ["urgent_safety_language"] if any(pattern.search(query) for pattern in URGENT_SAFETY_PATTERNS) else []


def build_agent_prompt(query, agent_domain, evidence):
    return (
        f"User question:\n{query}\n\n"
        f"Agent domain: {agent_domain}\n\n"
        f"Domain-specific retrieved evidence:\n{format_passage_evidence(evidence)}\n\n"
        "Write a short domain finding. Use only this evidence. Every factual sentence must "
        "include at least one exact evidence ID in square brackets. If the evidence does not "
        "support a claim, do not include that claim. "
        "State when the evidence is limited or indirect."
    )


def build_synthesis_prompt(query, findings, evidence:):
    finding_text = "\n\n".join(
        f"{finding.agent_domain} finding:\n{finding.answer}" for finding in findings
    )
    return (
        f"User question:\n{query}\n\n"
        f"Domain findings:\n{finding_text}\n\n"
        f"Underlying evidence:\n{format_passage_evidence(evidence)}\n\n"
        "Synthesize one educational answer. Explain possible interacting domains without overclaiming. "
        "Every factual sentence must include at least one exact evidence ID in square brackets. "
        "Do not diagnose or prescribe. Include safety guidance when appropriate."
    )


class MultiAgentPassageRAG:
    """Multi-agent architecture using passage chunks as the retrieval unit."""

    def __init__(self, settings: FixedRAGSettings):
        self.settings = settings
        self.embedder = TransformerMeanPoolEmbedder(settings.embedding_model)
        self.store = QdrantVectorStore(settings, settings.passage_collection, self.embedder)
        self.reranker = MiniLMCrossEncoderReranker(settings.reranker_model)
        self.generator = QwenGenerator(settings.generator_model, settings.max_new_tokens)

    def index_passages(self, passage_path: Path, recreate: bool = False) -> None:
        raw_records = load_jsonl(passage_path)
        records = [standardise_passage_record(record) for record in raw_records]
        self.store.index_records(records, recreate=recreate)

    def retrieve_for_agent(self, query: str, agent_domain: str) -> tuple[list[dict[str, Any]], int]:
        # The unrouted agent searches without a domain filter. Every other agent
        # keeps its filter, which is the core architectural difference from the
        # baseline.
        retrieved = self.store.search(
            query=query,
            top_k=self.settings.retrieve_k,
            agent_domain=None if agent_domain == UNROUTED_DOMAIN else normalise_domain(agent_domain),
        )
        return self.reranker.rerank(query, retrieved, top_k=self.settings.final_k), len(retrieved)

    def run_agent(self, query: str, agent_domain: str) -> AgentFinding:
        evidence, n_retrieved = self.retrieve_for_agent(query, agent_domain)
        answer = self.generator.generate(
            system_prompt=AGENT_PROMPTS[agent_domain],
            user_prompt=build_agent_prompt(query, agent_domain, evidence),
        )
        answer, _ = ensure_citations(answer, evidence)
        return AgentFinding(
            agent_domain=agent_domain,
            answer=answer,
            evidence=evidence,
            n_retrieved=n_retrieved,
            n_after_rerank=len(evidence),
        )

    def synthesis_budget(self, n_agents: int) -> int:
        """How many evidence items the synthesizer may see.

        Default is settings.synthesis_k (= final_k), so the synthesizer sees the
        same amount of evidence as the single-agent baseline and the comparison
        isolates architecture from context volume. Set SYNTHESIS_K=0 to restore
        the old final_k * n_agents behaviour and report it as a separate arm.
        """
        if self.settings.synthesis_k > 0:
            return self.settings.synthesis_k
        return self.settings.final_k * max(1, n_agents)

    def answer(self, query: str) -> dict[str, Any]:
        safety_flags = safety_precheck(query)
        routed_agents = route_agents(query)
        router_miss = not routed_agents
        active_agents = routed_agents or [UNROUTED_DOMAIN]

        # Each agent searches the same Qdrant collection, but with its own
        # metadata filter. This is the core coding difference from baseline RAG.
        findings = [self.run_agent(query, domain) for domain in active_agents]

        # Deduplicate evidence before synthesis so the final answer is not
        # dominated by repeated chunks retrieved by several agents.
        evidence_by_id: dict[str, dict[str, Any]] = {}
        for finding in findings:
            for item in finding.evidence:
                evidence_by_id.setdefault(str(item.get("record_id")), item)
        synthesis_evidence = sorted(
            evidence_by_id.values(),
            key=lambda item: (
                -float(item.get("rerank_score") or 0.0),
                -float(item.get("vector_score") or 0.0),
                str(item.get("record_id") or ""),
            ),
        )[: self.synthesis_budget(len(active_agents))]

        final_answer = self.generator.generate(
            system_prompt="You are the Synthesizer Agent. Combine domain findings into one safe educational answer.",
            user_prompt=build_synthesis_prompt(query, findings, synthesis_evidence),
        )
        final_answer, fallback_used = ensure_citations(final_answer, synthesis_evidence)

        return {
            "model": "multi_agent_passage_rag",
            "query": query,
            "routed_agents": routed_agents,
            "active_agents": active_agents,
            "router_miss": router_miss,
            "starved_agents": [f.agent_domain for f in findings if f.n_after_rerank == 0],
            "n_agents": len(active_agents),
            "safety_flags": safety_flags,
            "agent_findings": [finding.__dict__ for finding in findings],
            "answer": final_answer,
            "evidence": synthesis_evidence,
            "n_evidence_to_generator": len(synthesis_evidence),
            "synthesis_k": self.synthesis_budget(len(active_agents)),
            "citation_fallback_used": fallback_used,
            "citation_report": citation_report(final_answer, synthesis_evidence),
        }

    def close(self):
        self.store.close()


def parse_args() :
    parser = argparse.ArgumentParser(description="Run multi-agent passage RAG.")
    parser.add_argument("--passages", type=Path, default=PROJECT_DIR / "data" / "prepared" / "passages.jsonl")
    parser.add_argument("--query", required=True)
    parser.add_argument("--embedding-model", default=None, help="Hugging Face encoder used for retrieval embeddings.")
    parser.add_argument("--collection-suffix", default=None, help="Optional suffix for Qdrant collection names.")
    parser.add_argument("--reindex", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    settings = settings_with_overrides(
        embedding_model=args.embedding_model,
        collection_suffix=args.collection_suffix,
    )
    rag = MultiAgentPassageRAG(settings)

    if args.reindex:
        rag.index_passages(args.passages, recreate=True)
    elif rag.store.count_points() == 0:
        if not args.passages.exists():
            raise FileNotFoundError(
                f"No indexed passages found and {args.passages} does not exist. "
                "Pass --passages with your prepared JSONL file and use --reindex."
            )
        rag.index_passages(args.passages, recreate=False)

    result = rag.answer(args.query)
    json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
    print()


if __name__ == "__main__":
    main()
