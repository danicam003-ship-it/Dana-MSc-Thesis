#!/usr/bin/env python3
"""Prepare the thesis corpus for the RAG experiments.

Outputs created by this script:

- data/prepared/passages.jsonl
- data/prepared/qna_pairs.jsonl
- data/prepared/qna_pairs_train.jsonl
- data/prepared/qna_pairs_test.jsonl
- data/prepared/evaluation_questions.jsonl
- data/prepared/knowledge_graph.json
- data/prepared/source_manifest.csv
- data/prepared/concept_inventory.csv
- data/prepared/agent_concepts.json
- data/prepared/preparation_report.md

The Q&A test split is excluded from both the Q-to-Q retrieval index and the
semi-automatic graph, which reduces evaluation leakage.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable
from xml.etree import ElementTree

from project_paths import PROJECT_ROOT


PROJECT_DIR = PROJECT_ROOT


CONTENT_DOMAINS = (
    "mental_health",
    "sleep",
    "hormonal_health",
    "lifestyle",
    "nutrition_body",
    "intervention",
)

DOMAIN_LABELS = {
    "mental health agent": "mental_health",
    "mental health": "mental_health",
    "mental_health": "mental_health",
    "sleep agent": "sleep",
    "sleep": "sleep",
    "hormonal health agent": "hormonal_health",
    "hormonal health": "hormonal_health",
    "hormonal_health": "hormonal_health",
    "lifestyle agent": "lifestyle",
    "lifestyle": "lifestyle",
    "nutrition and body agent": "nutrition_body",
    "nutrition and body": "nutrition_body",
    "nutrition_body": "nutrition_body",
    "intervention agent": "intervention",
    "intervention": "intervention",
}


@dataclass(frozen=True)
class Concept:
    concept_id: str
    label: str
    domain: str
    concept_type: str
    synonyms: tuple[str, ...] = ()


DEFAULT_AGENT_CONCEPTS: tuple[Concept, ...] = (
    Concept("anxiety", "anxiety", "mental_health", "symptom", ("worry", "nervousness", "anxious")),
    Concept("depression", "depression", "mental_health", "symptom", ("low mood", "depressive symptoms")),
    Concept("stress", "stress", "mental_health", "symptom", ("psychological stress", "distress")),
    Concept("trauma", "trauma", "mental_health", "condition", ("post traumatic stress", "ptsd")),
    Concept("panic", "panic", "mental_health", "symptom", ("panic attack", "panic attacks")),
    Concept("rumination", "rumination", "mental_health", "symptom", ("repetitive thinking",)),
    Concept("irritability", "irritability", "mental_health", "symptom", ("anger", "mood swings")),
    Concept("brain_fog", "brain fog", "mental_health", "symptom", ("poor concentration", "mental fog")),
    Concept("low_motivation", "low motivation", "mental_health", "symptom", ("amotivation", "lack of motivation")),
    Concept("anhedonia", "anhedonia", "mental_health", "symptom", ("loss of pleasure",)),
    Concept("emotional_regulation", "emotional regulation", "mental_health", "concept", ("emotion regulation",)),
    Concept("loneliness", "loneliness", "mental_health", "context", ("social isolation",)),
    Concept("suicidal_ideation", "suicidal ideation", "mental_health", "safety", ("suicidal thoughts", "suicide")),
    Concept("self_harm", "self harm", "mental_health", "safety", ("self-harm", "self injury")),
    Concept("insomnia", "insomnia", "sleep", "symptom", ("trouble sleeping", "difficulty sleeping")),
    Concept("sleep_deprivation", "sleep deprivation", "sleep", "symptom", ("insufficient sleep", "short sleep")),
    Concept("sleep_disturbance", "sleep disturbance", "sleep", "symptom", ("sleep problems", "disturbed sleep")),
    Concept("fatigue", "fatigue", "sleep", "symptom", ("tiredness", "exhaustion", "low energy")),
    Concept("circadian_rhythm", "circadian rhythm", "sleep", "concept", ("circadian clock", "body clock")),
    Concept("sleep_quality", "sleep quality", "sleep", "concept", ("quality of sleep",)),
    Concept("daytime_sleepiness", "daytime sleepiness", "sleep", "symptom", ("sleepy during the day",)),
    Concept("melatonin", "melatonin", "sleep", "concept", ("sleep hormone",)),
    Concept("light_exposure", "light exposure", "sleep", "intervention", ("sunlight", "bright light")),
    Concept("chronotype", "chronotype", "sleep", "concept", ("morningness", "eveningness")),
    Concept("slow_wave_sleep", "slow wave sleep", "sleep", "concept", ("deep sleep",)),
    Concept("rem_sleep", "REM sleep", "sleep", "concept", ("rapid eye movement sleep",)),
    Concept("pms", "PMS", "hormonal_health", "condition", ("premenstrual syndrome",)),
    Concept("pmdd", "PMDD", "hormonal_health", "condition", ("premenstrual dysphoric disorder",)),
    Concept("menstrual_cycle", "menstrual cycle", "hormonal_health", "life_stage", ("cycle", "menstruation")),
    Concept("period_symptoms", "period symptoms", "hormonal_health", "symptom", ("menstrual symptoms",)),
    Concept("perimenopause", "perimenopause", "hormonal_health", "life_stage", ("midlife transition",)),
    Concept("menopause", "menopause", "hormonal_health", "life_stage", ("postmenopause", "post menopausal")),
    Concept("pregnancy", "pregnancy", "hormonal_health", "life_stage", ("prenatal", "antenatal")),
    Concept("postpartum", "postpartum", "hormonal_health", "life_stage", ("postnatal", "after pregnancy")),
    Concept("estrogen", "estrogen", "hormonal_health", "concept", ("oestrogen", "estradiol")),
    Concept("progesterone", "progesterone", "hormonal_health", "concept", ()),
    Concept("hormonal_contraception", "hormonal contraception", "hormonal_health", "intervention", ("birth control",)),
    Concept("pcos", "PCOS", "hormonal_health", "condition", ("polycystic ovary syndrome",)),
    Concept("endometriosis", "endometriosis", "hormonal_health", "condition", ()),
    Concept("hot_flashes", "hot flashes", "hormonal_health", "symptom", ("hot flushes",)),
    Concept("exercise", "exercise", "lifestyle", "intervention", ("physical activity", "aerobic exercise")),
    Concept("meditation", "meditation", "lifestyle", "intervention", ("mindfulness", "mindfulness meditation")),
    Concept("breathing_exercise", "breathing exercise", "lifestyle", "intervention", ("breathwork", "breathing")),
    Concept("music_therapy", "music therapy", "lifestyle", "intervention", ("music intervention",)),
    Concept("social_connection", "social connection", "lifestyle", "context", ("social support", "relationships")),
    Concept("family_conflict", "family conflict", "lifestyle", "context", ("intrafamily conflict", "parental conflict")),
    Concept("screen_time", "screen time", "lifestyle", "context", ("social media use", "digital media")),
    Concept("environmental_exposure", "environmental exposure", "lifestyle", "context", ("pollution", "environment")),
    Concept("routine", "routine", "lifestyle", "intervention", ("habit", "daily routine")),
    Concept("coping", "coping", "lifestyle", "concept", ("avoidant coping", "coping strategy")),
    Concept("migration_stress", "migration stress", "lifestyle", "context", ("forced migrants", "displacement")),
    Concept("diet", "diet", "nutrition_body", "intervention", ("dietary pattern", "food intake")),
    Concept("nutrition", "nutrition", "nutrition_body", "concept", ("nutritional status",)),
    Concept("gut_microbiome", "gut microbiome", "nutrition_body", "concept", ("microbiota", "gut bacteria")),
    Concept("gut_brain_axis", "gut-brain axis", "nutrition_body", "concept", ("gut brain axis",)),
    Concept("probiotics", "probiotics", "nutrition_body", "intervention", ("probiotic",)),
    Concept("prebiotics", "prebiotics", "nutrition_body", "intervention", ("prebiotic",)),
    Concept("fermented_foods", "fermented foods", "nutrition_body", "intervention", ("fermented food",)),
    Concept("fiber", "fiber", "nutrition_body", "nutrient", ("fibre",)),
    Concept("saturated_fat", "saturated fat", "nutrition_body", "nutrient", ("saturated fatty acid",)),
    Concept("vitamin_d", "vitamin D", "nutrition_body", "nutrient", ("vitamin-d",)),
    Concept("iron", "iron", "nutrition_body", "nutrient", ("iron deficiency", "ferritin")),
    Concept("glucose", "glucose", "nutrition_body", "concept", ("blood sugar",)),
    Concept("insulin_sensitivity", "insulin sensitivity", "nutrition_body", "concept", ("insulin resistance",)),
    Concept("obesity", "obesity", "nutrition_body", "condition", ("BMI", "body mass index")),
    Concept("appetite", "appetite", "nutrition_body", "symptom", ("satiety", "hunger")),
    Concept("inflammation", "inflammation", "nutrition_body", "concept", ("cytokines", "inflammatory")),
    Concept("cbt", "CBT", "intervention", "intervention", ("cognitive behavioral therapy", "cognitive behavioural therapy")),
    Concept("therapy", "therapy", "intervention", "intervention", ("psychotherapy", "counselling", "counseling")),
    Concept("self_help", "self help", "intervention", "intervention", ("self-help", "guided self help")),
    Concept("supplements", "supplements", "intervention", "intervention", ("supplementation", "supplement")),
    Concept("herbal_medicine", "herbal medicine", "intervention", "intervention", ("chinese herbal medicine", "herbs")),
    Concept("ginger", "ginger", "intervention", "intervention", ("ginger consumption",)),
    Concept("hormone_therapy", "hormone therapy", "intervention", "intervention", ("menopausal hormone therapy", "HRT")),
    Concept("light_therapy", "light therapy", "intervention", "intervention", ("bright light therapy",)),
    Concept("medication", "medication", "intervention", "intervention", ("medicine", "drug treatment")),
    Concept("contraindication", "contraindication", "intervention", "safety", ("contraindicated", "not recommended")),
    Concept("clinical_assessment", "clinical assessment", "intervention", "safety", ("professional advice", "doctor")),
    Concept("red_flag", "red flag", "intervention", "safety", ("urgent help", "emergency")),
)

AGENT_CONCEPTS: tuple[Concept, ...] = DEFAULT_AGENT_CONCEPTS
CONCEPT_SOURCE_DESCRIPTION = "manually defined agent concepts in prepare_experiment_data.py"


class SimpleHTMLTextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.title_parts: list[str] = []
        self.skip_depth = 0
        self.in_title = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() in {"script", "style", "noscript"}:
            self.skip_depth += 1
        if tag.lower() == "title":
            self.in_title = True
        if tag.lower() in {"p", "br", "div", "section", "article", "h1", "h2", "h3", "li"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() in {"script", "style", "noscript"} and self.skip_depth:
            self.skip_depth -= 1
        if tag.lower() == "title":
            self.in_title = False

    def handle_data(self, data: str) -> None:
        if self.skip_depth:
            return
        text = data.strip()
        if not text:
            return
        if self.in_title:
            self.title_parts.append(text)
        self.parts.append(text)

    @property
    def text(self) -> str:
        return clean_text(" ".join(self.parts))

    @property
    def title(self) -> str:
        return clean_text(" ".join(self.title_parts))


def clean_text(text: str) -> str:
    text = text.replace("\u00a0", " ")
    text = re.sub(r"(?<=\w)-\s+(?=\w)", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def slugify(text: str, max_len: int = 64) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    return slug[:max_len].strip("_") or "item"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalise_domain(value: str) -> str:
    key = clean_text(value).lower().replace("-", " ")
    return DOMAIN_LABELS.get(key, key.replace(" ", "_") if key else "mental_health")


def matrix_domain(value: Any, fallback: str = "mental_health") -> str:
    """Map free-text spreadsheet agent labels to one content domain."""
    text = clean_text(str(value or "")).lower().replace("-", " ")
    if not text or "manual review" in text:
        return fallback

    parts = [part.strip() for part in re.split(r"[;/,]+", text) if part.strip()]
    for part in [*parts, text]:
        if "mental" in part:
            return "mental_health"
        if "sleep" in part:
            return "sleep"
        if "hormonal" in part or "hormone" in part or "reproductive" in part:
            return "hormonal_health"
        if "nutrition" in part or "body" in part:
            return "nutrition_body"
        if "lifestyle" in part or "demographic" in part or "social context" in part:
            return "lifestyle"
        if "intervention" in part or "safety" in part:
            return "intervention"
    return fallback


def matrix_concept_type(value: Any) -> str:
    """Map graph node labels from the workbook to the internal concept types."""
    text = clean_text(str(value or "")).lower()
    if "safety" in text or "red flag" in text:
        return "safety"
    if "symptom" in text:
        return "symptom"
    if "condition" in text:
        return "condition"
    if "intervention" in text or "behavior" in text or "behaviour" in text:
        return "intervention"
    if "life" in text and "stage" in text:
        return "life_stage"
    if "context" in text or "population" in text:
        return "context"
    if "nutrient" in text:
        return "nutrient"
    return "concept"


def split_matrix_terms(value: Any) -> tuple[str, ...]:
    """Split semicolon-separated spreadsheet variants into clean synonyms."""
    terms: list[str] = []
    for raw in re.split(r"[;\n]+", str(value or "")):
        term = clean_text(raw.strip(" ,.;:"))
        if not term:
            continue
        if term.lower() in {"manual review", "manual review needed", "none", "n/a", "na"}:
            continue
        terms.append(term)
    return tuple(dict.fromkeys(terms))


def merge_concepts(left: Concept, right: Concept) -> Concept:
    """Merge duplicate concepts while retaining synonyms from both sources."""
    synonyms = []
    seen = {left.label.lower(), right.label.lower()}
    for term in (*left.synonyms, *right.synonyms):
        key = term.lower()
        if key not in seen:
            synonyms.append(term)
            seen.add(key)
    return Concept(
        concept_id=left.concept_id,
        label=left.label,
        domain=right.domain or left.domain,
        concept_type=right.concept_type or left.concept_type,
        synonyms=tuple(synonyms),
    )


def load_concepts_from_matrix(path: Path, base_concepts: tuple[Concept, ...]) -> tuple[Concept, ...]:
    """Load concept labels and synonyms from the highlighted metadata matrix."""
    if not path.exists():
        return base_concepts

    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise RuntimeError(
            "Concept-matrix reading requires openpyxl. Install it with: python -m pip install openpyxl"
        ) from exc

    workbook = load_workbook(path, read_only=True, data_only=True)
    concepts_by_key: dict[str, Concept] = {slugify(concept.label): concept for concept in base_concepts}

    sheet_specs = {
        "Concept_Matrix": {
            "label": "concept",
            "synonyms": "synonyms_or_query_variants",
            "domain": "suggested_agent_or_domain",
            "node_type": "graph_node_type",
        },
        "Highlighted_Phrases": {
            "label": "normalized_phrase",
            "synonyms": "suggested_synonyms",
            "domain": "suggested_agent_or_domain",
            "node_type": "graph_node_type",
        },
    }

    for sheet_name, spec in sheet_specs.items():
        if sheet_name not in workbook.sheetnames:
            continue
        worksheet = workbook[sheet_name]
        headers = {
            clean_text(str(worksheet.cell(1, column).value or "")): column
            for column in range(1, worksheet.max_column + 1)
        }
        required = [spec["label"], spec["domain"], spec["node_type"]]
        if any(name not in headers for name in required):
            continue

        for row in range(2, worksheet.max_row + 1):
            label = clean_text(str(worksheet.cell(row, headers[spec["label"]]).value or "").strip(" ,.;:"))
            if not label:
                continue
            if label.lower() in {"manual review", "manual review needed"}:
                continue

            key = slugify(label)
            existing = concepts_by_key.get(key)
            fallback_domain = existing.domain if existing else "mental_health"
            domain = matrix_domain(worksheet.cell(row, headers[spec["domain"]]).value, fallback=fallback_domain)
            concept_type = matrix_concept_type(worksheet.cell(row, headers[spec["node_type"]]).value)
            synonyms = split_matrix_terms(
                worksheet.cell(row, headers.get(spec["synonyms"], 0)).value if spec["synonyms"] in headers else ""
            )
            concept = Concept(key, label, domain, concept_type, synonyms)
            concepts_by_key[key] = merge_concepts(existing, concept) if existing else concept

    return tuple(sorted(concepts_by_key.values(), key=lambda concept: concept.concept_id))


def set_agent_concepts_from_matrix(path: Path | None) -> None:
    """Activate the workbook-backed concept vocabulary for this preparation run."""
    global AGENT_CONCEPTS, CONCEPT_SOURCE_DESCRIPTION
    if path and path.exists():
        AGENT_CONCEPTS = load_concepts_from_matrix(path, DEFAULT_AGENT_CONCEPTS)
        CONCEPT_SOURCE_DESCRIPTION = f"default agent concepts plus highlighted concept metadata matrix: {path}"
    else:
        AGENT_CONCEPTS = DEFAULT_AGENT_CONCEPTS
        CONCEPT_SOURCE_DESCRIPTION = "manually defined agent concepts in prepare_experiment_data.py"


def word_count(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text))


def read_pdf(path: Path) -> tuple[str, str, int]:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise RuntimeError("PDF extraction requires pypdf. Install it or use the bundled Codex Python.") from exc
    reader = PdfReader(str(path))
    page_text = [page.extract_text() or "" for page in reader.pages]
    return clean_text("\n".join(page_text)), path.stem, len(page_text)


def read_html(path: Path) -> tuple[str, str, int]:
    raw = path.read_text(encoding="utf-8", errors="ignore")
    parser = SimpleHTMLTextExtractor()
    parser.feed(raw)
    title = parser.title or path.stem
    return parser.text, title, 0


def read_xml(path: Path) -> tuple[str, str, int]:
    root = ElementTree.parse(path).getroot()
    texts = [text.strip() for text in root.itertext() if text and text.strip()]
    title = path.stem
    for elem in root.iter():
        tag = elem.tag.lower().split("}")[-1]
        if tag in {"title", "article-title"} and elem.text:
            title = clean_text(elem.text)
            break
    return clean_text(" ".join(texts)), title, 0


def extract_source(path: Path) -> tuple[str, str, int]:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return read_pdf(path)
    if suffix in {".html", ".htm"}:
        return read_html(path)
    if suffix == ".xml":
        return read_xml(path)
    raise ValueError(f"Unsupported file type: {path}")


def chunk_text(text: str, chunk_words: int, overlap_words: int) -> list[str]:
    words = re.findall(r"\S+", text)
    if not words:
        return []
    if len(words) <= chunk_words:
        return [" ".join(words)]
    step = max(1, chunk_words - overlap_words)
    minimum = max(60, chunk_words // 3)
    chunks = []
    for start in range(0, len(words), step):
        chunk = words[start : start + chunk_words]
        if len(chunk) < minimum:
            # The tail is short because it is the end of the document, not
            # because it is junk. The old `break` discarded the end of every
            # source that did not divide evenly. Keep it as its own chunk when
            # it still carries content; otherwise it is already covered by the
            # overlap of the previous chunk.
            if len(chunk) >= 30:
                chunks.append(" ".join(chunk))
            break
        chunks.append(" ".join(chunk))
    return chunks


def concept_names(concept: Concept) -> tuple[str, ...]:
    return (concept.label, *concept.synonyms)


def contains_name(text_lower: str, name: str) -> bool:
    needle = name.lower().strip()
    if not needle:
        return False
    if len(needle) <= 3:
        return re.search(rf"(?<![a-z0-9]){re.escape(needle)}(?![a-z0-9])", text_lower) is not None
    return needle in text_lower


def match_concepts(text: str) -> list[Concept]:
    lowered = text.lower()
    matches = []
    for concept in AGENT_CONCEPTS:
        if any(contains_name(lowered, name) for name in concept_names(concept)):
            matches.append(concept)
    return matches


def choose_domain(text: str, fallback: str = "unknown") -> str:
    matches = match_concepts(text)
    if not matches:
        return fallback
    scores = Counter(concept.domain for concept in matches)
    return sorted(scores.items(), key=lambda item: (-item[1], item[0]))[0][0]


def tags_from_text(text: str) -> tuple[list[str], list[str], list[str]]:
    matches = match_concepts(text)
    symptom_tags = sorted({concept.label for concept in matches if concept.concept_type in {"symptom", "safety"}})
    concept_tags = sorted({concept.label for concept in matches})
    life_stage_tags = sorted({concept.label for concept in matches if concept.concept_type == "life_stage"})
    return symptom_tags, concept_tags, life_stage_tags


def find_doi(text: str) -> str:
    match = re.search(r"\b10\.\d{4,9}/[-._;()/:A-Za-z0-9]+\b", text)
    return match.group(0).rstrip(".") if match else ""


def source_type(path: Path, text: str) -> str:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return "pdf"
    if suffix in {".html", ".htm"}:
        return "science_direct_html" if "sciencedirect" in (path.name + text[:2000]).lower() else "html"
    if suffix == ".xml":
        return "xml"
    return "unknown"


def read_qna_workbook(path: Path, sheet_name: str = "Cleaned_QA_Pairs") -> list[dict[str, str]]:
    try:
        import openpyxl
    except ImportError as exc:
        raise RuntimeError(
            "Q&A workbook reading requires openpyxl. Install it in the active Python environment "
            "with: python -m pip install openpyxl"
        ) from exc

    workbook = openpyxl.load_workbook(path, read_only=True, data_only=True)
    sheet = workbook[sheet_name] if sheet_name in workbook.sheetnames else workbook.active
    raw_rows = [[str(value).strip() if value is not None else "" for value in row] for row in sheet.iter_rows(values_only=True)]

    header_index = None
    for index, row in enumerate(raw_rows):
        lowered = [cell.lower() for cell in row]
        if "question" in lowered and any("answer" in cell for cell in lowered):
            header_index = index
            break
    if header_index is None:
        raise ValueError(f"No Q&A header row found in {path}")

    headers = raw_rows[header_index]
    rows: list[dict[str, str]] = []
    for row in raw_rows[header_index + 1 :]:
        if not any(row):
            continue
        record = {headers[i]: row[i] if i < len(row) else "" for i in range(len(headers)) if headers[i]}
        question = record.get("Question", "").strip()
        answer = record.get("Possible Answer (Transcript-Derived)", "").strip() or record.get("Answer", "").strip()
        recommendation = record.get("Recommended for Q-Q Retrieval", "").strip().lower()
        if question and answer and recommendation not in {"no", "exclude", "remove"}:
            rows.append(record)
    return rows


def normalise_qna_record(row: dict[str, str], workbook_path: Path) -> dict[str, Any]:
    question = row.get("Question", "").strip()
    answer = row.get("Possible Answer (Transcript-Derived)", "").strip() or row.get("Answer", "").strip()
    domain = normalise_domain(row.get("Primary Agent", "mental_health"))
    tag_text = f"{question} {answer} {row.get('Episode Title', '')}"
    symptom_tags, concept_tags, life_stage_tags = tags_from_text(tag_text)
    pair_id = row.get("Pair ID", "").strip() or f"qa_{hashlib.md5(question.encode()).hexdigest()[:10]}"
    return {
        "qa_id": pair_id,
        "pair_id": pair_id,
        "question": question,
        "answer": answer,
        "source_title": row.get("Episode Title", "").strip() or "Huberman Lab transcript Q&A",
        "source_type": "podcast_transcript_qna",
        "interviewer": row.get("Question Speaker", "").strip(),
        "interviewee": row.get("Answer Speaker", "").strip(),
        "question_speaker": row.get("Question Speaker", "").strip(),
        "answer_speaker": row.get("Answer Speaker", "").strip(),
        "agent_domain": domain if domain in CONTENT_DOMAINS else choose_domain(tag_text),
        "secondary_agents": row.get("Secondary Agents", "").strip(),
        "pair_type": row.get("Pair Type", "").strip(),
        "context_dependency": row.get("Context Dependency", "").strip(),
        "recommended_for_q_to_q": row.get("Recommended for Q-Q Retrieval", "").strip(),
        "safety_tag": row.get("Safety Tag", "").strip(),
        "symptom_tags": symptom_tags,
        "concept_tags": concept_tags,
        "life_stage_tags": life_stage_tags,
        "license_metadata": "human-reviewed transcript Q&A; verify reuse terms for thesis before distribution",
        "source_file": str(workbook_path),
        "retrieval_text": question,
    }


def stratified_split(records: list[dict[str, Any]], test_ratio: float, seed: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        grouped[str(record.get("agent_domain", "mental_health"))].append(record)

    target_total = int(round(len(records) * test_ratio))
    allocations: dict[str, int] = {}
    fractions: list[tuple[float, str]] = []
    for domain, group in grouped.items():
        ideal = len(group) * test_ratio
        base = int(math.floor(ideal))
        allocations[domain] = base
        fractions.append((ideal - base, domain))

    remainder = target_total - sum(allocations.values())
    for _, domain in sorted(fractions, reverse=True)[: max(0, remainder)]:
        allocations[domain] += 1

    rng = random.Random(seed)
    train: list[dict[str, Any]] = []
    test: list[dict[str, Any]] = []
    for domain, group in grouped.items():
        shuffled = list(group)
        rng.shuffle(shuffled)
        n_test = allocations.get(domain, 0)
        test.extend(shuffled[:n_test])
        train.extend(shuffled[n_test:])

    train.sort(key=lambda item: str(item["qa_id"]))
    test.sort(key=lambda item: str(item["qa_id"]))
    return train, test


def write_jsonl(path: Path, records: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def build_passages(data_dir: Path, chunk_words: int, overlap_words: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    paths = sorted(
        path for path in data_dir.iterdir()
        if path.is_file() and path.suffix.lower() in {".pdf", ".html", ".htm", ".xml"}
    )
    passages: list[dict[str, Any]] = []
    manifest: list[dict[str, Any]] = []

    for source_index, path in enumerate(paths, start=1):
        source_id = f"SRC-{source_index:03d}"
        try:
            text, title, page_count = extract_source(path)
            error = ""
        except Exception as exc:
            text, title, page_count = "", path.stem, 0
            error = f"{type(exc).__name__}: {exc}"

        doi = find_doi(text)
        stype = source_type(path, text)
        chunks = chunk_text(text, chunk_words, overlap_words)
        manifest.append(
            {
                "source_id": source_id,
                "file_name": path.name,
                "file_path": str(path),
                "source_type": stype,
                "source_title": title or path.stem,
                "doi": doi,
                "sha256": sha256(path),
                "word_count": word_count(text),
                "chunk_count": len(chunks),
                "page_count": page_count,
                "dominant_agent_domain": choose_domain(f"{path.stem} {title} {text[:5000]}"),
                "extraction_error": error,
            }
        )

        for chunk_index, chunk in enumerate(chunks, start=1):
            symptom_tags, concept_tags, life_stage_tags = tags_from_text(chunk)
            domain = choose_domain(f"{path.stem} {title} {chunk}")
            chunk_id = f"{source_id}_chunk_{chunk_index:04d}"
            passages.append(
                {
                    "chunk_id": chunk_id,
                    "record_id": chunk_id,
                    "text": chunk,
                    "retrieval_text": chunk,
                    "source_id": source_id,
                    "source_title": title or path.stem,
                    "source_type": stype,
                    "source_file": str(path),
                    "doi": doi,
                    "section": "full_text",
                    "agent_domain": domain,
                    "symptom_tags": symptom_tags,
                    "concept_tags": concept_tags,
                    "life_stage_tags": life_stage_tags,
                    "license_metadata": "local thesis corpus; verify source-specific reuse terms before publication",
                }
            )
    return passages, manifest


def evidence_concepts(record: dict[str, Any]) -> set[str]:
    concepts = record.get("concept_tags") or []
    labels = {str(item) for item in concepts if str(item).strip()}
    return {concept.concept_id for concept in AGENT_CONCEPTS if concept.label in labels}


def relation_for(left: Concept, right: Concept) -> str:
    if left.concept_type == "safety" or right.concept_type == "safety":
        return "has_red_flag"
    if left.domain == "intervention" or right.domain == "intervention":
        return "may_be_supported_by"
    if left.domain != right.domain:
        return "associated_with"
    return "co_occurs_with"


def build_knowledge_graph(passages: list[dict[str, Any]], qna_train: list[dict[str, Any]], min_confidence: float) -> dict[str, Any]:
    concept_by_id = {concept.concept_id: concept for concept in AGENT_CONCEPTS}
    evidence_records = list(passages) + list(qna_train)
    mentions: Counter[str] = Counter()
    edge_evidence: dict[tuple[str, str], set[str]] = defaultdict(set)
    edge_sources: dict[tuple[str, str], set[str]] = defaultdict(set)

    for record in evidence_records:
        ids = sorted(evidence_concepts(record))
        evidence_id = str(record.get("record_id") or record.get("chunk_id") or record.get("qa_id"))
        source_id = str(record.get("source_id") or record.get("source_title") or record.get("source_file") or "unknown")
        for concept_id in ids:
            mentions[concept_id] += 1
        for index, left in enumerate(ids):
            for right in ids[index + 1 :]:
                if left == right:
                    continue
                key = tuple(sorted((left, right)))
                edge_evidence[key].add(evidence_id)
                edge_sources[key].add(source_id)

    nodes = [
        {
            "id": concept.concept_id,
            "label": concept.label,
            "synonyms": list(concept.synonyms),
            "agent_domain": concept.domain,
            "node_type": concept.concept_type,
            "mention_count": mentions[concept.concept_id],
        }
        for concept in AGENT_CONCEPTS
        if mentions[concept.concept_id] > 0
    ]

    edges = []
    for (left_id, right_id), evidence_ids in edge_evidence.items():
        left = concept_by_id[left_id]
        right = concept_by_id[right_id]
        count = len(evidence_ids)
        source_count = len(edge_sources[(left_id, right_id)])
        same_domain_bonus = 0.05 if left.domain == right.domain else 0.0
        confidence = min(0.97, 0.58 + 0.18 * min(count, 6) / 6 + 0.14 * min(source_count, 3) / 3 + same_domain_bonus)
        if confidence < min_confidence:
            continue
        edges.append(
            {
                "source": left_id,
                "target": right_id,
                "relation": relation_for(left, right),
                "confidence": round(confidence, 3),
                "evidence_ids": sorted(evidence_ids)[:30],
                "extraction_method": "controlled_concept_cooccurrence",
                "source_quality": 0.80,
                "extraction_confidence": round(confidence, 3),
                "corroboration_count": count,
                "source_count": source_count,
                # Edges are automatically extracted from concept co-occurrence
                # and are used only as retrieval-expansion candidates. No
                # clinical review step exists in this pipeline and nothing gates
                # on one; validation by a domain professional is future work.
                "extraction_type": "automatic_unreviewed",
            }
        )

    edges.sort(key=lambda item: (-item["confidence"], item["source"], item["target"]))
    return {
        "metadata": {
            "build_method": "semi_automatic_controlled_concept_cooccurrence",
            "concept_source": CONCEPT_SOURCE_DESCRIPTION,
            "graph_training_inputs": "passages plus Q&A training split only; held-out Q&A test rows excluded",
            "min_confidence": min_confidence,
            "note": (
                "Edges are automatically extracted retrieval-expansion candidates, not diagnostic "
                "or causal claims, and have not been reviewed by a clinical professional."
            ),
        },
        "nodes": nodes,
        "edges": edges,
    }


def build_evaluation_questions(qna_records: list[dict[str, Any]], split_name: str) -> list[dict[str, Any]]:
    rows = []
    prefix = "TRAIN-QA" if split_name == "train" else "TEST-QA"
    source_label = "training_human_reviewed_qna" if split_name == "train" else "held_out_human_reviewed_qna"
    for index, record in enumerate(qna_records, start=1):
        rows.append(
            {
                "test_id": f"{prefix}-{index:04d}",
                "query": record["question"],
                "reference_answer": record["answer"],
                "heldout_qa_id": record["qa_id"],
                "source_title": record.get("source_title", ""),
                "agent_domain": record.get("agent_domain", "mental_health"),
                "symptom_tags": record.get("symptom_tags", []),
                "concept_tags": record.get("concept_tags", []),
                "life_stage_tags": record.get("life_stage_tags", []),
                "test_source": source_label,
            }
        )
    return rows


def write_agent_concepts(path: Path) -> None:
    payload = [
        {
            "concept_id": concept.concept_id,
            "label": concept.label,
            "agent_domain": concept.domain,
            "concept_type": concept.concept_type,
            "synonyms": list(concept.synonyms),
        }
        for concept in AGENT_CONCEPTS
    ]
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def write_concept_inventory(path: Path, graph: dict[str, Any]) -> None:
    edge_counts: Counter[str] = Counter()
    for edge in graph["edges"]:
        edge_counts[edge["source"]] += 1
        edge_counts[edge["target"]] += 1
    rows = []
    for node in graph["nodes"]:
        rows.append(
            {
                "concept_id": node["id"],
                "label": node["label"],
                "agent_domain": node["agent_domain"],
                "node_type": node["node_type"],
                "mention_count": node["mention_count"],
                "candidate_edge_count": edge_counts[node["id"]],
                "synonyms": "; ".join(node["synonyms"]),
            }
        )
    write_csv(
        path,
        rows,
        ["concept_id", "label", "agent_domain", "node_type", "mention_count", "candidate_edge_count", "synonyms"],
    )


def build_report(
    output_dir: Path,
    passages: list[dict[str, Any]],
    manifest: list[dict[str, Any]],
    qna_all: list[dict[str, Any]],
    qna_train: list[dict[str, Any]],
    qna_test: list[dict[str, Any]],
    graph: dict[str, Any],
) -> str:
    passage_domains = Counter(record["agent_domain"] for record in passages)
    qna_train_domains = Counter(record["agent_domain"] for record in qna_train)
    qna_test_domains = Counter(record["agent_domain"] for record in qna_test)
    file_types = Counter(row["source_type"] for row in manifest)
    lines = [
        "# Experiment Data Preparation Report",
        "",
        "## Inputs",
        f"- Source files scanned: {len(manifest)}",
        f"- Source file types: {dict(sorted(file_types.items()))}",
        f"- Human-reviewed Q&A rows loaded: {len(qna_all)}",
        f"- Active concept vocabulary: {len(AGENT_CONCEPTS)} concepts",
        f"- Concept source: {CONCEPT_SOURCE_DESCRIPTION}",
        "",
        "## Outputs",
        f"- Passage chunks: {len(passages)} -> `{output_dir / 'passages.jsonl'}`",
        f"- Q&A train/index rows: {len(qna_train)} -> `{output_dir / 'qna_pairs.jsonl'}`",
        f"- Q&A held-out test rows: {len(qna_test)} -> `{output_dir / 'qna_pairs_test.jsonl'}`",
        f"- Training questions: {len(qna_train)} -> `{output_dir / 'training_questions.jsonl'}`",
        f"- Evaluation questions: {len(qna_test)} -> `{output_dir / 'evaluation_questions.jsonl'}`",
        f"- Graph nodes: {len(graph['nodes'])}",
        f"- Graph candidate edges above threshold: {len(graph['edges'])}",
        "",
        "## Domain Distribution",
        "",
        "| Domain | Passages | Q&A train | Q&A test |",
        "|---|---:|---:|---:|",
    ]
    for domain in CONTENT_DOMAINS:
        lines.append(f"| {domain} | {passage_domains[domain]} | {qna_train_domains[domain]} | {qna_test_domains[domain]} |")
    lines.extend(
        [
            "",
            "## Leakage Control",
            "Held-out Q&A rows are not written to `qna_pairs.jsonl` and are not used when constructing graph edges.",
            "They are written only to `qna_pairs_test.jsonl` and `evaluation_questions.jsonl`.",
            "",
            "## Notes",
            "The graph is semi-automatic: the concept vocabulary is controlled by the agent concepts and the highlighted concept metadata matrix, while candidate edges are created automatically from concept co-occurrence in the training evidence.",
            "All graph edges are automatically extracted retrieval-expansion candidates. They are used to widen the candidate pool before dense retrieval and are never presented as clinical claims. Review by a domain professional is out of scope here and is noted as future work.",
        ]
    )
    return "\n".join(lines) + "\n"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare local thesis data for RAG experiments.")
    parser.add_argument("--data-dir", type=Path, default=PROJECT_DIR / "data" / "raw")
    parser.add_argument("--qna-workbook", type=Path, default=PROJECT_DIR / "data" / "raw" / "huberman_qna_humanreviewed.xlsx")
    parser.add_argument("--qna-sheet", default="Cleaned_QA_Pairs")
    parser.add_argument(
        "--concept-matrix",
        type=Path,
        default=PROJECT_DIR / "data" / "raw" / "highlight_concept_metadata_matrix.xlsx",
        help="Updated highlighted concept metadata matrix used to extend the controlled vocabulary.",
    )
    parser.add_argument("--output-dir", type=Path, default=PROJECT_DIR / "data" / "prepared")
    parser.add_argument("--chunk-words", type=int, default=220)
    parser.add_argument("--overlap-words", type=int, default=40)
    parser.add_argument("--test-ratio", type=float, default=0.20)
    parser.add_argument("--seed", type=int, default=20260719)
    parser.add_argument("--graph-min-confidence", type=float, default=0.70)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    set_agent_concepts_from_matrix(args.concept_matrix)

    passages, manifest = build_passages(args.data_dir, args.chunk_words, args.overlap_words)
    qna_raw = read_qna_workbook(args.qna_workbook, args.qna_sheet)
    qna_all = [normalise_qna_record(row, args.qna_workbook) for row in qna_raw]
    qna_train, qna_test = stratified_split(qna_all, args.test_ratio, args.seed)

    for record in qna_train:
        record["split"] = "train"
    for record in qna_test:
        record["split"] = "test"

    graph = build_knowledge_graph(passages, qna_train, args.graph_min_confidence)
    training_questions = build_evaluation_questions(qna_train, "train")
    evaluation_questions = build_evaluation_questions(qna_test, "test")

    write_jsonl(args.output_dir / "passages.jsonl", passages)
    write_jsonl(args.output_dir / "qna_pairs.jsonl", qna_train)
    write_jsonl(args.output_dir / "qna_pairs_train.jsonl", qna_train)
    write_jsonl(args.output_dir / "qna_pairs_test.jsonl", qna_test)
    write_jsonl(args.output_dir / "qna_pairs_all.jsonl", qna_all)
    write_jsonl(args.output_dir / "training_questions.jsonl", training_questions)
    write_jsonl(args.output_dir / "evaluation_questions.jsonl", evaluation_questions)
    (args.output_dir / "knowledge_graph.json").write_text(json.dumps(graph, indent=2, ensure_ascii=False), encoding="utf-8")
    write_agent_concepts(args.output_dir / "agent_concepts.json")
    write_concept_inventory(args.output_dir / "concept_inventory.csv", graph)
    write_csv(
        args.output_dir / "source_manifest.csv",
        manifest,
        [
            "source_id",
            "file_name",
            "file_path",
            "source_type",
            "source_title",
            "doi",
            "sha256",
            "word_count",
            "chunk_count",
            "page_count",
            "dominant_agent_domain",
            "extraction_error",
        ],
    )
    report = build_report(args.output_dir, passages, manifest, qna_all, qna_train, qna_test, graph)
    (args.output_dir / "preparation_report.md").write_text(report, encoding="utf-8")
    print(report)

    # Extraction failures used to be recorded only as a CSV column, so a third
    # of the corpus could fail to parse without anything saying so.
    failed = [row for row in manifest if row["extraction_error"]]
    empty = [row for row in manifest if not row["extraction_error"] and row["chunk_count"] == 0]
    if failed:
        print(f"\n[ERROR] {len(failed)} source files failed to extract:")
        for row in failed[:20]:
            print(f"  - {row['file_name']}: {row['extraction_error']}")
    if empty:
        print(f"\n[WARN] {len(empty)} source files parsed but produced zero chunks:")
        for row in empty[:20]:
            print(f"  - {row['file_name']}")
    unknown = sum(1 for record in passages if record["agent_domain"] == "unknown")
    if unknown:
        print(f"\n[WARN] {unknown}/{len(passages)} chunks matched no concept and are labelled 'unknown'.")
    if failed:
        raise SystemExit(
            f"{len(failed)} source files could not be extracted. Fix them or move them out of the "
            "data directory, then rerun. Continuing would silently shrink the corpus."
        )


if __name__ == "__main__":
    main()
