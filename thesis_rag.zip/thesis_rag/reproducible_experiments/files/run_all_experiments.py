
"""Run every experiment arm as one sweep, then evaluate them together.


run_experiment_batch.py already centralises the four architectures behind one
interface. What was missing was something that indexes once
instead of once per arm, gives the whole sweep a single identity.

Indexing is a function of (corpus content, chunking, embedding model) and has
nothing to do with which architecture is running. Attaching --reindex to each
arm re-embeds the same corpus three times to produce identical vectors, and
because --reindex deletes before it rebuilds, an interrupted run leaves a
partial collection that the usual "index if empty" check cannot detect. This
driver stores a fingerprint next to the Qdrant directory and reindexes only when
the fingerprint actually changes.

Each arm runs as a subprocess."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from project_paths import OUTPUTS_DIR, PREPARED_DIR, PROJECT_ROOT, SCRIPT_DIR


CURRENT_DIR = SCRIPT_DIR
PROJECT_DIR = PROJECT_ROOT

ARMS = {
    "single_agent": "single_agent_passage_rag",
    "multi_agent_passage": "multi_agent_passage_rag",
    "question_to_question": "multi_agent_question_to_question_rag",
    "graph_supported": "graph_supported_multi_agent_passage_rag",
}


def file_hash(path: Path) -> str:
    if not path.exists():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()[:16]


def corpus_fingerprint(data_path: Path, embedding_model: str, extra: dict[str, Any]) -> str:
    """Identity of an index: corpus content plus everything that shapes vectors."""
    payload = json.dumps(
        {"file": file_hash(data_path), "embedding_model": embedding_model, **extra},
        sort_keys=True,
    )
    return hashlib.sha256(payload.encode()).hexdigest()[:16]


def load_fingerprints(path: Path) -> dict[str, str]:
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_fingerprints(path: Path, data: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def run(cmd: list[str]) -> None:
    print("\n$ " + " ".join(cmd))
    completed = subprocess.run(cmd, cwd=str(PROJECT_DIR))
    if completed.returncode != 0:
        raise SystemExit(f"Command failed with exit code {completed.returncode}: {' '.join(cmd)}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the full experiment sweep.")
    parser.add_argument("--data-dir", type=Path, default=PREPARED_DIR)
    parser.add_argument("--output-dir", type=Path, default=OUTPUTS_DIR)
    parser.add_argument("--arms", nargs="+", default=list(ARMS), choices=list(ARMS))
    parser.add_argument("--embedding-model", default=None)
    parser.add_argument("--generator-model", default=None)
    parser.add_argument("--reranker-model", default=None)
    parser.add_argument("--qdrant-path", default=None)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--k", type=int, default=5)
    parser.add_argument("--seed", type=int, default=20260719)
    parser.add_argument("--graph-threshold", type=float, default=0.91)
    parser.add_argument("--route-on", choices=("original", "expanded"), default="original")
    parser.add_argument("--allow-empty-graph", action="store_true")
    parser.add_argument("--answer-metric", choices=("lexical_f1", "bertscore", "both"), default="lexical_f1")
    parser.add_argument("--continue-on-error", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--force-reindex", action="store_true")
    parser.add_argument("--skip-eval", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data_dir = args.data_dir
    out_dir = args.output_dir
    runs_dir = out_dir / "runs"
    runs_dir.mkdir(parents=True, exist_ok=True)

    passages = data_dir / "passages.jsonl"
    qna = data_dir / "qna_pairs.jsonl"
    graph = data_dir / "knowledge_graph.json"
    questions = data_dir / "evaluation_questions.jsonl"

    for required in (questions,):
        if not required.exists():
            raise SystemExit(f"Missing required file: {required}. Run prepare_experiment_data.py first.")

    run_id = uuid.uuid4().hex[:12]
    fingerprint_path = out_dir / "index_fingerprints.json"
    fingerprints = load_fingerprints(fingerprint_path)

    embedding_model = args.embedding_model or "default"
    passage_fp = corpus_fingerprint(passages, embedding_model, {"kind": "passages"})
    qna_fp = corpus_fingerprint(qna, embedding_model, {"kind": "qna"})

    needs_passage_index = args.force_reindex or fingerprints.get("passages") != passage_fp
    needs_qna_index = args.force_reindex or fingerprints.get("qna") != qna_fp

    print(f"run_id: {run_id}")
    print(f"passage index: {'REBUILD' if needs_passage_index else 'reuse'} ({passage_fp})")
    print(f"qna index:     {'REBUILD' if needs_qna_index else 'reuse'} ({qna_fp})")

    common = [
        "--questions", str(questions),
        "--passages", str(passages),
        "--qna", str(qna),
        "--graph", str(graph),
        "--seed", str(args.seed),
        "--run-id", run_id,
    ]
    for flag, value in (
        ("--embedding-model", args.embedding_model),
        ("--generator-model", args.generator_model),
        ("--reranker-model", args.reranker_model),
        ("--qdrant-path", args.qdrant_path),
    ):
        if value:
            common += [flag, value]
    if args.limit:
        common += ["--limit", str(args.limit)]
    if args.continue_on_error:
        common.append("--continue-on-error")
    if args.resume:
        common.append("--resume")

    produced: list[Path] = []
    passage_indexed = not needs_passage_index
    qna_indexed = not needs_qna_index

    # Absolute path: the arms must launch regardless of the folder name
    # or the working directory the driver was started from.
    script = str(CURRENT_DIR / "run_experiment_batch.py")
    for arm in args.arms:
        output = runs_dir / f"{arm}.jsonl"
        cmd = [sys.executable, script, "--model", arm, "--output", str(output), *common]

        # Index exactly once per collection, on the first arm that needs it.
        if arm == "question_to_question":
            if not qna_indexed:
                cmd.append("--reindex")
                qna_indexed = True
        else:
            if not passage_indexed:
                cmd.append("--reindex")
                passage_indexed = True

        if arm == "graph_supported":
            cmd += ["--graph-threshold", str(args.graph_threshold), "--route-on", args.route_on]
            if args.allow_empty_graph:
                cmd.append("--allow-empty-graph")

        run(cmd)
        produced.append(output)

    fingerprints["passages"] = passage_fp
    fingerprints["qna"] = qna_fp
    save_fingerprints(fingerprint_path, fingerprints)

    # Cross-arm integrity check before anything reaches the evaluator.
    problems: list[str] = []
    counts: dict[str, int] = {}
    for path in produced:
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
        counts[path.stem] = len(rows)
        if not rows:
            problems.append(f"{path.name} is empty")
            continue
        if {row.get("run_id") for row in rows} != {run_id}:
            problems.append(f"{path.name} contains rows from another sweep")
        errors = sum(1 for row in rows if row.get("error"))
        if errors:
            problems.append(f"{path.name} has {errors} errored rows")
    if len(set(counts.values())) > 1:
        problems.append(f"arms answered different numbers of questions: {counts}")

    manifest = {
        "run_id": run_id,
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "arms": args.arms,
        "row_counts": counts,
        "passage_fingerprint": passage_fp,
        "qna_fingerprint": qna_fp,
        "graph_file_hash": file_hash(graph),
        "problems": problems,
    }
    (out_dir / f"sweep_{run_id}.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    if problems:
        print("\n[warn] sweep integrity problems:")
        for problem in problems:
            print(f"  - {problem}")

    if args.skip_eval:
        print("\nSkipping evaluation (--skip-eval).")
        return

    eval_cmd = [
        sys.executable, str(PROJECT_DIR / "evaluate_experiment_outputs.py"),
        "--runs", *[str(path) for path in produced],
        "--output-dir", str(out_dir / "metrics"),
        "--k", str(args.k),
        "--answer-metric", args.answer_metric,
        "--baseline-model", ARMS["single_agent"],
    ]
    run(eval_cmd)
    print(f"\nSweep {run_id} complete. Metrics in {out_dir / 'metrics'}")


if __name__ == "__main__":
    main()
