
"""Where the project's data and outputs are


Anchoring defaults to the script's own directory breaks the second layout, and
anchoring to the working directory breaks whenever you run from somewhere else.
So the root is discovered instead: start at the directory holding the scripts
and walk upwards for the first directory that contains a "data" folder.

Override with the THESIS_ROOT environment variable when the layout is unusual:

    THESIS_ROOT=/content/drive/MyDrive/thesis python .../run_all_experiments.py
"""

from __future__ import annotations

import os
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
MAX_LEVELS_UP = 3


def resolve_project_root(start: Path | None = None) -> Path:
    """First directory at or above the scripts that contains a "data" folder."""
    override = os.getenv("THESIS_ROOT")
    if override:
        return Path(override).expanduser().resolve()

    start = (start or SCRIPT_DIR).resolve()
    for candidate in [start, *list(start.parents)[:MAX_LEVELS_UP]]:
        if (candidate / "data").is_dir():
            return candidate

    for candidate in list(start.parents)[:MAX_LEVELS_UP]:
        if any((candidate / name).exists() for name in ("outputs", "data", ".git")):
            return candidate
    return start


PROJECT_ROOT = resolve_project_root()
DATA_DIR = PROJECT_ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
PREPARED_DIR = DATA_DIR / "prepared"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"


def describe() -> str:
    return (
        f"project root : {PROJECT_ROOT}\n"
        f"scripts      : {SCRIPT_DIR}\n"
        f"raw data     : {RAW_DIR}      (exists: {RAW_DIR.is_dir()})\n"
        f"prepared data: {PREPARED_DIR} (exists: {PREPARED_DIR.is_dir()})\n"
        f"outputs      : {OUTPUTS_DIR}"
    )


if __name__ == "__main__":
    print(describe())
