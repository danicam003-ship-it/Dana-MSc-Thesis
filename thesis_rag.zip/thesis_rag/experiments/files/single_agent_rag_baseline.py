
"""Model 1: Single-agent passage RAG baseline.

This file also defines the shared fixed retrieval pipeline used by the other
three experiment scripts:

1. Conversational LLM: Qwen3.5-0.8B
2. Embedding model: ClinicalBERT by default, overrideable with DeBERTa
3. Vector database: Qdrant
4. Reranker: MiniLM cross-encoder

"""


from __future__ import annotations

import argparse
import json
import os
import re
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from project_paths import OUTPUTS_DIR, PROJECT_ROOT


PROJECT_DIR = PROJECT_ROOT


# Standard domain names used across all four models. These values should match
# the agent_domain metadata stored with each chunk or Q&A pair.
DOMAIN_ALIASES = {
    "mental health agent": "mental_health",
    "mental_health": "mental_health",
    "mental-health": "mental_health",
    "mental health": "mental_health",
    "sleep agent": "sleep",
    "sleep": "sleep",
    "hormonal health agent": "hormonal_health",
    "hormonal_health": "hormonal_health",
    "hormonal health": "hormonal_health",
    "lifestyle agent": "lifestyle",
    "lifestyle": "lifestyle",
    "nutrition and body agent": "nutrition_body",
    "nutrition_body": "nutrition_body",
    "nutrition and body": "nutrition_body",
    "intervention agent": "intervention",
    "intervention": "intervention",
}


def normalise_domain(value):
    text = str(value or "").strip().lower().replace("-", " ")
    return DOMAIN_ALIASES.get(text, text.replace(" ", "_") if text else "unknown")


@dataclass(frozen=True)
class FixedRAGSettings:
    """All settings that must remain fixed across the thesis comparison."""
    generator_model= os.getenv("GENERATOR_MODEL", "Qwen/Qwen3.5-0.8B")
    embedding_model= os.getenv("EMBEDDING_MODEL", "emilyalsentzer/Bio_ClinicalBERT")
    reranker_model = os.getenv("RERANKER_MODEL", "cross-encoder/ms-marco-MiniLM-L6-v2")

    # By default Qdrant is used in local embedded mode. This does not require a
    # Docker server. If you prefer a running Qdrant server, set QDRANT_URL.
    qdrant_path= os.getenv("QDRANT_PATH", str(OUTPUTS_DIR / "qdrant_local"))
    passage_collection = os.getenv("QDRANT_PASSAGE_COLLECTION", "womens_health_passages")
    qa_collection= os.getenv("QDRANT_QA_COLLECTION", "womens_health_qna_pairs")

    # Same retrieval numbers should be used in all experimental arms.
    retrieve_k= int(os.getenv("RETRIEVE_K", "40"))
    final_k= int(os.getenv("FINAL_K", "5"))
    max_new_tokens= int(os.getenv("MAX_NEW_TOKENS", "550"))
    synthesis_k= int(os.getenv("SYNTHESIS_K", str(int(os.getenv("FINAL_K", "5")))))


def model_slug(value):
    """Convert a model name into a safe suffix for Qdrant collections and files."""
    slug = re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")
    return slug or "model"


def settings_with_overrides(
    *,
    embedding_model= None,
    generator_model= None,
    reranker_model= None,
    qdrant_path= None,
    collection_suffix= None,
) -> FixedRAGSettings:
    """Build fixed settings while allowing controlled experiment overrides.

    If a non-default embedding model is used, separate Qdrant collection names
    are created automatically. This prevents ClinicalBERT and DeBERTa vectors
    from being mixed in the same collection.
    """
    base = FixedRAGSettings()
    selected_embedding_model = embedding_model or base.embedding_model
    selected_generator_model = generator_model or base.generator_model
    selected_reranker_model = reranker_model or base.reranker_model
    selected_qdrant_path = qdrant_path or base.qdrant_path

    suffix = collection_suffix
    if suffix is None and selected_embedding_model != base.embedding_model:
        suffix = model_slug(selected_embedding_model)

    passage_collection = base.passage_collection
    qa_collection = base.qa_collection
    if suffix:
        safe_suffix = model_slug(suffix)
        passage_collection = f"{passage_collection}_{safe_suffix}"
        qa_collection = f"{qa_collection}_{safe_suffix}"

    return FixedRAGSettings(
        generator_model=selected_generator_model,
        embedding_model=selected_embedding_model,
        reranker_model=selected_reranker_model,
        qdrant_path=selected_qdrant_path,
        passage_collection=passage_collection,
        qa_collection=qa_collection,
        retrieve_k=base.retrieve_k,
        final_k=base.final_k,
        max_new_tokens=base.max_new_tokens,
        synthesis_k=base.synthesis_k,
    )


def load_jsonl(path):
    """Load prepared data from JSONL
    """
    records= []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            line =line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON on line {line_number} of {path}") from exc
    return records


def first_present(record, names, default: Any = "") :
    """Return the first non-empty field from a prepared data record."""
    for name in names:
        value = record.get(name)
        if value not in (None, ""):
            return value
    return default


def stable_point_id(record_id):
    """Make a deterministic Qdrant UUID from a source chunk or Q&A identifier."""
    return str(uuid.uuid5(uuid.NAMESPACE_URL, record_id))


def sanitise_payload(record):
    """Ensure payloads are JSON-serialisable before storing them in Qdrant."""
    return json.loads(json.dumps(record, ensure_ascii=False, default=str))


def standardise_passage_record(record):
    """Map your prepared passage fields into the fields used by the scripts."""
    standard=dict(record)
    standard["record_id"] = str(
        first_present(record, ["chunk_id", "passage_id", "evidence_id", "id", "Source Record ID"])
    )
    standard["text"] = str(first_present(record, ["text", "chunk_text", "passage", "content"]))
    standard["source_title"] = str(first_present(record, ["source_title", "title", "Source Title", "Episode Title"]))
    standard["source_type"] = str(first_present(record, ["source_type", "Source Type"], "unknown"))
    standard["agent_domain"] = normalise_domain(
        first_present(record, ["agent_domain", "primary_agent", "Primary Agent"], "mental_health")
    )
    standard["retrieval_text"] = standard["text"]
    if not standard["record_id"]:
        raise ValueError("Every passage record must have chunk_id, passage_id, evidence_id, or id.")
    if not standard["text"]:
        raise ValueError(f"Passage {standard['record_id']} has no text.")
    return sanitise_payload(standard)


def standardise_qa_record(record):
    """Map your cleaned Q&A fields into the fields used by Q-to-Q retrieval."""
    standard=dict(record)
    standard["record_id"]= str(first_present(record, ["qa_id", "pair_id", "Pair ID", "id"]))
    standard["question"]= str(first_present(record, ["question", "Question"]))
    standard["answer"]=str( first_present(record, ["answer", "Possible Answer (Transcript-Derived)", "possible_answer"]) )
    standard["source_title"] = str(first_present(record, ["source_title", "Episode Title", "title"]))
    standard["source_type"] = str(first_present(record, ["source_type"], "qna_pair"))
    standard["agent_domain"] = normalise_domain(
        first_present(record, ["agent_domain", "primary_agent", "Primary Agent"], "mental_health")
    )
    # For question-to-question retrieval, the vector represents the stored question 
    standard["retrieval_text"] = standard["question"]
    if not standard["record_id"]:
        raise ValueError("Every Q&A record must have qa_id, pair_id, Pair ID, or id.")
    if not standard["question"]:
        raise ValueError(f"Q&A record {standard['record_id']} has no question.")
    return sanitise_payload(standard)


class TransformerMeanPoolEmbedder:
    """Mean-pooling embedding adapter for BERT-style encoder models.
	BERT, ClinicalBERT, and DeBERTa-style encoders return token embeddings. To
    use one of these models for retrieval, convert token-level outputs into
    one vector per text using attention-mask-aware mean pooling, then
    L2-normalise the vector. This makes cosine similarity in Qdrant meaningful.
    """

    def __init__(self, model_id):
        try:
            import torch
            from transformers import AutoModel, AutoTokenizer
        except ImportError as exc:
            raise RuntimeError(
                "Install model dependencies first: transformers, torch, qdrant-client, sentence-transformers"
            ) from exc

        self.torch = torch
        self.device= "cuda" if torch.cuda.is_available() else "cpu"
        self.tokenizer= AutoTokenizer.from_pretrained(model_id)
        self.model = AutoModel.from_pretrained(model_id).to(self.device)
        self.model.eval()
        self.vector_size = int(self.model.config.hidden_size)

    def encode(self, texts, batch_size: int = 16):
        vectors: list[list[float]] =[]
        with self.torch.inference_mode():
            for start in range(0, len(texts), batch_size):
                batch= texts[start : start + batch_size]
                tokens= self.tokenizer(
                    batch,
                    padding=True,
                    truncation=True,
                    max_length=512,
                    return_tensors="pt",
                ).to(self.device)
                output= self.model(**tokens)
                token_embeddings = output.last_hidden_state
                mask= tokens["attention_mask"].unsqueeze(-1).expand(token_embeddings.size()).float()
                pooled=(token_embeddings * mask).sum(dim=1) / mask.sum(dim=1).clamp(min=1e-9)
                pooled= self.torch.nn.functional.normalize(pooled, p=2, dim=1)
                vectors.extend(pooled.cpu().tolist())
        return vectors


ClinicalBERTEmbedder = TransformerMeanPoolEmbedder


class QdrantVectorStore:
    """Qdrant shared by all four models."""

    def __init__(self, settings: FixedRAGSettings, collection_name, embedder: TransformerMeanPoolEmbedder):
        try:
            from qdrant_client import QdrantClient
        except ImportError as exc:
            raise RuntimeError("Install qdrant-client first.") from exc

        self.settings = settings
        self.collection_name = collection_name
        self.embedder = embedder

        qdrant_url = os.getenv("QDRANT_URL", "").strip()
        qdrant_api_key = os.getenv("QDRANT_API_KEY", "").strip() or None
        if qdrant_url:
            self.client = QdrantClient(url=qdrant_url, api_key=qdrant_api_key)
        else:
            Path(settings.qdrant_path).mkdir(parents=True, exist_ok=True)
            self.client = QdrantClient(path=settings.qdrant_path)

    def collection_exists(self) -> bool:
        try:
            self.client.get_collection(self.collection_name)
            return True
        except Exception:
            return False

    def ensure_collection(self, recreate: bool = False) -> None:
        from qdrant_client.models import Distance, VectorParams

        if recreate and self.collection_exists():
            self.client.delete_collection(self.collection_name)

        if not self.collection_exists():
            self.client.create_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(size=self.embedder.vector_size, distance=Distance.COSINE),
            )

    def count_points(self):
        """Exact point count.
        """
        if not self.collection_exists():
            return 0
        return int(self.client.count(self.collection_name, exact=True).count)

    def index_records(self, records, recreate: bool = False):
        """Embed and upsert prepared records into Qdrant.

        Re-running this is safe because each point ID is derived from the stable
        record_id.
        """
        from qdrant_client.models import PointStruct

        self.ensure_collection(recreate=recreate)
        texts= [record["retrieval_text"] for record in records]
        vectors = self.embedder.encode(texts)

        points = [
            PointStruct(
                id=stable_point_id(record["record_id"]),
                vector=vector,
                payload=record,
            )
            for record, vector in zip(records, vectors, strict=True)
        ]

        for start in range(0, len(points), 64):
            self.client.upsert(self.collection_name, points[start : start + 64])

    def search(self, query, top_k, agent_domain= None):
        """Search Qdrant, optionally filtering by agent/domain metadata."""
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        query_vector = self.embedder.encode([query])[0]
        query_filter = None
        if agent_domain:
            query_filter = Filter(
                must=[
                    FieldCondition(
                        key="agent_domain",
                        match=MatchValue(value=normalise_domain(agent_domain)),
                    )
                ]
            )

        # query_points is the current API. client.search still exists but is
        # deprecated, so the old hasattr(client, "search") check always took the
        # deprecated branch and the modern branch was dead code.
        if hasattr(self.client, "query_points"):
            response = self.client.query_points(
                collection_name=self.collection_name,
                query=query_vector,
                query_filter=query_filter,
                limit=top_k,
                with_payload=True,
            )
            hits = response.points
        else:
            hits = self.client.search(
                collection_name=self.collection_name,
                query_vector=query_vector,
                query_filter=query_filter,
                limit=top_k,
                with_payload=True,
            )

        candidates= []
        for hit in hits:
            payload = dict(hit.payload or {})
            payload["qdrant_id"] = str(hit.id)
            payload["vector_score"] = float(hit.score)
            payload["rerank_score"] = None
            candidates.append(payload)
        return candidates

    def close(self):
        close = getattr(self.client, "close", None)
        if callable(close):
            close()


class MiniLMCrossEncoderReranker:
    """Rerank retrieved candidates with a MiniLM cross-encoder."""

    def __init__(self, model_id):
        try:
            from sentence_transformers import CrossEncoder
        except ImportError as exc:
            raise RuntimeError("Install sentence-transformers first.") from exc
        self.model = CrossEncoder(model_id)

    def rerank(self, query candidates, top_k: int):
        if not candidates:
            return []
        # retrieval_text is passage text for passage RAG and stored question text
        # for Q-to-Q RAG. This preserves the difference between the two methods.
        pairs = [(query, str(candidate.get("retrieval_text") or candidate.get("text") or "")) for candidate in candidates]
        scores = self.model.predict(pairs)

        reranked= []
        for candidate, score in zip(candidates, scores, strict=True):
            updated= dict(candidate)
            updated["rerank_score"] = float(score)
            reranked.append(updated)

        reranked.sort(
            key=lambda item: (
                -float(item.get("rerank_score") or 0.0),
                -float(item.get("vector_score") or 0.0),
                str(item.get("record_id") or ""),
            )
        )
        return reranked[:top_k]


class QwenGenerator:
    """Local Hugging Face generator for Qwen3.5-0.8B."""

    def __init__(self, model_id, max_new_tokens):
        try:
            from transformers import pipeline
        except ImportError as exc:
            raise RuntimeError("Install transformers and torch first.") from exc

        self.task = os.getenv(
            "GENERATOR_TASK",
            "image-text-to-text" if "qwen3.5" in model_id.lower() else "text-generation",
        )
        self.max_new_tokens = max_new_tokens
        self.call_count = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0

        pipeline_kwargs = {
            "model": model_id,
            "device_map": "auto",
            "torch_dtype": "auto",
        }
        if self.task == "text-generation":
            pipeline_kwargs["tokenizer"] = model_id
        self.pipe = pipeline(self.task, **pipeline_kwargs)

    def reset_usage(self):
        self.call_count = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0

    def usage(self):
        return {
            "llm_calls": self.call_count,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
        }

    def _count_tokens(self, text):
        tokenizer = getattr(self.pipe, "tokenizer", None)
        if tokenizer is None:
            processor = getattr(self.pipe, "processor", None)
            tokenizer = getattr(processor, "tokenizer", None)
        if tokenizer is None:
            # Rough fallback so the column is never silently zero.
            return max(1, len(text) // 4)
        try:
            return len(tokenizer(text, add_special_tokens=False)["input_ids"])
        except Exception:
            return max(1, len(text) // 4)

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        self.call_count=self.call_count+ 1
        self.prompt_tokens =self.prompt_tokens+ self._count_tokens(system_prompt) + self._count_tokens(user_prompt)

        if self.task == "image-text-to-text":
            messages = [
                {"role": "system", "content": [{"type": "text", "text": system_prompt}]},
                {"role": "user", "content": [{"type": "text", "text": user_prompt}]},
            ]
            output = self.pipe(text=messages, max_new_tokens=self.max_new_tokens, do_sample=False)
        else:
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]
            output = self.pipe(messages, max_new_tokens=self.max_new_tokens, do_sample=False)
        generated = output[0]["generated_text"]
        if isinstance(generated, list):
            content = generated[-1].get("content", "")
            if isinstance(content, list):
                text = " ".join(str(part.get("text", "")) for part in content if isinstance(part, dict)).strip()
            else:
                text = str(content).strip()
        else:
            text = str(generated).strip()

        self.completion_tokens=self.completion_tokens+ self._count_tokens(text)
        return text


def format_passage_evidence(candidates) :
    """compact, citeable evidence block for the generator prompt."""
    blocks: list[str] = []
    for index, item in enumerate(candidates, start=1):
        evidence_id = item.get("record_id") or item.get("chunk_id") or f"evidence_{index}"
        title = item.get("source_title") or item.get("title") or "Unknown source"
        section = item.get("section") or "unspecified section"
        text = item.get("text") or item.get("retrieval_text") or ""
        blocks.append(
            f"[{evidence_id}]\n"
            f"Source: {title}\n"
            f"Section: {section}\n"
            f"Vector score: {item.get('vector_score')}\n"
            f"Rerank score: {item.get('rerank_score')}\n"
            f"Text: {text}"
        )
    return "\n\n".join(blocks) or "No evidence retrieved."


def evidence_ids(candidates):
    """Return citeable IDs from retrieved evidence records."""
    ids = []
    for index, item in enumerate(candidates, start=1):
        evidence_id = item.get("record_id") or item.get("chunk_id") or item.get("qa_id") or f"evidence_{index}"
        evidence_id = str(evidence_id).strip()
        if evidence_id and evidence_id not in ids:
            ids.append(evidence_id)
    return ids


CITATION_PATTERN = re.compile(r"\[([^\]]{1,120})\]")
FALLBACK_CITATION_PREFIX = "Evidence used:"


def extract_citations(answer):
    """Return every bracketed token the model emitted, in order."""
    return [match.strip() for match in CITATION_PATTERN.findall(answer or "") if match.strip()]


def citation_report(answer, evidence):
    """Check bracketed citations against the IDs the model was actually given.
    """
    allowed= set(evidence_ids(evidence))
    cited= extract_citations(answer)
    valid= [item for item in cited if item in allowed]
    invalid= [item for item in cited if item not in allowed]
    return {
        "n_citations": len(cited),
        "n_valid_citations": len(valid),
        "n_invalid_citations": len(invalid),
        "citation_validity": len(valid) / len(cited) if cited else 0.0,
        "invalid_citation_examples": sorted(set(invalid))[:5],
        "distinct_valid_citations": len(set(valid)),
        "n_evidence_offered": len(allowed),
    }


def ensure_citations(answer, evidence):
    """Append a transparent evidence list if the LLM produced no valid citation.
	 Returns (answer, fallback_applied). The flag matters for evaluation: the
    appended block injects evidence IDs into the answer text, which would
    otherwise silently inflate both citation counts and any lexical overlap
    metric computed against a reference answer.
    """
    answer = (answer or "").strip()
    allowed = set(evidence_ids(evidence))
    if any(item in allowed for item in extract_citations(answer)):
        return answer, False

    ids = evidence_ids(evidence)
    if not ids:
        return answer, False

    cited_ids = " ".join(f"[{evidence_id}]" for evidence_id in ids[:5])
    return f"{answer}\n\n{FALLBACK_CITATION_PREFIX} {cited_ids}".strip(), True


def build_single_agent_prompt(query, evidence):
    return (
        f"User question:\n{query}\n\n"
        f"Retrieved evidence:\n{format_passage_evidence(evidence)}\n\n"
        "Write an educational answer for a women's mental-health chatbot. "
        "Use only the retrieved evidence. Every factual sentence must include at least one "
        "evidence ID in square brackets, using the exact IDs shown above, for example "
        "[SRC-001_chunk_0001]. If a claim is not directly supported by the evidence, do not "
        "include it. "
        "Do not diagnose, prescribe medication, or make deterministic claims. "
        "State uncertainty when the evidence is incomplete."
    )


class SingleAgentRAGBaseline:
    """One general retriever and one general answer generator."""

    def __init__(self, settings: FixedRAGSettings):
        self.settings = settings
        self.embedder = TransformerMeanPoolEmbedder(settings.embedding_model)
        self.store = QdrantVectorStore(settings, settings.passage_collection, self.embedder)
        self.reranker = MiniLMCrossEncoderReranker(settings.reranker_model)
        self.generator = QwenGenerator(settings.generator_model, settings.max_new_tokens)

    def index_passages(self, passage_path: Path, recreate: bool = False) -> None:
        raw_records = load_jsonl(passage_path)
        records = [standardise_passage_record(record) for record in raw_records]
        self.store.index_records(records, recreate=recreate)

    def answer(self, query: str) -> dict[str, Any]:
        # First-stage retrieval: transformer vector search over all passages.
        retrieved = self.store.search(query, top_k=self.settings.retrieve_k)

        # Second-stage retrieval: MiniLM cross-encoder reranking.
        evidence = self.reranker.rerank(query, retrieved, top_k=self.settings.final_k)

        # Final generation: one Qwen answer from the reranked evidence.
        final_answer = self.generator.generate(
            system_prompt="You are an evidence-grounded educational assistant. You are not a clinician.",
            user_prompt=build_single_agent_prompt(query, evidence),
        )
        final_answer, fallback_used = ensure_citations(final_answer, evidence)

        return {
            "model": "single_agent_passage_rag",
            "query": query,
            "answer": final_answer,
            "evidence": evidence,
            "n_evidence_to_generator": len(evidence),
            "citation_fallback_used": fallback_used,
            "citation_report": citation_report(final_answer, evidence),
        }

    def close(self) -> None:
        self.store.close()


def parse_args():
    parser = argparse.ArgumentParser(description="Run the single-agent passage RAG baseline.")
    parser.add_argument("--passages", type=Path, default=PROJECT_DIR / "data" / "prepared" / "passages.jsonl")
    parser.add_argument("--query", required=True)
    parser.add_argument("--embedding-model", default=None, help="Hugging Face encoder used for retrieval embeddings.")
    parser.add_argument("--collection-suffix", default=None, help="Optional suffix for Qdrant collection names.")
    parser.add_argument("--reindex", action="store_true", help="Rebuild the Qdrant passage collection.")
    return parser.parse_args()


def main():
    args = parse_args()
    settings = settings_with_overrides(
        embedding_model=args.embedding_model,
        collection_suffix=args.collection_suffix,
    )
    rag = SingleAgentRAGBaseline(settings)
    try:
        if args.reindex:
            rag.index_passages(args.passages, recreate=True)
        elif rag.store.count_points() == 0:
            if not args.passages.exists():
                raise FileNotFoundError(
                    f"No indexed passages found and {args.passages} does not exist. "
                    "Pass --passages with your prepared JSONL file and use --reindex."
                )
            rag.index_passages(args.passages, recreate=False)

        result = rag.answer(args.query)
    finally:
        rag.close()

    json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
    print()


if __name__ == "__main__":
    main()
