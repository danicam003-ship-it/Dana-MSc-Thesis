
"""Model 3: Multi-agent question-to-question semantic retrieval RAG.
Q-to-Q RAG retrieves already-cleaned question-answer pairs,
where the stored question is used for semantic matching and the linked answer is
used as grounded evidence.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from project_paths import PROJECT_ROOT, SCRIPT_DIR


CURRENT_DIR = SCRIPT_DIR
PROJECT_DIR = PROJECT_ROOT
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

from multi_agent_passage_rag import (  # noqa: E402
    AGENT_PROMPTS,
    UNROUTED_DOMAIN,
    AgentFinding,
    route_agents,
    safety_precheck,
)
from single_agent_rag_baseline import (  # noqa: E402
    FixedRAGSettings,
    MiniLMCrossEncoderReranker,
    QdrantVectorStore,
    QwenGenerator,
    TransformerMeanPoolEmbedder,
    citation_report,
    ensure_citations,
    load_jsonl,
    normalise_domain,
    settings_with_overrides,
    standardise_qa_record,
)


def format_qna_evidence(candidates):
    """Format retrieved Q&A pairs for the generator.
       The stored question is shown because it explains why the pair was retrieved.
       The linked answer is shown because that is the evidence used for generation.
    """
    blocks = []
    for index, item in enumerate(candidates, start=1):
        evidence_id = item.get("record_id") or item.get("qa_id") or f"qa_{index}"
        title = item.get("source_title") or item.get("title") or "Unknown source"
        blocks.append(
            f"[{evidence_id}]\n"
            f"Source: {title}\n"
            f"Stored question: {item.get('question')}\n"
            f"Transcript-derived answer: {item.get('answer')}\n"
            f"Vector score: {item.get('vector_score')}\n"
            f"Rerank score: {item.get('rerank_score')}"
        )
    return "\n\n".join(blocks) or "No Q&A evidence retrieved."


def build_qa_agent_prompt(query, agent_domain, evidence):
    return (
        f"User question:\n{query}\n\n"
        f"Agent domain: {agent_domain}\n\n"
        f"Retrieved similar Q&A pairs:\n{format_qna_evidence(evidence)}\n\n"
        "Write a short domain finding using the linked answers only. "
        "Every factual sentence must include at least one exact Q&A ID in square brackets. "
        "Do not treat podcast answers as clinical advice."
    )


def build_qa_synthesis_prompt(query, findings, evidence):
    finding_text = "\n\n".join(
        f"{finding.agent_domain} finding:\n{finding.answer}" for finding in findings
    )
    return (
        f"User question:\n{query}\n\n"
        f"Domain findings from retrieved Q&A pairs:\n{finding_text}\n\n"
        f"Underlying Q&A evidence:\n{format_qna_evidence(evidence)}\n\n"
        "Synthesize one educational answer. Make clear that the system retrieved similar "
        "questions and transcript-derived answers, not direct clinical diagnoses. Every factual "
        "sentence must include at least one exact Q&A ID in square brackets."
    )


class MultiAgentQuestionToQuestionRAG:
    """Multi-agent RAG where each agent retrieves similar cleaned questions."""

    def __init__(self, settings: FixedRAGSettings):
        self.settings = settings
        self.embedder = TransformerMeanPoolEmbedder(settings.embedding_model)
        self.store = QdrantVectorStore(settings, settings.qa_collection, self.embedder)
        self.reranker = MiniLMCrossEncoderReranker(settings.reranker_model)
        self.generator = QwenGenerator(settings.generator_model, settings.max_new_tokens)

    def index_qna_pairs(self, qna_path, recreate: bool = False):
        raw_records = load_jsonl(qna_path)
        records = [standardise_qa_record(record) for record in raw_records]
        self.store.index_records(records, recreate=recreate)

    def retrieve_for_agent(self, query, agent_domain):
        # Qdrant searches stored question embeddings. The MiniLM reranker also
        # compares the user query to the stored question, preserving the
        # question-to-question semantic retrieval design.
        retrieved = self.store.search(query=query,
            top_k=self.settings.retrieve_k,
            agent_domain=None if agent_domain == UNROUTED_DOMAIN else normalise_domain(agent_domain),
        )
        return self.reranker.rerank(query, retrieved, top_k=self.settings.final_k), len(retrieved)

    def run_agent(self, query, agent_domain):
        evidence, n_retrieved = self.retrieve_for_agent(query, agent_domain)
        answer = self.generator.generate(
            system_prompt=AGENT_PROMPTS[agent_domain],
            user_prompt=build_qa_agent_prompt(query, agent_domain, evidence),
        )
        answer, _ = ensure_citations(answer, evidence)
        return AgentFinding(
            agent_domain=agent_domain,
            answer=answer,
            evidence=evidence,
            n_retrieved=n_retrieved,
            n_after_rerank=len(evidence),
        )

    def synthesis_budget(self, n_agents):
        if self.settings.synthesis_k > 0:
            return self.settings.synthesis_k
        m=self.settings.final_k * max(1, n_agents)
        return m

    def answer(self, query):
        safety_flags=safety_precheck(query)
        routed_agents=route_agents(query)
        router_miss=not routed_agents
        active_agents= routed_agents or [UNROUTED_DOMAIN]
        findings = [self.run_agent(query, domain) for domain in active_agents]

        evidence_by_id = {}
        for finding in findings:
            for item in finding.evidence:
                evidence_by_id.setdefault(str(item.get("record_id")), item)
        synthesis_evidence = sorted(
            evidence_by_id.values(),
            key=lambda item: (
                -float(item.get("rerank_score") or 0.0),
                -float(item.get("vector_score") or 0.0),
                str(item.get("record_id") or ""),
            ),
        )[: self.synthesis_budget(len(active_agents))]

        final_answer = self.generator.generate(
            system_prompt=(
                "You are the Synthesizer Agent for question-to-question semantic retrieval. "
                "Use retrieved Q&A evidence cautiously and cite Q&A IDs in every factual sentence."
            ),
            user_prompt=build_qa_synthesis_prompt(query, findings, synthesis_evidence),
        )
        final_answer, fallback_used = ensure_citations(final_answer, synthesis_evidence)

        return {
            "model": "multi_agent_question_to_question_rag",
            "query": query,
            "routed_agents": routed_agents,
            "active_agents": active_agents,
            "router_miss": router_miss,
            "starved_agents": [f.agent_domain for f in findings if f.n_after_rerank == 0],
            "n_agents": len(active_agents),
            "safety_flags": safety_flags,
            "agent_findings": [finding.__dict__ for finding in findings],
            "answer": final_answer,
            "evidence": synthesis_evidence,
            "n_evidence_to_generator": len(synthesis_evidence),
            "synthesis_k": self.synthesis_budget(len(active_agents)),
            "citation_fallback_used": fallback_used,
            "citation_report": citation_report(final_answer, synthesis_evidence),
        }

    def close(self):
        self.store.close()


def parse_args():
    parser = argparse.ArgumentParser(description="Run multi-agent question-to-question RAG.")
    parser.add_argument("--qna", type=Path, default=PROJECT_DIR / "data" / "prepared" / "qna_pairs.jsonl")
    parser.add_argument("--query", required=True)
    parser.add_argument("--embedding-model", default=None, help="Hugging Face encoder used for retrieval embeddings.")
    parser.add_argument("--collection-suffix", default=None, help="Optional suffix for Qdrant collection names.")
    parser.add_argument("--reindex", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    settings = settings_with_overrides(
        embedding_model=args.embedding_model,
        collection_suffix=args.collection_suffix,
    )
    rag = MultiAgentQuestionToQuestionRAG(settings)

    if args.reindex:
        rag.index_qna_pairs(args.qna, recreate=True)
    elif rag.store.count_points() == 0:
        if not args.qna.exists():
            raise FileNotFoundError(
                f"No indexed Q&A pairs found and {args.qna} does not exist. "
                "Pass --qna with your prepared JSONL file and use --reindex."
            )
        rag.index_qna_pairs(args.qna, recreate=False)

    try:
        result = rag.answer(args.query)
    finally:
        rag.close()
    json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
    print()


if __name__ == "__main__":
    main()
